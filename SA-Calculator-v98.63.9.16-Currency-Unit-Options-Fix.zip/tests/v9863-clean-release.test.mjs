import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
const read = p => fs.readFileSync(p, 'utf8');
test('v98.63 removes promotional and vault-specific copy from the app shell', () => {
  const html = read('index.html');
  assert.doesNotMatch(html, /SMART\s*<span>•<\/span>\s*POWERFUL|PREMIUM Calculator Workspace/i);
  assert.match(html, />Clear Unlocked History</);
  assert.match(read('assets/js/localization.js'), /'Clear Unlocked History'/);
});
test('v98.63 keeps only one maintained Android workflow and current release docs', () => {
  const files = fs.readdirSync('.');
  assert.deepEqual(files.filter(x => /^SA-Calculator-v.*Android-Workflow\.yml$/.test(x)), []);
  for (const file of ['README.md','CHANGELOG-v98.63.md','MICRO-LEVEL-AUDIT-v98.63.md','QA-RESULTS-v98.63.md','RELEASE-LIMITATIONS-v98.63.md','.github/workflows/main.yml']) assert.ok(fs.statSync(file).isFile(), `${file} missing`);
  assert.equal(JSON.parse(read('package.json')).version, '1.98.64-v98.63.9');
  assert.equal(JSON.parse(read('manifest.webmanifest')).version, '1.98.64-v98.63.9');
  assert.match(read('service-worker.js'), /sa-calculator-v98-63-9-clean-runtime-v98639/);
});

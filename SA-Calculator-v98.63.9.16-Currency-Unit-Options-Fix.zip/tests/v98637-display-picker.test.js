const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const root = path.resolve(__dirname, '..');
const js = fs.readFileSync(path.join(root, 'assets/js/app.js'), 'utf8');
const css = fs.readFileSync(path.join(root, 'assets/css/app.css'), 'utf8');
const build = fs.readFileSync(path.join(root, 'scripts/prepare-android-web.mjs'), 'utf8');

test('currency and unit selectors are searchable independently', () => {
  assert.match(js, /const isCurrency = \/\^cur-\(from\|to\)\$\//);
  assert.match(js, /const isUnit = \/\^unit-\(from\|to\)\$\//);
  assert.match(js, /Search unit name or symbol/);
});

test('picker shows the complete currency and unit catalogs on first open and search only filters', () => {
  assert.match(js, /function selectedOptionIndex\(select, entries\)/);
  assert.match(js, /Every enabled option is present on first open/);
  assert.match(js, /if \(query && !\(optionLabel \+ ' ' \+ option\.value\)\.toLocaleLowerCase\(\)\.includes\(query\)\) return;/);
  assert.doesNotMatch(js, /revealAlternatives/);
  assert.doesNotMatch(js, /query\.length < 2 && index !== selectedIndex/);
});

test('home display is capped to 700px and keypad buttons are compact', () => {
  assert.match(css, /max-width:700px/);
  assert.match(css, /width:76%/);
  assert.match(css, /height:74%/);
  assert.match(css, /min-height:40px/);
});

test('Android bundle build includes the new final CSS layer', () => {
  assert.match(build,/assets\/css\/app\.css/);
});

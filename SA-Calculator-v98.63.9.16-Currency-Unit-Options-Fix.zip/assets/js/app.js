const APP_VERSION = '1.98.64-v98.63.9';

// Keep the skip-to-workspace link available to keyboard users without allowing
// Android WebView touch-focus to pin its blue outline over the app header.
document.addEventListener('keydown', event => {
  if (event.key === 'Tab' || event.key.startsWith('Arrow') || event.key === 'Enter' || event.key === ' ') {
    document.body.classList.add('keyboard-modality');
  }
}, true);
document.addEventListener('pointerdown', () => {
  document.body.classList.remove('keyboard-modality');
  const skipLink = document.querySelector('.skip-to-workspace');
  if (skipLink && document.activeElement === skipLink) skipLink.blur();
}, true);



// Preserve preferences and local calculator data when upgrading from the prior
// independently branded build. Copy only missing Sumaire keys; never overwrite.
(function migratePreviousBrandStorage() {
  try {
    if (typeof localStorage === 'undefined') return;
    const previousKeys = [];
    for (let i = 0; i < localStorage.length; i += 1) {
      const key = localStorage.key(i);
      if (key && key.startsWith('calcnova_')) previousKeys.push(key);
    }
    previousKeys.forEach((oldKey) => {
      const newKey = oldKey.replace(/^calcnova_/, 'sumaire_');
      if (localStorage.getItem(newKey) === null) {
        const value = localStorage.getItem(oldKey);
        if (value !== null) localStorage.setItem(newKey, value);
      }
    });
  } catch (error) { /* Storage can be unavailable in private/restricted contexts. */ }
})();


// SAFE ELEMENT TEXT SETTER (PRESERVES ACTIVE CURSOR IF PRESENT)
function setElementText(id, val) {
  const el = document.getElementById(id);
  if (!el) return;
  const textSpan = el.querySelector('.input-text');
  if (textSpan) {
    textSpan.textContent = val;
  } else {
    const cursor = el.querySelector('.input-cursor') || el.querySelector('.calc-cursor');
    if (cursor) {
      let valueNode = el.querySelector('.input-text');
      if (!valueNode) {
        valueNode = document.createElement('span');
        valueNode.className = 'input-text';
        el.insertBefore(valueNode, cursor);
      }
      valueNode.textContent = String(val);
    } else {
      el.textContent = val;
    }
  }
}


/**
 * SUMAIRE CORE ENGINE (HIGH PRECISION, SMOOTH, REACTIVE)
 */

// STATE MANAGEMENT
const STATE = {
  hapticEnabled: true,
  vibeStrength: 'medium',
  keySound: true,
  autoCopy: false,
  thousandsSep: 'comma',
  precision: 'auto',
  language: 'en',
  fullscreen: false,
  fontSize: 'medium',
  screenAwake: false,
  theme: 'dark',
  accentColor: '#8b78ff',
  oledBlack: false,
  liveCalc: true,
  implicitMult: true,
  trailingZeros: true,
  startupScreen: 'calc',
  restoreState: true,
  recordHistory: true,
  maxHistory: '50',
  telemetry: false,
  favorites: ['calc', 'currencies', 'units', 'discount', 'percent', 'salestax'],

  currentScreen: 'calc',
  previousScreen: 'calc',
  screenScrollPositions: Object.create(null),
  activeInputTarget: null,
  calcExpr: '',
  calcCursor: 0,
  calcSelectionStart: 0,
  calcSelectionEnd: 0,
  calcSelectionDirection: 'none',
  calcVal: '0',
  calcErrorMessage: '',
  // Scientific-panel error preview is intentionally preview-only until the user
  // edits the expression again. It must never be committed by '='.
  calcScientificErrorPreview: false,
  // The forced scientific-preview error is scoped to the exact expression
  // that produced it. Cursor movement or later editing must never make the
  // old Error state stick to a newly valid expression (e.g. `195`).
  calcScientificErrorExpression: null,
  calcRawValue: null,
  calcRepeat: null,
  calcResultExpression: null,
  calcResultSelectionStart: 0,
  calcResultSelectionEnd: 0,
  calcResultSelectionDirection: 'none',
  isResultMode: false,
  history: [],
  currencyUpdatedAt: null,
  currencyLastRefreshAt: null,
  currencyLastSuccessfulRefreshAt: null,
  currencyRateDate: null,
  currencyRateDates: {},
  currencyRateSources: {},
  currencyRateSource: 'built-in',
  worldTimeZones: ['America/New_York', 'Europe/London', 'Asia/Kolkata', 'Asia/Tokyo'],
  currencies: {
    USD: 1.0,
    INR: 94.70,
    EUR: 0.92,
    GBP: 0.79,
    AED: 3.67,
    SAR: 3.75,
    PKR: 278.50,
    CAD: 1.38,
    AUD: 1.52,
    JPY: 153.20,
    CNY: 6.6925795,
    BAM: 1.80,
    BWP: 13.50,
    BRL: 5.68,
    UYU: 41.50,
    UZS: 12800.0,
    VES: 42.80,
    VND: 25400.0,
    XAF: 605.0,
    YER: 250.0,
    ZMW: 26.50
  }
};

// Offline-first currency estimates are retained only as an explicitly labelled
// fallback. They are never presented as live or freshly updated exchange rates.
const BUILTIN_CURRENCY_RATES = Object.freeze({ ...STATE.currencies });

// Consistent significant-digit formatting preserves small values without noisy trailing zeros.
function formatCalcNumber(value, significantDigits = 12) {
  if (!Number.isFinite(value)) return 'Error';
  return String(Number(value.toPrecision(significantDigits)));
}

// Shared result formatter honors the app's precision, trailing-zero, and grouping settings.
function formatResultNumber(value, fallbackDecimals = 2) {
  if (!Number.isFinite(Number(value))) return 'Error';
  const numeric = Number(value);
  const configured = STATE.precision === 'auto' ? null : Number.parseInt(STATE.precision, 10);
  const decimals = Number.isInteger(configured) && configured >= 0 && configured <= 6
    ? configured
    : Math.max(0, Math.min(12, fallbackDecimals));
  let text;
  const magnitude = Math.abs(numeric);
  // Number#toFixed switches to exponent notation at 1e21 and rounds tiny
  // non-zero values to zero. Handle those ranges deliberately so tool results
  // never expose binary-float noise or silently lose a measurable value.
  const scientific = magnitude >= 1e21 || (magnitude > 0 && magnitude < 1e-6);
  if (scientific) {
    const significantDigits = STATE.precision === 'auto'
      ? (fallbackDecimals >= 10 ? Math.max(1, Math.min(15, fallbackDecimals)) : Math.max(1, Math.min(12, fallbackDecimals + 1)))
      : Math.max(1, Math.min(13, decimals + 1));
    text = numeric.toExponential(significantDigits - 1);
    if (!STATE.trailingZeros && text.includes('.')) {
      const [mantissa, exponent] = text.split('e');
      text = `${mantissa.replace(/\.?0+$/, '')}e${exponent}`;
    }
    return text;
  }
  if (STATE.precision === 'auto') {
    // Calculator calls pass 12 for significant-digit output; other modules keep
    // their domain-appropriate fallback decimal count (e.g. currency = 2).
    text = fallbackDecimals >= 10
      ? String(Number(numeric.toPrecision(Math.max(1, Math.min(15, fallbackDecimals)))))
      : numeric.toFixed(Math.max(0, Math.min(12, fallbackDecimals)));
    if (!STATE.trailingZeros && text.includes('.')) text = text.replace(/\.?0+$/, '');
  } else {
    text = numeric.toFixed(decimals);
    if (!STATE.trailingZeros && text.includes('.')) text = text.replace(/\.?0+$/, '');
  }
  const [signless, fraction] = text.replace(/^[-+]/, '').split('.');
  const sign = text.startsWith('-') ? '-' : '';
  let grouped = signless;
  if (STATE.thousandsSep === 'comma') {
    grouped = signless.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  } else if (STATE.thousandsSep === 'space') {
    grouped = signless.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  } else if (STATE.thousandsSep === 'lakh') {
    grouped = signless.replace(/(\d)(?=(\d{2})+\d{3}$)/g, '$1,');
    grouped = grouped.replace(/\B(?=(\d{3})+$)/g, ',');
  }
  return sign + grouped + (fraction !== undefined ? `.${fraction}` : '');
}

// Unit-converter output stays grouped and readable through 12 integer digits.
// Beyond that boundary (and for extremely small non-zero values), switch to
// 12-significant-digit scientific notation so the result cannot overflow its
// result field. This is display-only: conversion math keeps the full Number.
function formatUnitResultNumber(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 'Error';
  const magnitude = Math.abs(numeric);
  const roundedMagnitude = magnitude === 0 ? 0 : Math.abs(Number(numeric.toPrecision(12)));
  if (roundedMagnitude >= 1e12 || (magnitude > 0 && magnitude < 1e-6)) {
    return numeric.toExponential(11)
      .replace(/(\.\d*?[1-9])0+e/, '$1e')
      .replace(/\.0+e/, 'e');
  }
  return formatResultNumber(numeric, 12);
}

// Calculator-specific result display. Keep the full calculation value in
// STATE.calcRawValue; the 12-significant-digit display is a presentation layer.
// Scientific mantissas use at most six fractional places, with trailing zeros
// removed. Keep all 12-digit integer values in ordinary notation; switch only
// when the integer part grows to 13 digits (or for tiny non-zero magnitudes).
function calculatorIntegerDigitCount(value) {
  const magnitude = Math.abs(Number(value));
  if (!Number.isFinite(magnitude) || magnitude < 1) return 1;
  // Avoid logarithm boundary errors (for example log10(1e12) rounding just
  // below 12). Number#toFixed is exact enough for the <= 12 digit boundary;
  // larger values are already represented in exponent notation by JS.
  if (magnitude < 1e21) return Math.floor(magnitude).toString().length;
  const exponent = Number(magnitude.toExponential().split('e')[1]);
  return exponent + 1;
}

function calculatorNeedsScientificNotation(value) {
  const numeric = Number(value);
  const magnitude = Math.abs(numeric);
  if (!Number.isFinite(numeric)) return true;
  // The calculator's rule is based on integer digits, not total characters or
  // locale separators: 12 integer digits stay ordinary; digit 13 switches.
  // Tiny non-zero values remain scientific so they cannot disappear as zero.
  return calculatorIntegerDigitCount(magnitude) > 12 || (magnitude > 0 && magnitude < 1e-6);
}

function formatCalculatorResultNumber(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 'Error';
  // Apply the same 12-significant-digit display rounding before deciding the
  // boundary. This prevents a 12-digit value that rounds up to 1e12 from being
  // shown as a 13-digit ordinary integer. The raw calculation value is never
  // changed; only the display decision uses this rounded candidate.
  const configuredPrecision = STATE.precision === 'auto' ? null : Number.parseInt(STATE.precision, 10);
  const displayCandidate = STATE.precision === 'auto'
    ? Number(numeric.toPrecision(12))
    : (Number.isInteger(configuredPrecision) && configuredPrecision >= 0 && configuredPrecision <= 6
      ? Number(numeric.toFixed(configuredPrecision))
      : Number(numeric.toPrecision(12)));
  if (calculatorNeedsScientificNotation(displayCandidate)) return formatScientificEntryDisplay(numeric);
  return formatResultNumber(numeric, 12);
}

// Root expressions retain up to 11 digits after the decimal point. Apply this
// only to the rendered result: the parser and STATE.calcRawValue keep the full
// IEEE-754 value, so adding another operand never uses the rounded text.
function formatCalculatorExpressionResult(expression, value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 'Error';
  // Entry syntax must never override the calculator's numeric display
  // threshold. In particular e11 is 100000000000 (12 integer digits) and
  // remains ordinary; e12 is the first exponent-entry value that crosses
  // the 13-digit boundary and becomes scientific. Continued display tokens
  // and memory-recalled scientific operands follow the same rule. The
  // formatter retains six fractional mantissa digits whenever notation is
  // required, while the raw numeric value remains untouched for arithmetic.
  return formatCalculatorResultNumber(numeric);
}

// A repeated root key extends a prefix-root chain instead of wrapping the
// previous radical in another pair of parentheses: √√(9), ∛∛(27), etc.
function buildRootInsertion(displayFunction, operand) {
  const source = String(operand ?? '');
  return /^[√∛]/.test(source) ? `${displayFunction}${source}` : `${displayFunction}(${source})`;
}

function markScientificErrorPreview(expression = STATE.calcExpr) {
  STATE.calcScientificErrorPreview = true;
  STATE.calcScientificErrorExpression = String(expression ?? '');
}

function clearScientificErrorPreview() {
  STATE.calcScientificErrorPreview = false;
  STATE.calcScientificErrorExpression = null;
}

function isForcedScientificErrorPreview(expression) {
  return STATE.calcScientificErrorPreview === true &&
    STATE.calcScientificErrorExpression === String(expression ?? '');
}

// Convert the visible scientific notation back into a parser-safe exponent
// token without expanding it into a long decimal integer. This keeps the
// expression compact when a user continues from a scientific result.
function normalizeScientificExpressionGlyphs(expression) {
  const superscript = {'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁺':'+','⁻':'-'};
  return String(expression ?? '').replace(
    /([+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*×\s*10([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+)/g,
    (_, mantissa, exponent) => `${mantissa}e${exponent.split('').map(ch => superscript[ch] ?? ch).join('')}`
  );
}

function calculatorExpressionFromCommittedResult() {
  if (STATE.calcVal === 'Error') { STATE.calcScientificContinuation = null; return '0'; }
  const canonical = String(STATE.calcVal ?? '0');
  // Scientific calculator results are committed as a human-readable token
  // (for example `1×10⁹`), not as JS `1e9`. Preserve that exact token when an
  // operator is pressed after '=', while keeping the full raw value for math.
  const superscriptDigits = '⁰¹²³⁴⁵⁶⁷⁸⁹';
  const displayedScientific = canonical.match(/^([+-]?(?:\d+(?:\.\d*)?|\.\d+))\s*×\s*10([⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+)$/);
  if (displayedScientific) {
    const exponent = displayedScientific[2].split('').map(ch => {
      if (ch === '⁺') return '+';
      if (ch === '⁻') return '-';
      return String(superscriptDigits.indexOf(ch));
    }).join('');
    const parsedValue = Number(`${displayedScientific[1]}e${exponent}`);
    const exactValue = Number.isFinite(STATE.calcRawValue) ? STATE.calcRawValue : parsedValue;
    STATE.calcScientificContinuation = { displayToken: canonical, exactValue };
    return canonical;
  }
  const scientific = canonical.match(/^([+-]?(?:\d+(?:\.\d*)?|\.\d+))[eE]([+-]?\d+)$/);
  if (scientific) {
    const displayToken = `${scientific[1]} × 10${toSuperscriptExponent(Number(scientific[2]))}`;
    const exactValue = Number.isFinite(STATE.calcRawValue) ? STATE.calcRawValue : Number(canonical);
    STATE.calcScientificContinuation = { displayToken, exactValue };
    return displayToken;
  }
  STATE.calcScientificContinuation = null;
  // Radical results intentionally continue from the exact value the user saw.
  // Example: √2 = 1.41421356237, then +1 must produce the editable expression
  // `1.41421356237+1`, not expose the hidden IEEE-754 tail. This keeps the
  // committed display and the next expression semantically consistent.
  const committedExpression = String(STATE.calcResultExpression ?? STATE.calcExpr ?? '');
  if (/[√∛]/.test(committedExpression)) {
    return canonical.replace(/[ ,]/g, '');
  }
  // Non-radical ordinary values retain full underlying precision; never feed
  // grouped display text (commas/spaces) back into the arithmetic parser.
  return Number.isFinite(STATE.calcRawValue) ? String(STATE.calcRawValue) : canonical.replace(/[ ,]/g, '');
}

// INITIALIZATION ON DOM READY
document.addEventListener('DOMContentLoaded', () => {
  // Enable the versioned offline shell only on secure origins (HTTPS/localhost).
  // Registration is intentionally non-blocking: calculator startup must never wait on SW setup.
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || location.hostname === 'localhost' || location.hostname === '127.0.0.1')) {
    navigator.serviceWorker.register('./service-worker.js', { scope: './', updateViaCache: 'none' })
      .catch(error => console.warn('SA Calculator offline support could not be enabled:', error));
  }
  loadSettingsFromStorage();
  // Re-apply the resolved palette after all legacy stylesheet defaults are loaded.
  setAccentThemeTokens(STATE.accentColor || '#8b78ff');
  initDrawer();
  initBottomNavigation();
  initThemePicker();
  initKeypads();
  initCalculators();
  initTipTaxOption();
  initReferenceScreenActions();
  reorderReferenceSettings();
  initDateEvents();
  initGpaCourses();
  initPercentModes();
  initCurrencies();
  initUnits();
  initScientific();
  restoreHistory();
  initHistory();
  initTextInputDialog();
  initSupportDialogs();
  document.addEventListener('fullscreenchange', syncFullscreenSetting);
  syncFullscreenSetting();
  restorePreviousInputs();
  calcCurrency();
  calcUnits();
  initCalculationControlEvents();
  initWorldTime();
  updateWorldTimeLive();
  initAdaptiveToolResults();
  const startWorldTimeTimer = () => {
    if (!document.hidden && !window.worldTimeInterval) window.worldTimeInterval = setInterval(updateWorldTimeLive, 60000);
  };
  const stopWorldTimeTimer = () => {
    if (window.worldTimeInterval) { clearInterval(window.worldTimeInterval); window.worldTimeInterval = null; }
  };
  startWorldTimeTimer();
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) { updateWorldTimeLive(); startWorldTimeTimer(); if (STATE.screenAwake && !wakeLockSentinel) toggleScreenAwake(true); }
    else { stopWorldTimeTimer(); if (wakeLockSentinel) { wakeLockSentinel.release().catch(() => {}); wakeLockSentinel = null; } }
  });
  window.addEventListener('pagehide', stopWorldTimeTimer);
  window.addEventListener('pageshow', () => { updateWorldTimeLive(); startWorldTimeTimer(); });
});





function numericDigitCount(value) {
  return (String(value ?? '').match(/\d/g) || []).length;
}

// Calculator inputs use IEEE-754 Number arithmetic. Limit meaningful precision,
// not raw character count: leading zeros and insignificant trailing zeros do
// not consume the 15-significant-digit budget. Exponent digits are excluded by
// callers before this helper is used.
function numericSignificantDigitCount(value) {
  const digits = String(value ?? '').replace(/\D/g, '');
  const significant = digits.replace(/^0+/, '').replace(/0+$/, '');
  return significant.length || (digits.length ? 1 : 0);
}

function appendLimitedNumericKey(currentValue, key, maxDigits = 15, maxFractionDigits = Infinity) {
  let value = String(currentValue ?? '').replace(/[$,%\s,]/g, '');
  if (!value) value = '0';
  if (key === '.') {
    if (value.includes('.')) return value;
    return value + '.';
  }
  if (!/^\d+$/.test(String(key))) return value;
  const incoming = String(key);
  const fraction = value.includes('.') ? value.split('.')[1] : '';
  if (value.includes('.') && fraction.length >= maxFractionDigits) {
    showToast(`Maximum ${maxFractionDigits} decimal digits allowed`);
    return value;
  }
  if (value.includes('.') && fraction.length + incoming.length > maxFractionDigits) {
    showToast(`Maximum ${maxFractionDigits} decimal digits allowed`);
    return value;
  }
  const incomingDigits = incoming.length;
  if (numericDigitCount(value) + incomingDigits > maxDigits) {
    showToast(`Maximum ${maxDigits} digits allowed`);
    return value;
  }
  if (value === '0' && key !== '00') return String(key);
  if (value === '0' && key === '00') return '0';
  return value + incoming;
}

function limitCurrencyFraction(value, maxFractionDigits = 4) {
  let s = String(value ?? '').replace(/[$,%\s,]/g, '').trim();
  if (!s) return '0';
  if (!/^-?(?:\d+(?:\.\d*)?|\.\d+)$/.test(s)) return 'Error';
  const sign = s.startsWith('-') ? '-' : '';
  s = s.replace(/^[+-]/, '');
  let [whole, fraction = ''] = s.split('.');
  whole = whole || '0';
  if (fraction.length > maxFractionDigits) {
    const head = fraction.slice(0, maxFractionDigits);
    const next = Number(fraction.charAt(maxFractionDigits));
    let digits = BigInt((whole + head) || '0');
    if (next >= 5) digits += 1n;
    let text = digits.toString();
    if (text.length <= maxFractionDigits) text = text.padStart(maxFractionDigits + 1, '0');
    const cut = text.length - maxFractionDigits;
    whole = text.slice(0, cut);
    fraction = text.slice(cut);
  }
  fraction = fraction.slice(0, maxFractionDigits);
  return sign + whole + (fraction ? '.' + fraction : '');
}

function isSafePersistedNumericValue(value) {
  if (typeof value !== 'string' || value.length > 40) return false;
  const normalized = value.replace(/[$,%\s,]/g, '');
  if (!/^-?(?:\d+(?:\.\d*)?|\.\d+)$/.test(normalized)) return false;
  return numericDigitCount(normalized) <= 15;
}

function persistPreviousInputs() {
  if (!STATE.restoreState) return;
  try {
    const values = {};
    document.querySelectorAll('.input-val-box[id], .gpa-credits[id], input[type="date"][id], select[id]').forEach(element => {
      if (!element.id || element.id.startsWith('setting-') || element.id.length > 100) return;
      const value = element.classList.contains('input-val-box')
        ? (element.querySelector('.input-text')?.textContent ?? element.textContent)
        : element.value;
      if (typeof value === 'string' && ((element.classList.contains('input-val-box') || element.classList.contains('gpa-credits')) ? isSafePersistedNumericValue(value) : value.length <= 100)) values[element.id] = value;
    });
    const bounded = Object.fromEntries(Object.entries(values).slice(0, 250));
    const serialized = JSON.stringify(bounded);
    // Match the restore ceiling so we never write a payload that cannot be restored.
    if (serialized.length <= 50000) localStorage.setItem('sumaire_previous_inputs', serialized);
  } catch (error) {
    // Storage can be unavailable in private or restricted browser contexts.
  }
}

function restorePreviousInputs() {
  if (!STATE.restoreState) return;
  try {
    const raw = localStorage.getItem('sumaire_previous_inputs');
    if (!raw || raw.length > 50000) return;
    const values = JSON.parse(raw);
    if (!values || typeof values !== 'object' || Array.isArray(values)) return;
    Object.entries(values).slice(0, 250).forEach(([id, value]) => {
      if (!id || id.length > 100 || typeof value !== 'string' || value.length > 100) return;
      if (id.startsWith('setting-')) return;
      const element = document.getElementById(id);
      if (!element) return;
      if (element.classList.contains('input-val-box')) {
        if (!isSafePersistedNumericValue(value)) return;
        const text = element.querySelector('.input-text');
        if (text) text.textContent = value;
      } else if (element.classList.contains('gpa-credits')) {
        if (!isSafePersistedNumericValue(value)) return;
        element.value = value;
      } else if (element.matches('input[type="date"]')) {
        if (/^\d{4}-\d{2}-\d{2}$/.test(value)) element.value = value;
      } else if (element.matches('select')) {
        if (Array.from(element.options).some(option => option.value === value)) element.value = value;
      }
    });
  } catch (error) {
    // Ignore malformed or unavailable persisted input state.
  }
}

function initCalculationControlEvents() {
  document.addEventListener('input', persistPreviousInputs);
  document.addEventListener('change', persistPreviousInputs);
  const bind = (id, calculate) => {
    const control = document.getElementById(id);
    if (control) control.addEventListener('change', calculate);
  };
  bind('tax-mode', calcSalesTax);
  bind('bmi-gender', calcBodyMetrics);
  bind('loan-method', calcLoan);
  bind('sav-frequency', calcSavings);

  // Initial outputs should reflect the displayed default inputs before the first keypad tap.
  calcSalesTax();
  calcBodyMetrics();
  // Loan schedule is built lazily when its screen is opened, avoiding hundreds
  // of off-screen table rows during the calculator's initial startup.
  if (STATE.currentScreen === 'loan') calcLoan();
  calcSavings();
}

function showToast(msg) {
  const toast = document.getElementById('app-toast');
  if (!toast) return;
  toast.querySelector('span').textContent = msg;
  toast.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(() => {
    toast.classList.remove('show');
  }, 2200);
}

function triggerHaptic() {
  if (STATE.keySound) playKeyClickSound();
  if (STATE.hapticEnabled && navigator.vibrate) {
    // Keep runtime feedback aligned with the exact durations shown in Settings.
    // Settings stores the option as `heavy` (the visible label is Strong).
    // Keep `strong` as a compatibility alias for older saved preferences.
    const vibrationMs = { light: 15, medium: 30, heavy: 50, strong: 50 }[STATE.vibeStrength] ?? 30;
    try { navigator.vibrate(vibrationMs); } catch (error) { /* Unsupported or restricted WebView vibration. */ }
  }
}

let isLoadingSettings = false;
function saveSettingsToStorage() {
  if (isLoadingSettings) return;
  try {
    const s = {
      theme: STATE.theme,
      accentColor: STATE.accentColor,
      oledBlack: STATE.oledBlack,
      fontSize: STATE.fontSize,
      precision: STATE.precision,
      separator: STATE.thousandsSep,
      language: STATE.language,
      hapticEnabled: STATE.hapticEnabled,
      vibeStrength: STATE.vibeStrength,
      keySound: STATE.keySound,
      autoCopy: STATE.autoCopy,
      liveCalc: STATE.liveCalc,
      implicitMult: STATE.implicitMult,
      trailingZeros: STATE.trailingZeros,
      startupScreen: STATE.startupScreen,
      restoreState: STATE.restoreState,
      recordHistory: STATE.recordHistory,
      maxHistory: STATE.maxHistory,
      telemetry: STATE.telemetry,
      favorites: STATE.favorites,
      settingsFormatVersion: 2
    };
    localStorage.setItem('sumaire_settings_master', JSON.stringify(s));
  } catch(e) {}
}

function loadSettingsFromStorage() {
  let loadedSuccessfully = false;
  isLoadingSettings = true;
  try {
    const raw = localStorage.getItem('sumaire_settings_master');
    if (!raw) return;
    const s = JSON.parse(raw);
    // v2 removes the old forced .00 calculator default while preserving other preferences.
    if (!Number.isInteger(s.settingsFormatVersion) || s.settingsFormatVersion < 2) {
      s.precision = 'auto';
      s.settingsFormatVersion = 2;
    }
    
    // Migrate only unknown legacy accents; preserve a valid saved appearance mode.
    if (!['dark', 'light', 'system'].includes(s.theme)) s.theme = 'dark';
    if (!/^#[0-9a-f]{6}$/i.test(String(s.accentColor || '')) || !['#8b78ff','#5bd7f2','#f49a3e','#ef444f','#76504d','#7738d4','#e65eae','#f3c982','#61d5d3','#6594dc','#dc5d5d','#e8d34b'].includes(String(s.accentColor).toLowerCase())) s.accentColor = '#8b78ff';
    STATE.theme = s.theme;
    STATE.accentColor = String(s.accentColor).toLowerCase();
    const themeControl = document.getElementById('setting-theme');
    if (themeControl) themeControl.value = STATE.theme;
    const accentControl = document.getElementById('setting-accent');
    if (accentControl) accentControl.value = STATE.accentColor;
    applySettingTheme(STATE.theme);
    applyAccentColor(STATE.accentColor);
    if (typeof s.oledBlack === 'boolean') {
      STATE.oledBlack = s.oledBlack;
      const el = document.getElementById('setting-oled');
      if (el) el.checked = s.oledBlack;
      toggleOLED(s.oledBlack);
    }
    if (['small', 'medium', 'large'].includes(s.fontSize)) {
      STATE.fontSize = s.fontSize;
      const el = document.getElementById('setting-fontsize');
      if (el) el.value = s.fontSize;
      applyFontSize(s.fontSize);
    }
    if (['auto', '0', '2', '4', '6'].includes(String(s.precision))) {
      STATE.precision = s.precision;
      const el = document.getElementById('setting-precision');
      if (el) el.value = s.precision;
      applySettingPrecision(s.precision);
    }
    if (['comma', 'space', 'lakh', 'none'].includes(s.separator)) {
      STATE.thousandsSep = s.separator;
      const el = document.getElementById('setting-separator');
      if (el) el.value = s.separator;
      applySettingSeparator(s.separator);
    }
    if (Object.prototype.hasOwnProperty.call(TRANSLATIONS, s.language)) {
      STATE.language = s.language;
      const el = document.getElementById('setting-language');
      if (el) el.value = s.language;
      applyLanguage(s.language);
    }
    if (typeof s.hapticEnabled === 'boolean') {
      STATE.hapticEnabled = s.hapticEnabled;
      const el = document.getElementById('setting-haptic');
      if (el) el.checked = s.hapticEnabled;
    }
    if (['light', 'medium', 'heavy'].includes(s.vibeStrength)) {
      STATE.vibeStrength = s.vibeStrength;
      const el = document.getElementById('setting-vibe-strength');
      if (el) el.value = s.vibeStrength;
    }
    if (typeof s.keySound === 'boolean') {
      STATE.keySound = s.keySound;
      const el = document.getElementById('setting-sound');
      if (el) el.checked = s.keySound;
    }
    if (typeof s.autoCopy === 'boolean') {
      STATE.autoCopy = s.autoCopy;
      const el = document.getElementById('setting-autocopy');
      if (el) el.checked = s.autoCopy;
    }
    if (typeof s.liveCalc === 'boolean') {
      STATE.liveCalc = s.liveCalc;
      const el = document.getElementById('setting-livecalc');
      if (el) el.checked = s.liveCalc;
    }
    if (typeof s.implicitMult === 'boolean') {
      STATE.implicitMult = s.implicitMult;
      const el = document.getElementById('setting-implicit');
      if (el) el.checked = s.implicitMult;
    }
    if (typeof s.trailingZeros === 'boolean') {
      STATE.trailingZeros = s.trailingZeros;
      const el = document.getElementById('setting-trailing-zero');
      if (el) el.checked = s.trailingZeros;
    }
    if (s.startupScreen && ['calc', 'currencies', 'units', 'discount', 'last', 'percent', 'salestax', 'bodymetrics', 'date', 'fuelcost', 'fuelefficiency', 'gradeavg', 'hex', 'loan', 'savings', 'tip', 'unitprice', 'worldtime'].includes(s.startupScreen)) {
      STATE.startupScreen = s.startupScreen;
      const el = document.getElementById('setting-startup-screen');
      if (el) el.value = s.startupScreen;
      let initialScreen = s.startupScreen;
      if (initialScreen === 'last') {
        try {
          const last = localStorage.getItem('sumaire_last_screen');
          initialScreen = last && document.getElementById(`screen-${last}`) ? last : 'calc';
        } catch (error) { initialScreen = 'calc'; }
      }
      switchScreen(initialScreen); // Always activate the configured startup screen, including Calculator.
    }
    if (typeof s.restoreState === 'boolean') {
      STATE.restoreState = s.restoreState;
      const el = document.getElementById('setting-restore-state');
      if (el) el.checked = s.restoreState;
    }
    if (typeof s.recordHistory === 'boolean') {
      STATE.recordHistory = s.recordHistory;
      const el = document.getElementById('setting-record-history');
      if (el) el.checked = s.recordHistory;
    }
    STATE.telemetry = false;
    if ([25, 50, 100, 500].includes(Number(s.maxHistory))) {
      STATE.maxHistory = String(Number(s.maxHistory));
      const el = document.getElementById('setting-max-history');
      if (el) el.value = s.maxHistory;
    }
    if (Array.isArray(s.favorites)) {
      STATE.favorites = [...new Set(s.favorites.filter(id => ALL_CALC_ITEMS.some(item => item.id === id)))];
      updateDrawerFavoritesDOM();
    }
    loadedSuccessfully = true;
  } catch(e) {
    // Ignore malformed or inaccessible settings; keep in-memory defaults.
  } finally {
    isLoadingSettings = false;
    // Persist the fully-normalized settings once, after every stored preference
    // has been restored. Individual apply handlers must not overwrite the
    // unread remainder of the original record during initialization.
    if (loadedSuccessfully) saveSettingsToStorage();
  }
}

// PHYSICAL KEYBOARD SUPPORT: preserve native form editing and browser navigation.
document.addEventListener('keydown', (e) => {
  const target = e.target;
  const isEditable = target && (
    target.isContentEditable ||
    /^(INPUT|TEXTAREA|SELECT)$/.test(target.tagName)
  );
  // Never hijack typing inside editable controls, modified shortcuts, or native Tab navigation.
  if (isEditable || e.altKey || e.ctrlKey || e.metaKey || e.key === 'Tab') return;

  if (e.key === 'Escape') {
    const overlay = document.getElementById('drawer-overlay');
    const drawer = document.getElementById('sidebar-drawer');
    if (drawer && drawer.classList.contains('active')) {
      // Keep visual, accessibility and focus state in sync even when Escape is
      // received outside the drawer (for example after WebView focus is lost).
      overlay?.classList.remove('active');
      drawer.classList.remove('active');
      drawer.setAttribute('aria-hidden', 'true');
      drawer.inert = true;
      const opener = document.querySelector('[data-bottom-nav="tools"]') || document.getElementById('btn-drawer-open');
      if (opener && opener.getClientRects().length) opener.focus({ preventScroll: true });
      e.preventDefault();
      return;
    }
    const history = document.getElementById('history-modal');
    if (history?.classList.contains('active')) {
      closeHistoryModal();
      e.preventDefault();
      return;
    }
    // The Scientific dialog owns its Escape lifecycle so ARIA state and focus are restored together.
    closePopupKeypad();
    return;
  }

  const consumed = ['0','1','2','3','4','5','6','7','8','9','.','+','-','*','/','=','Enter','Backspace','Delete','c','C'];
  if (!consumed.includes(e.key)) return;

  if (STATE.currentScreen === 'calc') {
    const action = e.key === 'Enter' ? '=' : e.key === 'Delete' || e.key === 'c' || e.key === 'C' ? 'C' : e.key;
    if (action === 'Backspace') {
      e.preventDefault();
      deleteCalcBackward();
      return;
    }
    const btn = Array.from(document.querySelectorAll('.main-keypad [data-calc]'))
      .find(button => button.getAttribute('data-calc') === action);
    if (btn) {
      e.preventDefault();
      btn.click();
    }
  } else {
    if (e.key === 'Enter') {
      e.preventDefault();
      handleKeypadInput('NEXT');
    } else if (e.key === 'Backspace') {
      e.preventDefault();
      handleKeypadInput('DEL');
    } else if (e.key === 'Delete') {
      e.preventDefault();
      handleKeypadInput('CLR');
    } else if (/^[0-9.]$/.test(e.key)) {
      e.preventDefault();
      handleKeypadInput(e.key);
    }
  }
});

// DRAWER NAVIGATION
function initDrawer() {
  const overlay = document.getElementById('drawer-overlay');
  const drawer = document.getElementById('sidebar-drawer');
  const btnOpen = document.getElementById('btn-drawer-open');
  drawer.setAttribute('aria-hidden', 'true');
  drawer.inert = true;

  function openDrawer() {
    // Treat the overlay drawer as a modal navigation surface for keyboard and
    // assistive-technology users, and keep focus inside it while it is open.
    closePopupKeypad();
    drawer.setAttribute('aria-hidden', 'false');
    drawer.inert = false;
    // Start at the top whenever the compact utility drawer opens.
    drawer.scrollTop = 0;
    overlay.classList.add('active');
    drawer.classList.add('active');
    const initialFocus = drawer.querySelector('#btn-drawer-close, .drawer-menu-item, .drawer-item[tabindex="0"]');
    if (initialFocus) initialFocus.focus({ preventScroll: true });
  }
  function closeDrawer() {
    const wasOpen = drawer.classList.contains('active');
    overlay.classList.remove('active');
    drawer.classList.remove('active');
    drawer.setAttribute('aria-hidden', 'true');
    drawer.inert = true;
    if (wasOpen) {
      const returnFocus = document.querySelector('[data-bottom-nav="tools"]') || btnOpen;
      if (returnFocus && returnFocus.getClientRects().length) returnFocus.focus({ preventScroll: true });
    }
  }

  // Keep keyboard and programmatic focus inside the modal drawer. Recompute
  // candidates for every Tab press because favourites can be added/removed live.
  function getDrawerFocusable() {
    return Array.from(drawer.querySelectorAll(
      'a[href], area[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )).filter(el => {
      // A tabindex alone does not make a control a valid focus destination:
      // WebViews can still report layout boxes for visibility:hidden nodes.
      if (el.hidden || el.matches(':disabled') || el.tabIndex < 0 || el.getAttribute('aria-hidden') === 'true') return false;
      if (el.closest('[hidden], [inert], [aria-hidden="true"]')) return false;
      if (!el.getClientRects().length) return false;
      const style = window.getComputedStyle ? window.getComputedStyle(el) : null;
      if (style && (style.visibility === 'hidden' || style.visibility === 'collapse' || style.display === 'none')) return false;
      return true;
    });
  }

  drawer.addEventListener('keydown', event => {
    if (event.key === 'Escape') {
      event.preventDefault();
      closeDrawer();
      return;
    }
    if (event.key !== 'Tab') return;
    const candidates = getDrawerFocusable();
    if (!candidates.length) {
      event.preventDefault();
      drawer.focus({ preventScroll: true });
      return;
    }
    const first = candidates[0];
    const last = candidates[candidates.length - 1];
    const active = document.activeElement;
    if (event.shiftKey && (active === first || active === drawer || !drawer.contains(active))) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && (active === last || active === drawer || !drawer.contains(active))) {
      event.preventDefault();
      first.focus();
    }
  });

  // WebViews and assistive technologies may move focus without a Tab key.
  // Redirect any such escape back into the open modal surface.
  document.addEventListener('focusin', event => {
    if (!drawer.classList.contains('active') || drawer.contains(event.target)) return;
    const first = getDrawerFocusable()[0];
    (first || drawer).focus({ preventScroll: true });
  });

  btnOpen.addEventListener('click', () => {
    if (STATE.currentScreen === 'tools') {
      openDrawer();
    } else if (STATE.currentScreen === 'settings') {
      switchScreen(STATE.previousScreen || 'calc');
    } else if (STATE.currentScreen !== 'calc') {
      switchScreen('calc');
    } else {
      openDrawer();
    }
  });
  overlay.addEventListener('click', closeDrawer);

  const btnCloseDrawer = document.getElementById('btn-drawer-close');
  if (btnCloseDrawer) btnCloseDrawer.addEventListener('click', closeDrawer);


  // Drawer utility actions: Help, Scientific, History and Settings. The old categorized tool list is replaced by the dedicated Tools screen.
  document.getElementById('btn-drawer-settings')?.addEventListener('click', () => { closeDrawer(); openSettingsScreen(); });

  document.getElementById('menu-help')?.addEventListener('click', () => {
    overlay.classList.remove('active');
    drawer.classList.remove('active');
    drawer.setAttribute('aria-hidden', 'true');
    drawer.inert = true;
    (document.querySelector('[data-bottom-nav="tools"]') || btnOpen).focus({ preventScroll: true });
    showHelpModal();
  });
}



// Bottom navigation mirrors the supplied native Android reference.
function updateBottomNavigation(screenId = STATE.currentScreen) {
  const primaryScreens = new Set(['calc', 'history', 'favorites', 'tools', 'settings']);
  const nav = document.getElementById('bottom-navigation');
  // The five primary destinations stay available on top-level screens only.
  // Individual calculators/converters get the full viewport and use Back/system navigation.
  if (nav) {
    nav.hidden = !primaryScreens.has(screenId);
    nav.setAttribute('aria-hidden', nav.hidden ? 'true' : 'false');
    nav.inert = nav.hidden;
  }
  const active = screenId === 'settings' ? 'settings'
    : screenId === 'tools' ? 'tools'
    : screenId === 'favorites' ? 'favorites'
    : screenId === 'calc' ? 'calc'
    : 'tools';
  document.querySelectorAll('[data-bottom-nav]').forEach(button => {
    const selected = button.dataset.bottomNav === active;
    button.classList.toggle('active', selected);
    if (selected) button.setAttribute('aria-current', 'page');
    else button.removeAttribute('aria-current');
  });
}
function renderFavoritesScreen() {
  const list = document.getElementById('favorites-screen-list');
  if (!list || !Array.isArray(STATE.favorites)) return;
  const items = ALL_CALC_ITEMS.filter(item => STATE.favorites.includes(item.id));
  list.replaceChildren();
  if (!items.length) {
    const empty = document.createElement('div');
    empty.className = 'favorites-empty';
    empty.textContent = 'No favorites yet. Add tools from Settings or the navigation menu.';
    list.appendChild(empty);
    return;
  }
  const fragment = document.createDocumentFragment();
  items.forEach((item, index) => {
    const button = document.createElement('button');
    button.type = 'button'; button.className = 'favorite-tool-card'; button.dataset.favoriteScreen = item.id;
    const icon = document.createElement('span'); icon.className = 'favorite-tool-icon'; icon.setAttribute('aria-hidden', 'true');
    icon.textContent = ['▦','💱','⇄','％','％','₹','⚖','▣','⛽','↗','★','#','₹','◷','％','⚖','◉'][index] || '▦';
    const name = document.createElement('strong'); name.textContent = item.name;
    const arrow = document.createElement('span'); arrow.className = 'favorite-tool-arrow'; arrow.textContent = '›';
    button.append(icon, name, arrow); fragment.appendChild(button);
  });
  list.appendChild(fragment);
}
function initBottomNavigation() {
  const nav = document.getElementById('bottom-navigation');
  if (!nav || nav.dataset.bound) return;
  nav.dataset.bound = 'true';
  nav.addEventListener('click', event => {
    const button = event.target.closest('[data-bottom-nav]');
    if (!button) return;
    const target = button.dataset.bottomNav;
    if (target === 'tools') { switchScreen('tools'); return; }
    if (target === 'history') { document.getElementById('btn-history-open')?.click(); return; }
    if (target === 'settings') { openSettingsScreen(); return; }
    switchScreen(target === 'favorites' ? 'favorites' : 'calc');
  });
  const favoritesList = document.getElementById('favorites-screen-list');
  favoritesList?.addEventListener('click', event => {
    const button = event.target.closest('[data-favorite-screen]');
    if (button) switchScreen(button.dataset.favoriteScreen);
  });
  document.getElementById('btn-header-history')?.addEventListener('click', () => {
    document.getElementById('btn-history-open')?.click();
  });
  document.getElementById('btn-tools-search')?.addEventListener('click', () => {
    if (STATE.currentScreen !== 'tools') switchScreen('tools');
    const input = document.getElementById('tools-screen-search');
    input?.focus({ preventScroll: true });
  });
  document.getElementById('btn-tools-more')?.addEventListener('click', () => document.getElementById('btn-drawer-open')?.click());
  const toolsGrid = document.getElementById('premium-tools-grid');
  toolsGrid?.addEventListener('click', event => {
    const card = event.target.closest('[data-tool-screen]');
    if (!card || !toolsGrid.contains(card)) return;
    const destination = card.dataset.toolScreen;
    if (destination === 'settings') openSettingsScreen();
    else switchScreen(destination);
  });
  const toolsSearch = document.getElementById('tools-screen-search');
  const toolsSearchClear = document.getElementById('tools-screen-search-clear');
  const categoryList = document.getElementById('tools-category-list');
  let activeToolCategory = 'all';
  const filterToolsScreen = () => {
    const query = String(toolsSearch?.value || '').trim().toLocaleLowerCase();
    let visible = 0;
    toolsGrid?.querySelectorAll('[data-tool-screen]').forEach(card => {
      const name = `${card.dataset.toolName || ''} ${card.dataset.toolScreen || ''} ${card.textContent || ''}`.toLocaleLowerCase();
      const queryMatch = !query || name.includes(query);
      const categoryMatch = activeToolCategory === 'all' || card.dataset.toolCategory === activeToolCategory;
      const match = queryMatch && categoryMatch;
      card.hidden = !match;
      if (match) visible += 1;
    });
    if (toolsSearchClear) toolsSearchClear.hidden = !query;
    const empty = document.getElementById('tools-empty-state');
    if (empty) empty.hidden = visible !== 0;
  };
  toolsSearch?.addEventListener('input', filterToolsScreen);
  toolsSearchClear?.addEventListener('click', () => { if (toolsSearch) { toolsSearch.value = ''; filterToolsScreen(); toolsSearch.focus(); } });
  toolsSearch?.addEventListener('keydown', event => {
    if (event.key === 'Escape') { toolsSearch.value = ''; filterToolsScreen(); toolsSearch.blur(); }
  });
  categoryList?.addEventListener('click', event => {
    const chip = event.target.closest('[data-tool-category]');
    if (!chip || !categoryList.contains(chip)) return;
    activeToolCategory = chip.dataset.toolCategory || 'all';
    categoryList.querySelectorAll('[data-tool-category]').forEach(item => {
      const active = item === chip;
      item.classList.toggle('active', active);
      item.setAttribute('aria-pressed', String(active));
    });
    filterToolsScreen();
  });
  updateBottomNavigation(STATE.currentScreen);
}

// ==========================================
// TRANSITION-GUARDED NAVIGATION & SETTINGS
// ==========================================
// Only the basic calculator keeps its keypad permanently visible. Every tool uses the shared on-demand keypad.
const PERMANENT_DOCKED_SCREENS = new Set(['calc']);
// Any numeric tool without its own permanent docked keypad uses the shared on-demand keypad.
// Keep the existing docked-keypad screens untouched; this fallback also covers future tools.

function applyTransitionGuard() {
  // Intentionally no global pointer lock: it swallowed rapid taps in Android WebView.
  document.body.classList.remove('transition-guard');
}

function openSettingsScreen() {
  applyTransitionGuard();
  const overlay = document.getElementById('drawer-overlay');
  const drawer = document.getElementById('sidebar-drawer');
  if (overlay) overlay.classList.remove('active');
  if (drawer) { drawer.classList.remove('active'); drawer.setAttribute('aria-hidden', 'true'); drawer.inert = true; }
  closePopupKeypad();
  switchScreen('settings');
  document.querySelector('[data-bottom-nav="settings"]')?.focus({ preventScroll: true });
}

function switchScreen(screenId) {
  if (screenId !== 'hex') closeHexKeyboard();
  const target = document.getElementById(`screen-${screenId}`);
  if (!target || !target.classList.contains('screen')) {
    showToast('Screen unavailable');
    return false;
  }
  applyTransitionGuard();
  const topLevelScreens = new Set(['calc', 'tools', 'favorites', 'settings']);
  if (screenId === 'settings') {
    if (STATE.currentScreen !== 'settings') STATE.previousScreen = STATE.currentScreen;
  } else if (topLevelScreens.has(screenId)) {
    STATE.previousScreen = screenId;
  } else if (topLevelScreens.has(STATE.currentScreen)) {
    // A tool opened from Home, Tools or Favorites returns to that exact surface.
    STATE.previousScreen = STATE.currentScreen;
  }
  if (screenId !== 'settings') {
    try { localStorage.setItem('sumaire_last_screen', screenId); } catch (error) {}
  }
  const outgoingScreen = document.getElementById(`screen-${STATE.currentScreen}`);
  const outgoingScroll = outgoingScreen?.querySelector('.calc-scrollable');
  if (outgoingScroll) STATE.screenScrollPositions[STATE.currentScreen] = outgoingScroll.scrollTop;
  STATE.currentScreen = screenId;
  closePopupKeypad();

  document.querySelectorAll('#screen-viewport > .screen').forEach(screen => {
    const active = screen === target;
    screen.classList.toggle('active', active);
    screen.setAttribute('aria-hidden', active ? 'false' : 'true');
    // Prevent hidden calculator controls/results from remaining visible or focusable
    // when an ID-specific CSS rule (for example #screen-calc) sets display:flex.
    if ('inert' in screen) screen.inert = !active;
  });
  const scrollContainer = target.querySelector('.calc-scrollable');
  if (scrollContainer) scrollContainer.scrollTop = Math.max(0, Number(STATE.screenScrollPositions[screenId]) || 0);

  // Update Drawer active highlight
  document.querySelectorAll('.drawer-item').forEach(i => {
    const isCurrent = i.getAttribute('data-screen') === screenId;
    i.classList.toggle('active', isCurrent);
    if (isCurrent) i.setAttribute('aria-current', 'page');
    else i.removeAttribute('aria-current');
  });

  // Title update
  const titles = {
    calc: 'SA Calculator',
    currencies: 'Currency Converter',
    units: 'Unit Converter',
    discount: 'Discount Calculator',
    percent: 'Percent Calculator',
    salestax: 'Sales Tax Calculator',
    bodymetrics: 'Body Metrics Calculator',
    date: 'Date Calculator',
    fuelcost: 'Fuel Cost Calculator',
    fuelefficiency: 'Fuel Efficiency',
    gradeavg: 'Grade Average',
    hex: 'Number Base Converter',
    loan: 'Loan / EMI Calculator',
    savings: 'Savings Calculator',
    tip: 'Tip Calculator',
    unitprice: 'Unit Price Calculator',
    worldtime: 'World Time Converter',
    settings: 'Settings',
    favorites: 'Favorites',
    tools: 'Tools',
    scientific: 'Scientific Calculator'
  };
  const translatedTitle = TRANSLATIONS?.[STATE.language]?.[screenId] || titles[screenId] || (screenId === 'calc' ? 'SA Calculator' : '');
  setElementText('app-title', screenId === 'calc' || screenId === 'tools' ? 'SA Calculator' : translatedTitle);
  document.body.classList.toggle('tool-screen-active', screenId !== 'calc' && screenId !== 'tools');
  document.body.classList.toggle('tools-screen-active', screenId === 'tools');
  if (screenId !== 'calc' && screenId !== 'tools') {
    let toolbar = target.querySelector(':scope > .reference-screen-toolbar');
    if (!toolbar) {
      toolbar = document.createElement('div');
      toolbar.className = 'reference-screen-toolbar';
      const back = document.createElement('button');
      back.type = 'button'; back.className = 'reference-screen-back'; back.setAttribute('aria-label', 'Back to previous screen'); back.textContent = '‹';
      back.addEventListener('click', () => switchScreen(STATE.previousScreen || 'calc'));
      const title = document.createElement('strong'); title.className = 'reference-screen-title';
      const more = document.createElement('button'); more.type = 'button'; more.className = 'reference-screen-more'; more.setAttribute('aria-label', 'Browse tools'); more.textContent = '▦';
      more.addEventListener('click', () => switchScreen('tools'));
      toolbar.append(back, title, more);
      target.insertBefore(toolbar, target.firstChild);
    }
    const titleNode = toolbar.querySelector('.reference-screen-title');
    if (titleNode) titleNode.textContent = translatedTitle;
  }
  updateBottomNavigation(screenId);
  if (screenId === 'favorites') renderFavoritesScreen();

  // Header Back Arrow vs Drawer Hamburger icon
  const btnDrawer = document.getElementById('btn-drawer-open');
  if (screenId === 'settings' || screenId === 'tools') {
    btnDrawer.textContent = '←'; // Left Arrow
    btnDrawer.setAttribute('title', 'Back to Calculator');
  } else if (screenId === 'calc') {
    btnDrawer.textContent = '☰';
    btnDrawer.setAttribute('title', 'Open tools menu');
  } else {
    btnDrawer.textContent = '←';
    btnDrawer.setAttribute('title', 'Back to Calculator');
  }


  // Tool screens intentionally start with no selected field and no keyboard.
  // The shared keypad opens only after the user taps an editable numeric field.
  if (screenId !== 'calc') setActiveInput(null);
  recalculateScreen(screenId);
  if (typeof fitAllToolResults === 'function') requestAnimationFrame(() => fitAllToolResults(target));
  return true;
}

// ==========================================
// POPUP ON-DEMAND KEYPAD CONTROLLER
// ==========================================
let currentPopupTarget = null;

function openPopupKeypad(inputElem) {
  if (!inputElem || !inputElem.isConnected || !(inputElem.classList.contains('input-val-box') || inputElem.matches('input[type="number"].gpa-credits'))) return;
  currentPopupTarget = inputElem;
  setActiveInput(inputElem);

  const overlay = document.getElementById('popup-keypad-overlay');
  const sheet = document.getElementById('popup-keypad-sheet');
  const titleElem = document.getElementById('popup-sheet-title');
  const fieldNameElem = document.getElementById('popup-field-name');
  const valDisplay = document.getElementById('popup-val-display');
  sheet.dataset.keypadContext = inputElem.id || 'generic';

  // Stable concise labels for converter amount fields. Do not derive labels from
  // select wrappers: their textContent includes every option in the native select,
  // which caused the complete unit/currency inventory to leak into the keypad UI.
  const converterLabels = {
    'unit-input-val': 'Value',
    'cur-amount': 'Amount',
    'cur-to-amount': 'Converted amount'
  };
  const explicitConverterLabel = converterLabels[inputElem.id] || '';

  // Resolve only the label belonging to this exact field; never borrow a sibling field label.
  const row = inputElem.closest('.input-row, .input-group, .form-row, .calc-field');
  const directLabel = inputElem.querySelector('.input-label, label, [data-field-label]');
  let rowLabel = row ? row.querySelector('.input-label, label, [data-field-label]') : null;
  if (!rowLabel && row) {
    // Some older tool rows use a plain leading span/div instead of .input-label.
    rowLabel = Array.from(row.children).find(node => node !== inputElem &&
      !node.classList.contains('input-val-box') &&
      !node.matches('input,select,textarea,button') &&
      !node.querySelector('select, option, input, textarea, button') &&
      node.textContent.trim());
  }
  let label = explicitConverterLabel || (directLabel || rowLabel)?.textContent?.trim().replace(/\s+/g, ' ').replace(/:$/, '') || '';
  if (!label && inputElem.classList.contains('gpa-credits')) {
    const courseName = row?.querySelector('input[type="text"]')?.value?.trim();
    label = courseName ? `${courseName} credits` : 'Course credits';
  }
  if (!label) label = inputElem.getAttribute('data-label') || inputElem.getAttribute('aria-label') || inputElem.getAttribute('placeholder') || '';
  if (!label) {
    const knownLabels = {
      'loan-p': 'Loan principal', 'loan-r': 'Interest rate', 'loan-m': 'Loan period (months)', 'loan-grace': 'Interest-only period',
      'sav-p': 'Deposit amount', 'sav-r': 'Interest rate', 'sav-tax': 'Interest income tax', 'sav-m': 'Savings period (years)',
      'tip-pct': 'Tip percentage', 'disc-orig': 'Original price', 'disc-pct': 'Discount percentage',
      'disc-extra': 'Additional discount', 'disc-tax': 'Added tax', 'tax-rate': 'Tax rate', 'pct-x': 'Percentage',
      'bmi-age': 'Age', 'bmi-height': 'Height', 'bmi-weight': 'Weight', 'fc-dist': 'Distance',
      'fc-eff': 'Fuel efficiency', 'fc-price': 'Fuel price', 'fe-before': 'Fuel before refueling', 'fe-after': 'Fuel after refueling', 'fe-added': 'Refueled gasoline', 'fe-dist': 'Distance traveled',
      'loan-p': 'Loan principal', 'loan-r': 'Interest rate', 'loan-m': 'Loan period (months)', 'loan-grace': 'Interest-only period',
      'sav-p': 'Deposit amount', 'sav-r': 'Interest rate', 'sav-m': 'Savings period (years)', 'sav-tax': 'Interest income tax',
      'tip-bill': 'Bill amount', 'tip-people': 'Number of people', 'tip-pct': 'Tip percentage', 'tip-tax': 'Tax amount',
      'up-p-a': 'Product A price', 'up-q-a': 'Product A quantity', 'up-p-b': 'Product B price', 'up-q-b': 'Product B quantity',
      'up-p-c': 'Product C price', 'up-q-c': 'Product C quantity', 'unit-input-val': 'Value', 'cur-amount': 'Amount'
    };
    label = knownLabels[inputElem.id] || inputElem.id.replace(/^(loan|sav|disc|bmi|fuel|unit|cur)-/, '').replace(/[-_]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase()) || 'Enter value';
  }
  label = label.replace(/^Input$/i, 'Enter value');
  titleElem.textContent = label || 'Enter value';
  fieldNameElem.textContent = `${label || 'Enter value'}:`;
  const textElem = inputElem.querySelector('.input-text');
  const initialValue = textElem ? textElem.textContent : (inputElem.matches('input') ? inputElem.value : inputElem.textContent);
  valDisplay.textContent = String(initialValue || '0').trim().replace(/[$%]/g, '') || '0';

  overlay.style.pointerEvents = 'auto';
  sheet.style.pointerEvents = 'auto';
  overlay.classList.add('active');
  sheet.classList.add('active');
  overlay.setAttribute('aria-hidden', 'false');
  sheet.setAttribute('aria-hidden', 'false');
  sheet.setAttribute('role', 'dialog');
  sheet.setAttribute('aria-modal', 'true');
}

function closePopupKeypad() {
  const overlay = document.getElementById('popup-keypad-overlay');
  const sheet = document.getElementById('popup-keypad-sheet');
  if (overlay) { overlay.classList.remove('active'); overlay.setAttribute('aria-hidden', 'true'); overlay.style.pointerEvents = 'none'; }
  if (sheet) { sheet.classList.remove('active'); sheet.setAttribute('aria-hidden', 'true'); sheet.style.pointerEvents = 'none'; delete sheet.dataset.keypadContext; }
  if (currentPopupTarget) currentPopupTarget.classList.remove('active');
  document.querySelectorAll('.input-val-box.next-ready, .gpa-credits.next-ready').forEach(el => el.classList.remove('next-ready'));
  currentPopupTarget = null;
  if (STATE.activeInputTarget && !STATE.activeInputTarget.classList.contains('active')) STATE.activeInputTarget = null;
}

function handlePopupKey(key) {
  triggerHaptic();
  if (!currentPopupTarget || !currentPopupTarget.isConnected) { closePopupKeypad(); return; }
  const valDisplay = document.getElementById('popup-val-display');
  let val = valDisplay.textContent.trim().replace(/[$%]/g, '');

  if (key === 'CLR') {
    val = '0';
  } else if (key === 'DEL') {
    val = val.length > 1 ? val.slice(0, -1) : '0';
  } else if (key === 'DONE') {
    closePopupKeypad();
    return;
  } else if (key === 'NEXT') {
    const inputs = Array.from(document.querySelectorAll(`#screen-${STATE.currentScreen} .input-val-box, #screen-${STATE.currentScreen} input[type="number"].gpa-credits`)).filter(el => el.offsetParent !== null);
    const idx = inputs.indexOf(currentPopupTarget);
    if (idx !== -1 && idx < inputs.length - 1) {
      openPopupKeypad(inputs[idx + 1]);
    } else {
      closePopupKeypad();
    }
    return;
  } else {
    const isCurrency = STATE.currentScreen === 'currencies';
    const nextValue = appendLimitedNumericKey(val, key, 15, isCurrency ? 4 : Infinity);
    if (nextValue === val) return;
    val = nextValue;
  }

  valDisplay.textContent = val;

  // Sync to actual input element in the active screen
  let finalVal = val;
  if (['disc-pct','disc-extra','disc-tax','pct-x','tax-rate','loan-r','sav-r','sav-tax','tip-pct'].includes(currentPopupTarget.id)) {
    finalVal = val + '%';
  }
  if (currentPopupTarget.matches('input[type="number"].gpa-credits')) {
    currentPopupTarget.value = finalVal;
    currentPopupTarget.dispatchEvent(new Event('input', { bubbles: true }));
    currentPopupTarget.dispatchEvent(new Event('change', { bubbles: true }));
  } else {
    const textSpan = currentPopupTarget.querySelector('.input-text');
    if (textSpan) {
      textSpan.textContent = finalVal;
    } else {
      const valueNode = document.createElement('span');
      valueNode.className = 'input-text';
      valueNode.textContent = finalVal;
      const cursorNode = document.createElement('span');
      cursorNode.className = 'input-cursor';
      currentPopupTarget.replaceChildren(valueNode, cursorNode);
    }
    recalculateCurrentScreen();
  }
  persistPreviousInputs();
}

// ROUTING CLICK ON INPUT BOXES (DOCKED VS POPUP)
function initKeypads() {
  // Keep transient keypad layers INSIDE the app stacking context. In V19.6 they
  // were siblings of #app-container while #app-container used isolation:isolate;
  // a child header z-index could therefore never rise above the root-level keypad.
  // Android WebView hit-testing then sent hamburger taps to the keypad instead.
  const appRoot = document.getElementById('app-container');
  const popupOverlay = document.getElementById('popup-keypad-overlay');
  const popupSheet = document.getElementById('popup-keypad-sheet');
  if (appRoot && popupOverlay && popupOverlay.parentElement !== appRoot) appRoot.appendChild(popupOverlay);
  if (appRoot && popupSheet && popupSheet.parentElement !== appRoot) appRoot.appendChild(popupSheet);

  // Capture navigation gestures before bubbling handlers. This is important on mobile WebViews:
  // the transient keypad must never survive a route/menu action or intercept the next screen.
  const navigationHit = '#btn-drawer-open, #btn-drawer-close, #drawer-overlay, #sidebar-drawer .drawer-item, #menu-help';
  const dismissForNavigation = (event) => {
    const target = event.target && (event.target.nodeType === 1 ? event.target : event.target.parentElement);
    if (target && target.closest && target.closest(navigationHit)) closePopupKeypad();
  };
  // Prefer Pointer Events on modern Android/WebView. Registering both pointer
  // and touch handlers on the same target can fire the same interaction twice
  // on hybrid WebViews, which is especially noticeable when opening the
  // transient keypad. Fall back to touch only on engines without PointerEvent.
  const supportsPointerEvents = typeof window !== 'undefined' && 'PointerEvent' in window;
  if (supportsPointerEvents) {
    document.addEventListener('pointerdown', dismissForNavigation, true);
  } else {
    document.addEventListener('touchstart', dismissForNavigation, { capture: true, passive: true });
  }
  document.addEventListener('click', dismissForNavigation, true);
  // Escape mirrors the Android system Back action for the transient keypad.
  window.addEventListener('popstate', () => {
    if (currentPopupTarget) closePopupKeypad();
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && currentPopupTarget) {
      e.preventDefault();
      closePopupKeypad();
    }
  });

  const findNumericPopupTarget = target => target?.closest?.('.input-val-box, input[type="number"].gpa-credits');
  const openNativeNumericPopup = event => {
    const input = event.target?.closest?.('input[type="number"].gpa-credits');
    if (!input || !document.getElementById(`screen-${STATE.currentScreen}`)?.contains(input)) return;
    event.preventDefault();
    openPopupKeypad(input);
  };
  if (supportsPointerEvents) {
    document.addEventListener('pointerdown', openNativeNumericPopup, true);
  } else {
    document.addEventListener('touchstart', openNativeNumericPopup, { capture: true, passive: false });
  }

  document.addEventListener('click', (e) => {
    const input = findNumericPopupTarget(e.target);
    if (!input) return;

    if (input.matches('input[type="number"].gpa-credits')) {
      e.preventDefault();
      e.stopPropagation();
      openPopupKeypad(input);
      return;
    }

    if (STATE.currentScreen === 'calc') {
      closePopupKeypad();
      setActiveInput(input);
    } else {
      // One consistent, on-demand keypad for every tool. Never show it on entry.
      e.preventDefault();
      e.stopPropagation();
      openPopupKeypad(input);
    }
  });

  // Docked Keypad clicks
  document.querySelectorAll('.dock-keypad').forEach(keypad => {
    keypad.addEventListener('click', (e) => {
      const btn = e.target.closest('.key-btn');
      if (!btn) return;
      const key = btn.getAttribute('data-num');
      handleKeypadInput(key);
    });
  });

  // Popup Keypad clicks
  document.querySelectorAll('[data-popup]').forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      const key = btn.getAttribute('data-popup');
      handlePopupKey(key);
    });
  });
}

function setActiveInput(elem) {
  const allInputs = Array.from(document.querySelectorAll(`#screen-${STATE.currentScreen} .input-val-box, #screen-${STATE.currentScreen} .gpa-credits`));
  allInputs.forEach(el => el.classList.remove('active', 'next-ready'));
  if (!elem) {
    STATE.activeInputTarget = null;
    return;
  }
  elem.classList.add('active');
  STATE.activeInputTarget = elem;

  // Give the next editable field a quiet, theme-aware ready state. This is
  // intentionally distinct from the active typing state and never uses a
  // browser-default white focus fill.
  const visibleInputs = allInputs.filter(el => el.offsetParent !== null && !el.disabled && el.getAttribute('aria-disabled') !== 'true');
  const index = visibleInputs.indexOf(elem);
  if (index >= 0 && index < visibleInputs.length - 1) {
    visibleInputs[index + 1].classList.add('next-ready');
  }
}

function handleKeypadInput(key) {
  triggerHaptic();
  if (!STATE.activeInputTarget) return;
  const textElem = STATE.activeInputTarget.querySelector('.input-text') || STATE.activeInputTarget;
  let val = (STATE.currentScreen === 'currencies' && STATE.activeInputTarget.dataset.currencyRaw && STATE.activeInputTarget.getAttribute('data-derived') === 'true' ? STATE.activeInputTarget.dataset.currencyRaw : textElem.textContent).trim().replace(/[$%]/g, '').replace(/,/g, '');
  if (STATE.currentScreen === 'currencies' && STATE.activeInputTarget.getAttribute('data-derived') === 'true' && ['CLR','DEL','PM','-','+'].includes(key)) {
    STATE.activeInputTarget.removeAttribute('data-derived');
    delete STATE.activeInputTarget.dataset.currencyRaw;
  }

  if (key === 'CLR') {
    val = '0';
  } else if (key === 'DEL') {
    val = val.length > 1 ? val.slice(0, -1) : '0';
  } else if (key === 'NEXT' || key === 'PREV') {
    const inputs = Array.from(document.querySelectorAll(`#screen-${STATE.currentScreen} .input-val-box`)).filter(el => el.offsetParent !== null);
    const idx = inputs.indexOf(STATE.activeInputTarget);
    if (inputs.length) setActiveInput(inputs[(idx + (key === 'NEXT' ? 1 : -1) + inputs.length) % inputs.length]);
    return;
  } else if (key === 'SWAP') {
    if (STATE.currentScreen === 'currencies' || STATE.currentScreen === 'units') {
      const from=document.getElementById(STATE.currentScreen==='currencies'?'cur-from':'unit-from');
      const to=document.getElementById(STATE.currentScreen==='currencies'?'cur-to':'unit-to');
      if(from&&to){
        const tmp=from.value; from.value=to.value; to.value=tmp;
        if(STATE.currentScreen==='currencies'){
          const fromAmount=document.getElementById('cur-amount');
          const toAmount=document.getElementById('cur-to-amount');
          if(fromAmount&&toAmount){
            const a=getCurrencyAmountRaw('cur-amount'), b=getCurrencyAmountRaw('cur-to-amount');
            setCurrencyAmountRaw('cur-amount',b,false); setCurrencyAmountRaw('cur-to-amount',a,false);
          }
          calcCurrency();
        } else calcUnits();
      }
    } else if (STATE.currentScreen === 'percent') {
      const active=document.querySelector('[data-percent-mode].active');
      const next=active?.dataset.percentMode==='change'?'of':'change';
      document.querySelector(`[data-percent-mode="${next}"]`)?.click();
    }
    return;
  } else if (key === 'PM' || key === '-' || key === '+') {
    if (key === '+') val = val.startsWith('-') ? val.slice(1) : val;
    else val = val.startsWith('-') ? val.slice(1) : `-${val}`;
  } else if (key === 'DONE') {
    // Re-evaluate
  } else {
    // Currency dual-edit parity: the calculated opposite field is replaced
    // by the first typed digit, exactly like a fresh Unit Converter value.
    if (STATE.currentScreen === 'currencies' && STATE.activeInputTarget?.getAttribute('data-derived') === 'true') {
      val = '0';
      STATE.activeInputTarget.removeAttribute('data-derived');
      delete STATE.activeInputTarget.dataset.currencyRaw;
    }
    const nextValue = appendLimitedNumericKey(val, key, 15);
    if (nextValue === val) return;
    val = nextValue;
  }

  // Restore units if present
  let finalVal = val;
  if (['disc-pct','disc-extra','disc-tax','pct-x','tax-rate','loan-r','sav-r','sav-tax','tip-pct'].includes(STATE.activeInputTarget.id)) {
    finalVal = val + '%';
  }
  const textSpan = STATE.activeInputTarget.querySelector('.input-text');
  if (textSpan) {
    textSpan.textContent = finalVal;
  } else {
    const valueNode = document.createElement('span');
    valueNode.className = 'input-text';
    valueNode.textContent = finalVal;
    const cursorNode = document.createElement('span');
    cursorNode.className = 'input-cursor';
    STATE.activeInputTarget.replaceChildren(valueNode, cursorNode);
  }

  recalculateCurrentScreen();
  // Refit size-sensitive tool UI only after the screen becomes measurable.
  // Hidden-screen calculations otherwise run with clientWidth=0 and can leave
  // currency values at an oversized font on the first frame after navigation.
  if (screenId === 'currencies') {
    const refitCurrency = () => {
      try { fitCurrencyDisplays(); } catch (error) {}
    };
    requestAnimationFrame(() => requestAnimationFrame(refitCurrency));
  }
  persistPreviousInputs();
}

function recalculateCurrentScreen() {
  recalculateScreen(STATE.currentScreen);
}

function recalculateScreen(screenId) {
  switch (screenId) {
    case 'calc': updateCalcDisplayDOM(); break;
    case 'currencies': calcCurrency(); break;
    case 'units': calcUnits(); break;
    case 'discount': calcDiscount(); break;
    case 'percent': calcPercent(); break;
    case 'salestax': calcSalesTax(); break;
    case 'bodymetrics': calcBodyMetrics(); break;
    case 'date': renderDateEvents(); break;
    case 'fuelcost': calcFuelCost(); break;
    case 'fuelefficiency': calcFuelEfficiency(); break;
    case 'gradeavg': calcGpa(); break;
    case 'hex': renderHexValues(); break;
    case 'loan': calcLoan(); break;
    case 'savings': calcSavings(); break;
    case 'tip': calcTip(); break;
    case 'unitprice': calcUnitPrice(); break;
    case 'worldtime': updateWorldTimeLive(); break;
  }
}

// 1. STANDARD & SCIENTIFIC CALCULATOR LOGIC
// SUMAIRE EXACT FORMULA & LIVE PREVIEW ENGINE
// Restricted arithmetic parser. Never execute calculator input as JavaScript.
// Scientific notation accepts an exponent-only shorthand: e20 means 1e20.
// The `e` key is an exponent-entry marker, not Euler's constant; a bare `e`
// is intentionally an incomplete/invalid expression and evaluates to Error.
function normalizeStandaloneScientificEntry(expression) {
  return String(expression ?? '');
}

function isScientificEntryExpression(expression) {
  const source = String(expression ?? '').replace(/\s+/g, '');
  return /^(?:[+−-]?(?:\d+(?:\.\d*)?|\.\d+)?)[eE][+−-]?\d+$/.test(source) ||
    /^(?:[+−-]?\d+(?:\.\d*)?|\.\d+)[eE][+−-]?\d+$/.test(source);
}

function formatScientificEntryDisplay(value) {
  const numeric = Number(value);
  if (!Number.isFinite(numeric)) return 'Error';
  // A scientific mantissa is always one integer digit plus at most six
  // fractional digits, regardless of whether it came from entry, preview,
  // equals, a continued expression, or a radical result.
  const scientific = numeric.toExponential(6);
  const match = scientific.match(/^([+-]?(?:\d+(?:\.\d+)?))e([+-]?\d+)$/i);
  if (!match) return String(numeric);
  const mantissa = match[1].replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '');
  const exponent = Number(match[2]);
  return `${mantissa}×10${toSuperscriptExponent(exponent)}`;
}

function evaluateArithmetic(expression, allowImplicitMultiplication = true, angleMode = 'deg') {
  // Keep the calculator's visible radical glyphs in the editor while mapping
  // them to the parser's internal function names only during evaluation.
  // Radical glyphs are first-class prefix operators. Keep them visible in
  // expressions (√9, ∛27, √(9+7)); never require sqrt()/cbrt() text.
  const source = normalizeStandaloneScientificEntry(normalizeScientificExpressionGlyphs(expression))
    .replace(/π/g, 'pi')
    .replace(/log₂/g, 'log2')
    .replace(/sin⁻¹/g, 'asin').replace(/cos⁻¹/g, 'acos').replace(/tan⁻¹/g, 'atan')
    .replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-')
    .replace(/\s+/g, '')
    // `e` followed directly by an exponent is calculator scientific notation:
    // e2 means 1×10², e-3 means 1×10⁻³. A mantissa form such as 2e3 is
    // already a numeric token and remains untouched. Bare `e` is not a
    // mathematical constant in this calculator and is rejected by the parser.
    // Preserve the existing pi2 shorthand as implicit multiplication.
    .replace(/(^|[^a-zA-Z0-9])pi(?=\d|\.)/gi, (match, prefix) => allowImplicitMultiplication ? `${prefix}pi*` : match)
    .replace(/(\d)pi(?=\d|\.)/gi, (match, digit) => allowImplicitMultiplication ? `${digit}*pi*` : match)
    .replace(/(^|[^a-zA-Z0-9])e([+−-]?\d+)(?![a-zA-Z0-9])/gi, (match, prefix, exponent) => `${prefix}1e${exponent.replace('−','-')}`)
    .replace(/(^|[^a-zA-Z0-9])e(?=\.)/gi, (match, prefix) => allowImplicitMultiplication ? `${prefix}e*` : match);
  if (!source || source.length > 250) throw new Error('Invalid expression length');

  const tokens = source.match(/(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?|[a-zA-Z][a-zA-Z0-9]*|[√∛()+\-*/^%!]/g) || [];
  if (!tokens.length || tokens.join('') !== source) throw new Error('Invalid expression');
  // Two numeric literals may never touch without an operator. Without this
  // guard malformed decimals such as `1..2` were tokenized as `1.` and `.2`,
  // then mistaken for implicit multiplication (0.2). Implicit multiplication
  // remains available for number/constant/group/function adjacency.
  const isNumericLiteral = token => /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/i.test(String(token ?? ''));
  for (let i = 1; i < tokens.length; i++) {
    if (isNumericLiteral(tokens[i - 1]) && isNumericLiteral(tokens[i])) {
      throw new Error('Invalid numeric literal');
    }
  }
  // Bound parser work before recursive descent; malformed deep input must fail cleanly.
  if (tokens.length > 150) throw new Error('Expression is too complex');
  let depth = 0;
  for (const token of tokens) {
    if (token === '(' && ++depth > 60) throw new Error('Expression is too deeply nested');
    if (token === ')' && --depth < 0) throw new Error('Invalid expression');
  }
  if (depth !== 0) throw new Error('Invalid expression');

  // Normalize calculator-style implicit multiplication without splitting scientific notation.
  // Supported adjacency includes 2(3), (2)3, (2)(3), 2pi, 2sin(30), pi(2),
  // pi2, (2)pi and sin(2)cos(3). Function-name + '(' remains a function call.
  const expanded = [];
  const isNumber = token => token !== undefined && /^(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?$/i.test(token);
  const functionNames = new Set(['log','ln','log2','sqrt','cbrt','abs','sin','cos','tan','asin','acos','atan','sinh','cosh','tanh','fact']);
  const isValueToken = token => isNumber(token) || token === 'pi' || token === ')';
  const isValueStart = (token, nextToken) => isNumber(token) || token === 'pi' || token === '(' || token === '√' || token === '∛' || (functionNames.has(String(token || '').toLowerCase()) && nextToken === '(');
  for (let i = 0; i < tokens.length; i++) {
    const cur = tokens[i];
    const prev = expanded[expanded.length - 1];
    if (allowImplicitMultiplication && isValueToken(prev) && isValueStart(cur, tokens[i + 1])) expanded.push('*');
    expanded.push(cur);
  }

  let index = 0;
  const peek = () => expanded[index];
  const take = () => expanded[index++];
  const finite = n => {
    if (!Number.isFinite(n)) throw new Error('Non-finite result');
    return n;
  };
  // Preserve the full round-trippable IEEE-754 value during arithmetic.
  // Rounding intermediates to 15 digits loses meaningful low-order changes
  // (for example, a +1 continuation on a 3.8e15 result). The display layer
  // independently rounds to the requested 12 significant digits.
  const stableArithmeticResult = n => finite(Number(finite(n).toPrecision(17)));

  const resultValue = value => ({ value: finite(value), isPercent: false });

  function applyScientificFunction(name, value) {
    const deg = angleMode === 'deg' ? Math.PI / 180 : 1;
    const invDeg = angleMode === 'deg' ? 180 / Math.PI : 1;
    let out;
    switch (name.toLowerCase()) {
      case 'log': out = Math.log10(value); break;
      case 'ln': out = Math.log(value); break;
      case 'log2': out = Math.log2(value); break;
      case 'sqrt': out = Math.sqrt(value); break;
      case 'cbrt': out = Math.cbrt(value); break;
      case 'abs': out = Math.abs(value); break;
      case 'sin': out = Math.sin(value * deg); break;
      case 'cos': out = Math.cos(value * deg); break;
      case 'tan': { const a=value*deg; out=Math.abs(Math.cos(a))<1e-12?NaN:Math.tan(a); break; }
      case 'asin': out = Math.asin(value) * invDeg; break;
      case 'acos': out = Math.acos(value) * invDeg; break;
      case 'atan': out = Math.atan(value) * invDeg; break;
      case 'sinh': out = Math.sinh(value); break;
      case 'cosh': out = Math.cosh(value); break;
      case 'tanh': out = Math.tanh(value); break;
      case 'fact': { if(!Number.isInteger(value)||value<0||value>170)return NaN; out=1; for(let i=2;i<=value;i++)out*=i; break; }
      default: throw new Error('Unknown function');
    }
    return finite(out);
  }
  function primary() {
    const token = take();
    if (token === '(') {
      const value = addSub();
      if (take() !== ')') throw new Error('Missing closing parenthesis');
      return value;
    }
    if (token === 'pi') return resultValue(Math.PI);
    if (/^[a-z][a-z0-9]*$/i.test(token || '')) {
      if (take() !== '(') throw new Error('Function requires parentheses');
      const arg = addSub();
      if (take() !== ')') throw new Error('Missing function parenthesis');
      return resultValue(applyScientificFunction(token, arg.value));
    }
    if (!isNumber(token)) throw new Error('Expected number');
    return resultValue(Number(token));
  }

  // Percent and factorial are postfix operators.
  function postfix() {
    let result = primary();
    while (peek() === '%' || peek() === '!') {
      const op = take();
      if (op === '%') result = { value: finite(result.value / 100), isPercent: true };
      else result = resultValue(applyScientificFunction('fact', result.value));
    }
    return result;
  }

  // Exponentiation is right-associative and binds tighter than a leading unary sign.
  function power() {
    const left = postfix();
    if (peek() === '^') {
      take();
      const right = unary();
      return resultValue(Math.pow(left.value, right.value));
    }
    return left;
  }

  function unary() {
    if (peek() === '+') { take(); return unary(); }
    if (peek() === '-') {
      take();
      const value = unary();
      return { value: finite(-value.value), isPercent: value.isPercent };
    }
    if (peek() === '√' || peek() === '∛') {
      const radical = take();
      const degree = radical === '√' ? 2 : 3;
      // Evaluate a leading radical over a power without first materializing
      // the potentially overflowing radicand. For example, ∛(9^966) is
      // representable even though 9^966 is not a finite IEEE-754 Number.
      // Parsing the base and exponent separately preserves normal power
      // precedence and avoids turning a valid final result into Error.
      // Support both compact and conventional parenthesized forms. A common
      // scientific-calculator input is `∛(9^966)`: evaluating the parenthesized
      // power first overflows even though the final root is representable.
      // Detect a simple signed-base integer/decimal power inside the matching
      // parentheses and apply the root to the exponent before materializing it.
      if (peek() === '(') {
        let close = index + 1, nesting = 1, caret = -1;
        for (; close < expanded.length && nesting > 0; close++) {
          const token = expanded[close];
          if (token === '(') nesting++;
          else if (token === ')') nesting--;
          else if (token === '^' && nesting === 1) {
            if (caret !== -1) { caret = -2; break; }
            caret = close;
          }
        }
        if (nesting === 0 && caret > 0) {
          const left = expanded.slice(index + 1, caret);
          const right = expanded.slice(caret + 1, close - 1);
          const signedNumeric = parts => {
            let sign = 1, offset = 0;
            if (parts[0] === '-') { sign = -1; offset = 1; }
            else if (parts[0] === '+') offset = 1;
            if (parts.length !== offset + 1 || !isNumber(parts[offset])) return null;
            return sign * Number(parts[offset]);
          };
          const base = signedNumeric(left), exponent = signedNumeric(right);
          if (base !== null && exponent !== null) {
            if (base < 0 && degree === 2) throw new Error('Invalid radical domain');
            const rooted = base < 0 ? -Math.pow(-base, exponent / degree) : Math.pow(base, exponent / degree);
            index = close;
            return resultValue(rooted);
          }
        }
      }
      if (peek() !== '(') {
        let sign = 1;
        if (peek() === '-') { take(); sign = -1; }
        else if (peek() === '+') take();
        const base = primary();
        const signedBase = sign * base.value;
        if (peek() === '^') {
          take();
          const exponent = unary();
          if (signedBase < 0 && degree === 2) throw new Error('Invalid radical domain');
          const rootedBase = signedBase < 0 ? -Math.pow(-signedBase, exponent.value / degree) :
            Math.pow(signedBase, exponent.value / degree);
          return resultValue(rootedBase);
        }
        return resultValue(applyScientificFunction(degree === 2 ? 'sqrt' : 'cbrt', signedBase));
      }
      const operand = unary();
      return resultValue(applyScientificFunction(degree === 2 ? 'sqrt' : 'cbrt', operand.value));
    }
    return power();
  }

  function mulDiv() {
    let result = unary();
    while (peek() === '*' || peek() === '/') {
      const op = take();
      const right = unary();
      result = resultValue(op === '*' ? stableArithmeticResult(result.value * right.value) : result.value / right.value);
    }
    return result;
  }

  function addSub() {
    let result = mulDiv();
    while (peek() === '+' || peek() === '-') {
      const op = take();
      const right = mulDiv();
      const rightValue = right.isPercent ? result.value * right.value : right.value;
      result = resultValue(stableArithmeticResult(op === '+' ? result.value + rightValue : result.value - rightValue));
    }
    return result;
  }

  const result = addSub();
  if (index !== expanded.length) throw new Error('Unexpected token');
  return finite(result.value);
}

function getCalculatorRepeatOperation(expression) {
  const source = normalizeScientificExpressionGlyphs(expression).replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-');
  let depth = 0;
  let candidate = -1;
  for (let i = 0; i < source.length; i++) {
    const ch = source[i];
    if (ch === '(') { depth++; continue; }
    if (ch === ')') { depth--; continue; }
    if (depth !== 0 || !/[+\-*/^]/.test(ch)) continue;
    const previous = source[i - 1] || '';
    // A sign immediately after e/E belongs to a scientific-notation exponent,
    // not to the repeatable binary operation. Example: 1e-3 = 0.001; pressing
    // equals again must not incorrectly repeat `- 3`.
    if ((ch === '+' || ch === '-') && /[eE]/.test(previous) && /\d/.test(source[i + 1] || '')) continue;
    if (i === 0 || /[+\-*/^(]/.test(previous)) continue; // unary sign
    candidate = i;
  }
  if (candidate < 0) return null;
  const operator = source[candidate];
  const rhs = source.slice(candidate + 1);
  if (!rhs) return null;
  try {
    // Validate the repeat operand now so an incomplete expression cannot
    // become a sticky repeat operation.
    evaluateArithmetic(rhs, STATE.implicitMult);
    return { operator, rhs };
  } catch (_) { return null; }
}

function calculatorErrorMessage(error) {
  const message = String(error?.message || '').toLowerCase();
  if (message.includes('non-finite') || message.includes('range') || message.includes('division')) return 'Result is outside the calculator range';
  if (message.includes('parenthesis')) return 'Check the parentheses in your expression';
  if (message.includes('function')) return 'Check the scientific function and its input';
  if (message.includes('invalid') || message.includes('expected') || message.includes('unexpected') || message.includes('requires')) return 'Check the expression and try again';
  if (message.includes('incomplete')) return 'Complete the scientific exponent';
  return 'This calculation cannot be completed';
}

function isLivePreviewIncompleteExpression(expression) {
  const source = String(expression ?? '').trim();
  if (!source) return true;
  // Do not turn normal typing states into scary errors: a trailing binary
  // operator, an unfinished scientific exponent, or an unfinished function
  // call is still being edited. The preview remains blank until the operation
  // is evaluable or has a definite mathematical error.
  if (/[+−×÷*/^]\s*$/.test(source)) return true;
  if (/(?:^|[0-9.])[eE][+−-]?\s*$/.test(source) && !/^e$/i.test(source)) return true;
  if (/(?:sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|log|ln|log₂|√|∛)\s*$/i.test(source)) return true;
  if (/[(]\s*$/.test(source)) return true;
  return false;
}

function normalizedCalcExpression(exprStr) {
  let source = String(exprStr || '');
  const continuation = STATE.calcScientificContinuation;
  if (continuation && continuation.displayToken) {
    // A committed scientific result can be continued directly (`token+1`)
    // or wrapped by a scientific function (`√(token)`, `sin(token)`). Replace
    // only the exact untouched display token, wherever it appears, so the
    // hidden full-precision value survives both workflows.
    const token = String(continuation.displayToken);
    if (token && source.includes(token) && Number.isFinite(Number(continuation.exactValue))) {
      source = source.split(token).join(String(continuation.exactValue));
    } else if (token && !source.includes(token)) {
      // The user edited/deleted the visible token. Do not let stale metadata
      // silently affect a later, unrelated expression.
      STATE.calcScientificContinuation = null;
    }
  }
  let clean = normalizeStandaloneScientificEntry(normalizeScientificExpressionGlyphs(source)).replace(/×/g, '*').replace(/÷/g, '/').replace(/−/g, '-').trim();
  while (clean && ['+', '-', '*', '/', '.', '^'].includes(clean.slice(-1))) clean = clean.slice(0, -1).trim();
  if (!clean) return '';
  const open = (clean.match(/\(/g) || []).length;
  const close = (clean.match(/\)/g) || []).length;
  if (open > close) clean += ')'.repeat(open - close);
  return clean;
}

function hasBinaryCalculatorOperator(expression) {
  const source = normalizeScientificExpressionGlyphs(expression).replace(/\s+/g, '');
  let depth = 0;
  for (let i = 0; i < source.length; i++) {
    const ch = source[i];
    if (ch === '(') { depth++; continue; }
    if (ch === ')') { depth = Math.max(0, depth - 1); continue; }
    if (!/[+−×÷*/^]/.test(ch)) continue;
    const previous = source[i - 1] || '';
    // The sign inside a parser-safe scientific exponent (e+15/e-8) is part
    // of the number, not a binary operator that should activate live preview.
    if ((ch === '+' || ch === '-') && /[eE]/.test(previous) && /\d/.test(source[i + 1] || '')) continue;
    // Leading signs and signs immediately after another operator or '(' are
    // unary; they must not activate a preview for a lone numeric operand.
    if (i === 0 || /[+−×÷*/^(]/.test(previous)) continue;
    return true;
  }
  return false;
}

function calculatorExpressionHasDefiniteSyntaxError(expression) {
  const source = String(expression ?? '').trim();
  if (!source) return false;
  const compact = source.replace(/\s+/g, '');

  // A scientific-key function is an explicit operation. Once its opening
  // parenthesis is present but no operand has been entered yet, the preview
  // must not disappear: show the same visible Error state used by other
  // parser failures. This covers `cos(`, `2cos(`, `sin(`, `sqrt(`, etc.
  if (/^(?:sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|log|ln|log₂|abs|fact|sqrt|cbrt)\($/i.test(compact)) return true;
  if (/(?:^|[0-9.πe)])(?:sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|log|ln|log₂|abs|fact|sqrt|cbrt)\($/i.test(compact)) return true;

  // Detect malformed/unknown identifiers early. The parser is intentionally
  // strict, but the old preview gate only recognized valid function names,
  // which made errors such as `c2os(`, `co2s(`, `sinn(` and `cos2` silently
  // blank. Every parser-visible identifier failure must now surface as Error.
  const identifierPattern = /[A-Za-z][A-Za-z0-9]*/g;
  const allowedFunctions = new Set(['log','ln','log2','sin','cos','tan','asin','acos','atan','sinh','cosh','tanh','abs','fact','sqrt','cbrt']);
  let identifierMatch;
  while ((identifierMatch = identifierPattern.exec(compact))) {
    const id = identifierMatch[0];
    const lower = id.toLowerCase();
    if (lower === 'e') continue; // scientific exponent marker / legacy constant entry
    if (!allowedFunctions.has(lower)) return true;
    // Validate the exact occurrence, not the first occurrence of the same
    // function name. This catches `sin(2)+sin2` and similar split failures.
    const after = compact.slice(identifierMatch.index + id.length);
    // Every named scientific function in this calculator requires `(`.
    if (after[0] !== '(') return true;
  }

  // Malformed numeric literals should never become an invisible preview. The
  // tokenizer rejects these, so the preview should expose that rejection too.
  if (/(?:\d|\.)\.{1,}/.test(compact)) return true;
  if (/[0-9.]e[+−-]?$/i.test(compact)) return true;
  if (/[0-9.]e[+−-]?[^0-9.]/i.test(compact)) return true;

  // A stray closing parenthesis is a definite parser error; an opening
  // parenthesis is allowed to remain temporarily incomplete for ordinary
  // grouping, preserving the calculator's normal live-preview behavior.
  let depth = 0;
  for (const ch of compact) {
    if (ch === '(') depth++;
    else if (ch === ')' && --depth < 0) return true;
  }
  return false;
}

function hasPreviewableCalculatorOperation(expression) {
  const source = String(expression ?? '').trim();
  if (!source) return false;
  // IMPORTANT: syntax failures are previewable states. Never gate them behind
  // recognition of a valid operator/function, otherwise errors such as
  // `c2os(` have no route to the visible Error renderer.
  if (calculatorExpressionHasDefiniteSyntaxError(source)) return true;
  // Constants and exponent-entry shorthand are previewable on their own.
  // A bare `e` is intentionally previewable so the evaluator can show Error.
  if (/^(?:π|e)$/i.test(source)) return true;
  // A radical is itself a complete mathematical operation. Unlike a lone
  // numeric operand, √2 / ∛8 must show a live preview before the user presses
  // equals. Binary expressions retain their existing preview behavior.
  return hasBinaryCalculatorOperator(source) || /[√∛%!]/.test(source) ||
    /(?:sin|cos|tan|asin|acos|atan|sinh|cosh|tanh|log|ln|log₂|abs|fact|sqrt|cbrt)\s*\(/i.test(source) ||
    /(?:π|[0-9.]+[eE][+−-]?\d+|e[+−-]?\d+)/.test(source);
}

function evaluateLiveExpression(exprStr) {
  const source = String(exprStr ?? '').trim();
  if (!source) return '';
  // The explicit error-preview flag is a UI state and must win before any
  // previewability gate. This prevents a scientific-key error from becoming
  // invisible simply because the expression is not a valid operation token.
  // A forced scientific-panel error is valid only for the exact expression
  // that triggered it. This prevents a stale flag from turning a later valid
  // number into Error merely because the caret moved or a deletion completed.
  if (isForcedScientificErrorPreview(source)) return 'Error';
  if (!hasPreviewableCalculatorOperation(source)) return '';
  // π is a supported constant. `e` is only an exponent-entry marker, so a
  // bare marker must flow through the parser and render the same Error state
  // as '=' rather than silently becoming Euler's constant.
  if (/^π$/i.test(source)) return formatCalculatorExpressionResult(source, Math.PI);
  if (isLivePreviewIncompleteExpression(exprStr)) {
    // A trailing operator is intentionally normalized to preview the completed
    // left side (`9×` → `9`). Other incomplete entry states stay quiet.
    try {
      const clean = normalizedCalcExpression(exprStr);
      if (!clean) return '';
      const result = evaluateArithmetic(clean, STATE.implicitMult);
      return formatCalculatorExpressionResult(exprStr, result);
    } catch (_) {
      // Definite syntax/domain failures must remain visible even while the
      // expression is still being edited. In particular, `cos(` and similar
      // unfinished scientific calls are errors, not blank preview states.
      return calculatorExpressionHasDefiniteSyntaxError(exprStr) ? 'Error' : '';
    }
  }
  try {
    const clean = normalizedCalcExpression(exprStr);
    if (!clean) return '';
    const result = evaluateArithmetic(clean, STATE.implicitMult);
    return formatCalculatorExpressionResult(exprStr, result);
  } catch (error) {
    // Live preview must expose definite mathematical/syntax failures instead
    // of silently disappearing. This keeps the preview authoritative while the
    // expression is still editable; `=` continues to use the same evaluator.
    // The calculator's preview contract is intentionally minimal: mathematical
    // failures render only `Error`, never a second diagnostic sentence. The
    // detailed reason remains internal for debugging/accessibility state.
    return 'Error';
  }
}

function getCalcEditor() { return document.getElementById('calc-expr'); }

// Scientific results such as `1.380878 × 10¹⁹⁵` are one mathematical number.
// The superscript exponent is metadata of that number, not an independent
// operand. Keep the visible scientific token atomic during editing so a caret
// or Backspace can never detach `195` and turn it into a standalone `195`.
const CALC_SCIENTIFIC_SUPERSCRIPT_RE = /[⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+/;
function getScientificDisplayTokenRanges(expression) {
  const source = String(expression ?? '');
  const ranges = [];
  const pattern = /[+-]?(?:\d+(?:\.\d*)?|\.\d+)\s*×\s*10[⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+/g;
  let match;
  while ((match = pattern.exec(source))) {
    ranges.push({ start: match.index, end: match.index + match[0].length });
  }
  return ranges;
}

function getScientificDisplayTokenAt(expression, start, end = start) {
  const ranges = getScientificDisplayTokenRanges(expression);
  for (const range of ranges) {
    // A collapsed caret strictly inside the token belongs to the token.
    // At the exact boundaries the caller may intentionally append/prepend.
    if (start === end) {
      if (start > range.start && start < range.end) return range;
      continue;
    }
    // Any selection that intersects the token expands to the whole token.
    if (start < range.end && end > range.start) return range;
  }
  return null;
}

function getScientificDeletionRange(expression, start, end, direction = 'backward') {
  const source = String(expression ?? '');
  const selected = getScientificDisplayTokenAt(source, start, end);
  if (selected) return selected;
  if (start !== end) return null;
  if (direction === 'backward') {
    const left = getScientificDisplayTokenRanges(source).find(range => range.end === start);
    if (left) return left;
  } else {
    const right = getScientificDisplayTokenRanges(source).find(range => range.start === start);
    if (right) return right;
  }
  return null;
}

function syncCalcSelectionFromEditor(force = false) {
  const editor = getCalcEditor();
  if (!editor || (!force && document.activeElement !== editor)) return;
  const start = Number.isFinite(editor.selectionStart) ? editor.selectionStart : String(editor.value || '').length;
  const end = Number.isFinite(editor.selectionEnd) ? editor.selectionEnd : start;
  STATE.calcCursor = start;
  STATE.calcSelectionStart = start;
  STATE.calcSelectionEnd = end;
  STATE.calcSelectionDirection = editor.selectionDirection || 'none';
}
function setCalcEditorSelection(start, end = start, focus = false, direction = STATE.calcSelectionDirection || 'none') {
  const editor = getCalcEditor();
  if (!editor) return;
  const length = editor.value.length;
  const a = Math.max(0, Math.min(length, Number(start) || 0));
  const b = Math.max(a, Math.min(length, Number(end) || 0));
  const safeDirection = direction === 'backward' || direction === 'forward' ? direction : 'none';
  STATE.calcCursor = a;
  STATE.calcSelectionStart = a;
  STATE.calcSelectionEnd = b;
  STATE.calcSelectionDirection = safeDirection;
  if (focus) editor.focus({preventScroll:true});
  try { editor.setSelectionRange(a, b, safeDirection); } catch (_) {}
  // This helper is used only after an intentional programmatic selection
  // change. Ordinary taps, arrow keys and native typing are left to WebView.
  revealCalculatorEditorCaret(editor, { restoreSelection: true });
  scheduleCalculatorExpressionRightAnchor(editor);
}

function revealCalculatorEditorCaret(editor = getCalcEditor(), options = {}) {
  if (!editor || editor.readOnly || document.activeElement !== editor) return;
  const restoreSelection = options.restoreSelection === true;
  const reveal = () => {
    if (!editor.isConnected || editor.readOnly || document.activeElement !== editor) return;
    // Read the live selection at execution time. Never use a captured caret
    // index: Android keyboards can update it between input and animation frame.
    const value = String(editor.value ?? '');
    const start = Math.max(0, Math.min(value.length, Number.isFinite(editor.selectionStart) ? editor.selectionStart : value.length));
    const end = Math.max(start, Math.min(value.length, Number.isFinite(editor.selectionEnd) ? editor.selectionEnd : start));
    const direction = editor.selectionDirection === 'backward' || editor.selectionDirection === 'forward'
      ? editor.selectionDirection : 'none';

    // The browser's native text-control selection algorithm scrolls the focus
    // endpoint into view. Reapply only after programmatic font/layout changes;
    // never calculate or overwrite scrollLeft during native touch/typing.
    if (restoreSelection) {
      try { editor.setSelectionRange(start, end, direction); } catch (_) {}
    }
    STATE.calcCursor = start;
    STATE.calcSelectionStart = start;
    STATE.calcSelectionEnd = end;
    STATE.calcSelectionDirection = direction;
  };
  reveal();
  if (restoreSelection && typeof window.requestAnimationFrame === 'function') {
    if (window.__sumaireCaretRevealFrame) window.cancelAnimationFrame?.(window.__sumaireCaretRevealFrame);
    window.__sumaireCaretRevealFrame = window.requestAnimationFrame(() => {
      window.__sumaireCaretRevealFrame = 0;
      reveal();
    });
  }
}
/* Let the native single-line text control reveal its own caret.  Manually
   assigning scrollLeft on a right-aligned control is browser-dependent and was
   the source of the repeated right-edge drift.  Only ask the platform to
   re-evaluate the current end-caret after a layout change; never override a
   middle caret or selection. */
function scheduleCalculatorExpressionRightAnchor(editor = getCalcEditor()) {
  // LEFT-GROWTH DISPLAY CONTRACT:
  // The expression viewport is right-anchored. When the expression becomes
  // wider than the display, the newest/right edge stays fixed and the older
  // characters are revealed toward the LEFT. This is deliberately enforced
  // even when the caret is in the middle, because Android/WebView can otherwise
  // move scrollLeft back toward the caret and make the expression appear to
  // grow from the wrong side.
  if (!editor || editor.isConnected === false || editor.readOnly) return;

  const reveal = () => {
    if (editor.isConnected === false || editor.readOnly) return;
    try {
      const maxScroll = Math.max(0, editor.scrollWidth - editor.clientWidth);
      // In LTR WebView, maxScroll is the stable right-edge position. Keeping
      // this value after layout prevents the viewport from drifting right/left
      // between successive keypad taps, font-size changes, and previews.
      editor.scrollLeft = maxScroll;
      // A second assignment after layout is intentional: Android WebView may
      // restore the native caret scroll position one frame after input.
      if (editor.scrollLeft !== maxScroll) editor.scrollLeft = maxScroll;
    } catch (_) {}
  };

  if (typeof window !== 'undefined' && typeof window.requestAnimationFrame === 'function') {
    if (window.__sumaireExprAnchorFrame) window.cancelAnimationFrame?.(window.__sumaireExprAnchorFrame);
    window.__sumaireExprAnchorFrame = window.requestAnimationFrame(() => {
      window.__sumaireExprAnchorFrame = 0;
      reveal();
      if (typeof window.requestAnimationFrame === 'function') {
        window.__sumaireExprAnchorFrame = window.requestAnimationFrame(() => {
          window.__sumaireExprAnchorFrame = 0;
          reveal();
        });
      }
    });
  } else {
    reveal();
  }
}

function toSuperscriptExponent(exponent) {
  const map = {'-':'⁻','0':'⁰','1':'¹','2':'²','3':'³','4':'⁴','5':'⁵','6':'⁶','7':'⁷','8':'⁸','9':'⁹'};
  return String(exponent).split('').map(ch => map[ch] || ch).join('');
}
function compactScientificDisplay(value, fractionalDigits = 6) {
  const numeric = Number(String(value).replace(/[ ,]/g, ''));
  if (!Number.isFinite(numeric) || numeric === 0) return String(value);
  const digits = Math.max(0, Math.min(6, Number(fractionalDigits) || 0));
  const parts = numeric.toExponential(digits).split('e');
  const mantissa = parts[0].replace(/(\.\d*?[1-9])0+$/, '$1').replace(/\.0+$/, '');
  return `${mantissa} × 10${toSuperscriptExponent(Number(parts[1]))}`;
}

function measureCalculatorTextFit(valEl, text, maxSize, minSize, width) {
  valEl.textContent = String(text);
  valEl.style.whiteSpace = 'nowrap';
  valEl.style.overflowWrap = 'normal';
  valEl.style.fontSize = `${maxSize}px`;
  const fitsAt = size => {
    valEl.style.fontSize = `${size}px`;
    return valEl.scrollWidth <= width + 0.5;
  };
  if (fitsAt(maxSize)) return maxSize;
  if (!fitsAt(minSize)) return 0;

  // Binary search avoids the repeated layout/reflow work of decrementing one
  // pixel at a time, while still selecting the largest whole-pixel size.
  let low = minSize;
  let high = maxSize - 1;
  while (low < high) {
    const middle = Math.ceil((low + high) / 2);
    if (fitsAt(middle)) low = middle;
    else high = middle - 1;
  }
  fitsAt(low);
  return low;
}

function fitCalculatorResult(valEl) {
  if (!valEl || valEl.isConnected === false) return;

  // In committed-result mode the primary expression row owns the result.
  // Never render the same canonical value into the secondary live-preview
  // row; doing so caused the old preview to remain visibly duplicated under
  // results such as `6.642...`, `Error`, and scientific outputs.
  const isResult = !!STATE.isResultMode;
  if (isResult) {
    valEl.textContent = '';
    valEl.__sumaireCanonicalText = '';
    valEl.classList.remove('is-preview-error');
    valEl.setAttribute('aria-label', 'Live preview');
    valEl.style.removeProperty('font-size');
    valEl.style.removeProperty('--calc-preview-fitted-size');
    valEl.style.removeProperty('white-space');
    valEl.style.removeProperty('overflow-x');
    valEl.style.removeProperty('display');
    return;
  }

  const canonical = String(valEl.__sumaireCanonicalText ?? valEl.textContent ?? '');
  valEl.__sumaireCanonicalText = canonical;
  if (valEl.setAttribute) valEl.setAttribute('aria-label', canonical ? `Calculation value: ${canonical}` : '');

  // Keep the canonical value in state/history; render scientific notation
  // as ×10 with superscript exponent for calculator-style readability.
  const displayText = canonical.replace(
    /^([+-]?(?:\d+(?:\.\d*)?|\.\d+))[eE]([+-]?\d+)$/,
    (_, mantissa, exponent) => `${mantissa} × 10${toSuperscriptExponent(Number(exponent))}`
  );
  const rectWidth = valEl.getBoundingClientRect ? valEl.getBoundingClientRect().width : 0;
  const width = valEl.clientWidth || rectWidth || 0;
  if (!width) {
    valEl.textContent = displayText;
    return;
  }

  const maxSize = isResult ? 62 : 28;
  const minSize = isResult ? 24 : 16;
  const rawSize = measureCalculatorTextFit(valEl, displayText, maxSize, minSize, width);
  if (rawSize) {
    // Share the exact measured preview font size with the error-state CSS.
    // This keeps 'Error' identical in scale to any normal live-preview value.
    valEl.style.setProperty('--calc-preview-fitted-size', `${rawSize}px`);
    valEl.style.fontSize = `${rawSize}px`;
    valEl.style.whiteSpace = 'nowrap';
    valEl.style.overflowWrap = 'normal';
    valEl.style.wordBreak = 'normal';
    return;
  }

  // Reduce only visible significant digits when a compact notation still
  // cannot fit; the canonical calculation value is never modified.
  const candidates = [6, 4, 3, 1].map(digits => compactScientificDisplay(canonical, digits));
  for (const candidate of [...new Set(candidates)]) {
    if (!candidate || candidate === canonical) continue;
    const size = measureCalculatorTextFit(valEl, candidate, maxSize, minSize, width);
    if (size) {
      valEl.style.fontSize = `${size}px`;
      valEl.style.whiteSpace = 'nowrap';
      valEl.style.overflowWrap = 'normal';
      valEl.style.wordBreak = 'normal';
      return;
    }
  }

  // Extremely narrow embeds scroll the compact output horizontally instead
  // of wrapping exponent characters or silently clipping them.
  const emergency = candidates[candidates.length - 1] || displayText;
  valEl.textContent = emergency;
  valEl.style.setProperty('--calc-preview-fitted-size', `${minSize}px`);
  valEl.style.fontSize = `${minSize}px`;
  valEl.style.whiteSpace = 'nowrap';
  valEl.style.overflowWrap = 'normal';
  valEl.style.wordBreak = 'normal';
  valEl.style.maxWidth = '100%';
  valEl.style.overflowX = 'auto';
  valEl.style.display = 'block';
}

function measureCalculatorExpressionWidth(editor, text, fontSize) {
  const value = String(text ?? '');
  const size = Math.max(1, Number(fontSize) || 16);
  let computed = null;
  try { computed = window.getComputedStyle ? window.getComputedStyle(editor) : null; } catch (_) {}
  const fontFamily = computed?.fontFamily || editor?.style?.fontFamily || 'sans-serif';
  const fontWeight = computed?.fontWeight || editor?.style?.fontWeight || '400';
  const fontStyle = computed?.fontStyle || editor?.style?.fontStyle || 'normal';
  const fontVariant = computed?.fontVariant || editor?.style?.fontVariant || 'normal';
  const letterSpacing = computed?.letterSpacing || editor?.style?.letterSpacing || '0px';

  // Measure with the browser's own text layout engine, not only canvas metrics.
  // Canvas can under/over-estimate fallback glyphs and Android WebView font metrics,
  // which is precisely how the final character could touch or cross the edge.
  try {
    if (document.body && document.createElement) {
      let probe = window.__sumaireExpressionWidthProbe;
      if (!probe) {
        probe = document.createElement('span');
        probe.setAttribute('aria-hidden', 'true');
        probe.style.cssText = 'position:fixed;left:-10000px;top:-10000px;display:inline-block;visibility:hidden;white-space:pre;contain:layout style;pointer-events:none;padding:0;border:0;margin:0;';
        document.body.appendChild(probe);
        window.__sumaireExpressionWidthProbe = probe;
      }
      probe.textContent = value || ' ';
      probe.style.fontFamily = fontFamily;
      probe.style.fontWeight = fontWeight;
      probe.style.fontStyle = fontStyle;
      probe.style.fontVariant = fontVariant;
      probe.style.fontSize = `${size}px`;
      probe.style.letterSpacing = letterSpacing;
      const rect = probe.getBoundingClientRect();
      if (rect && Number.isFinite(rect.width) && rect.width > 0) return rect.width + 1.5;
    }
  } catch (_) {}

  // Canvas fallback for restricted WebViews. Reuse a single canvas per page.
  try {
    const canvas = window.__sumaireExpressionMeasureCanvas ||
      (window.__sumaireExpressionMeasureCanvas = document.createElement('canvas'));
    const context = canvas && canvas.getContext && canvas.getContext('2d');
    if (context) {
      context.font = `${fontStyle} ${fontVariant} ${fontWeight} ${size}px ${fontFamily}`;
      const spacing = Number.parseFloat(letterSpacing) || 0;
      return context.measureText(value).width + Math.max(0, value.length - 1) * spacing + 1.5;
    }
  } catch (_) {}
  return value.length * size * 0.62 + 1.5;
}

function fitCalculatorExpression() {
  const row = document.getElementById('calc-expr-row');
  const editor = getCalcEditor();
  if (!row || !editor) return;

  // A committed answer is rendered in the primary expression field. Fit the
  // complete visible value to the row on every resize/font/layout pass; never
  // let the native input's horizontal scrolling hide the leading digits.
  if (STATE.isResultMode) {
    // Lock the committed answer to the exact primary expression row. Inline
    // important styles deliberately override legacy result-mode CSS rules
    // that used to hide this row and promote the lower preview row.
    const displayBox = document.getElementById('calc-display-box');
    if (displayBox) displayBox.style.setProperty('justify-content', 'flex-start', 'important');
    row.style.setProperty('display', 'flex', 'important');
    row.style.setProperty('margin-top', '0', 'important');
    row.style.setProperty('flex', '0 0 auto', 'important');
    row.style.setProperty('align-self', 'stretch', 'important');
    row.style.setProperty('position', 'absolute', 'important');
    row.style.setProperty('left', '25px', 'important');
    row.style.setProperty('right', '25px', 'important');
    row.style.setProperty('width', 'auto', 'important');
    row.style.setProperty('margin-left', '0', 'important');
    row.style.setProperty('margin-right', '0', 'important');
    row.style.setProperty('padding-left', '0', 'important');
    row.style.setProperty('padding-right', '0', 'important');
    row.style.setProperty('box-sizing', 'border-box', 'important');
    row.style.setProperty('visibility', 'visible', 'important');
    row.style.setProperty('opacity', '1', 'important');
    const previewRow = document.getElementById('calc-preview-row');
    // A committed result owns the primary row exclusively. This applies to
    // both successful answers and Error: the preview is only an editing-time
    // surface, so pressing = must visibly promote Error into the result row
    // without leaving a duplicate diagnostic/preview underneath it.
    if (previewRow) {
      previewRow.style.setProperty('display', 'none', 'important');
      previewRow.style.setProperty('visibility', 'hidden', 'important');
      previewRow.style.setProperty('height', '0', 'important');
      previewRow.style.setProperty('min-height', '0', 'important');
      previewRow.style.setProperty('margin', '0', 'important');
      previewRow.style.setProperty('padding', '0', 'important');
    }
    const canonical = String(STATE.calcVal ?? '0');
    const availableWidth = Math.max(0, row.clientWidth || editor.clientWidth || 0);
    const px = value => Number.parseFloat(value) || 0;
    let style = null;
    try { style = window.getComputedStyle ? window.getComputedStyle(editor) : null; } catch (_) {}
    const insets = style
      ? px(style.paddingLeft) + px(style.paddingRight) + px(style.borderLeftWidth) + px(style.borderRightWidth)
      : 0;
    // The row itself already ends exactly 25px before the display boundary.
    // Do not subtract a second visual gutter from the measured text width.
    const usableWidth = Math.max(0, availableWidth - insets);
    const plain = canonical.replace(/^([+-]?(?:\d+(?:\.\d*)?|\.\d+))[eE]([+-]?\d+)$/, (_, m, e) => `${m} × 10${toSuperscriptExponent(Number(e))}`);
    const candidates = [plain];
    const numeric = Number(canonical.replace(/[ ,]/g, ''));
    if (Number.isFinite(numeric) && numeric !== 0 && plain === canonical) {
      // Try progressively shorter scientific display strings only when the
      // complete decimal form cannot fit. STATE.calcVal remains untouched,
      // so this is a display-only precision adaptation, never a calculation.
      for (const significantDigits of [7, 5, 4, 2]) {
        const exp = numeric.toExponential(significantDigits - 1)
          .replace(/(\.\d*?[1-9])0+e/, '$1e').replace(/\.0+e/, 'e');
        const parts = exp.split('e');
        const candidate = `${parts[0]} × 10${toSuperscriptExponent(Number(parts[1]))}`;
        if (!candidates.includes(candidate)) candidates.push(candidate);
      }
    }
    let chosenText = candidates[0];
    let chosenSize = 18;
    // Match the editable expression's exact font-size range and fit policy.
    // Identical text in the same 25px-gutter row therefore resolves to the
    // same font size before and after '=' (unless display-only notation
    // compaction is required to preserve the complete visible answer).
    const maxSize = 62;
    const minSize = 40;
    let fitted = false;
    for (const candidate of candidates) {
      const measuredAtMin = measureCalculatorExpressionWidth(editor, candidate, minSize);
      if (measuredAtMin > usableWidth && candidate === candidates[0]) continue;
      let low = minSize, high = maxSize;
      if (measureCalculatorExpressionWidth(editor, candidate, high) <= usableWidth) low = high;
      else if (measuredAtMin <= usableWidth) {
        while (high - low > 0.25) {
          const mid = (low + high) / 2;
          if (measureCalculatorExpressionWidth(editor, candidate, mid) <= usableWidth) low = mid;
          else high = mid;
        }
      }
      if (measureCalculatorExpressionWidth(editor, candidate, low) <= usableWidth) {
        chosenText = candidate;
        chosenSize = Math.max(minSize, Math.floor(low * 2) / 2);
        fitted = true;
        break;
      }
    }
    // Extremely narrow embeds: keep the complete value available through
    // horizontal scrolling rather than clipping it outside the screen.
    if (!fitted) {
      chosenText = candidates[candidates.length - 1];
      chosenSize = minSize;
    }
    if (editor.value !== chosenText) editor.value = chosenText;
    editor.setAttribute('aria-label', `Calculation result: ${canonical}`);
    editor.style.setProperty('font-size', `${chosenSize}px`, 'important');
    editor.style.setProperty('height', '100%', 'important');
    editor.style.setProperty('min-height', '0', 'important');
    editor.style.setProperty('max-height', '100%', 'important');
    editor.style.setProperty('position', 'relative', 'important');
    editor.style.setProperty('width', '100%', 'important');
    editor.style.setProperty('min-width', '0', 'important');
    editor.style.setProperty('max-width', '100%', 'important');
    editor.style.setProperty('flex', '0 0 100%', 'important');
    editor.style.setProperty('margin-left', '0', 'important');
    editor.style.setProperty('margin-right', '0', 'important');
    editor.style.setProperty('padding-left', '0', 'important');
    editor.style.setProperty('padding-right', '0', 'important');
    editor.style.setProperty('text-indent', '0', 'important');
    editor.style.setProperty('box-sizing', 'border-box', 'important');
    editor.style.setProperty('white-space', 'pre', 'important');
    editor.style.setProperty('overflow-x', fitted ? 'hidden' : 'auto', 'important');
    editor.style.setProperty('overflow-y', 'hidden', 'important');
    editor.style.setProperty('text-overflow', 'clip', 'important');
    editor.style.setProperty('text-align', 'right', 'important');
    editor.style.setProperty('text-align-last', 'right', 'important');
    editor.style.setProperty('direction', 'ltr', 'important');
    editor.style.setProperty('transform', 'none', 'important');
    editor.style.setProperty('line-height', '1.12', 'important');
    row.style.setProperty('overflow', 'hidden', 'important');
    row.style.setProperty('min-width', '0', 'important');
    row.style.setProperty('width', 'auto', 'important');
    return;
  }

  const computed = (() => {
    try { return window.getComputedStyle ? window.getComputedStyle(editor) : null; }
    catch (_) { return null; }
  })();
  const px = value => Number.parseFloat(value) || 0;
  const rowStyle = (() => {
    try { return window.getComputedStyle ? window.getComputedStyle(row) : null; }
    catch (_) { return null; }
  })();
  const rowInsets = rowStyle
    ? px(rowStyle.paddingLeft) + px(rowStyle.paddingRight) + px(rowStyle.borderLeftWidth) + px(rowStyle.borderRightWidth)
    : 0;
  const editorInsets = computed
    ? px(computed.paddingLeft) + px(computed.paddingRight) + px(computed.borderLeftWidth) + px(computed.borderRightWidth)
    : 0;
  // Measure against the ROW, not editor.clientWidth. Measuring the editor
  // itself creates a feedback loop after its width is reduced to content size.
  const availableWidth = Math.max(0, (row.clientWidth || editor.clientWidth || 0) - rowInsets);
  const expressionText = String(editor.value ?? STATE.calcExpr ?? '');
  const maxFont = 62;
  const minFont = 40;
  let chosenFont = maxFont;
  // The row is physically inset by exactly 25px on both sides. The editor
  // fills that row and is left-aligned; do not add another hidden text gutter.
  const maxContentWidth = Math.max(0, availableWidth - editorInsets);

  editor.setAttribute?.('type', 'text');
  editor.setAttribute?.('aria-multiline', 'false');
  editor.style.whiteSpace = 'pre';
  editor.style.overflowWrap = 'normal';
  editor.style.wordBreak = 'normal';
  editor.style.overflowY = 'hidden';
  editor.style.overflowX = 'auto';
  editor.style.maxHeight = 'none';

  const widthAt = size => measureCalculatorExpressionWidth(editor, expressionText, size);
  const naturalMaxWidth = widthAt(maxFont);
  if (expressionText && availableWidth > 0 && naturalMaxWidth > maxContentWidth) {
    if (widthAt(minFont) > maxContentWidth) {
      chosenFont = minFont;
    } else {
      // Find the largest font that keeps the complete expression inside the
      // display. At the 40px readability floor, stop shrinking and allow native scroll.
      let low = minFont;
      let high = maxFont;
      while (high - low > 0.25) {
        const mid = (low + high) / 2;
        if (widthAt(mid) <= maxContentWidth) low = mid;
        else high = mid;
      }
      chosenFont = Math.max(minFont, Math.floor(low * 2) / 2);
    }
  }

  const measuredWidth = expressionText ? measureCalculatorExpressionWidth(editor, expressionText, chosenFont) : 0;
  const expressionOverflows = availableWidth > 0 && measuredWidth > maxContentWidth + 0.5;
  // Keep the editable field spanning the whole display. Right alignment pins
  // the newest input to the right boundary; as text grows, earlier characters
  // extend left. Native caret scrolling still owns focused middle-caret edits.
  const targetEditorWidth = Math.max(1, availableWidth || measuredWidth);

  const expressionRowHeight = Math.max(38, Math.ceil(chosenFont * 1.18 + 5));
  const rowHeight = `${expressionRowHeight}px`;
  row.style.setProperty?.('--calc-expression-row-height', rowHeight);
  editor.style.setProperty?.('--calc-expression-row-height', rowHeight);

  const previousFontSize = Number.parseFloat(editor.style.fontSize) || (computed ? px(computed.fontSize) : 0);
  const previousWidth = Number.parseFloat(editor.style.width) || editor.clientWidth || 0;
  editor.style.fontSize = `${chosenFont}px`;
  const setImportant = (name, value) => editor.style.setProperty ? editor.style.setProperty(name, value, 'important') : (editor.style[name] = value);
  // Keep the editor's viewport fixed to the full available row width.
  // A content-sized input (or auto left margin) can make the visual text box
  // drift right as its measured content width changes between keystrokes.
  setImportant('width', '100%');
  setImportant('min-width', '0');
  setImportant('max-width', '100%');
  setImportant('flex', '1 1 100%');
  setImportant('margin-left', '0');
  setImportant('margin-right', '0');
  setImportant('text-align', 'right');
  setImportant('text-align-last', 'right');
  setImportant('direction', 'ltr');
  setImportant('unicode-bidi', 'normal');
  editor.style.transition = 'none';
  editor.style.lineHeight = '1.12';
  editor.style.height = rowHeight;
  editor.style.minHeight = rowHeight;
  editor.style.maxHeight = rowHeight;
  row.style.display = 'flex';
  row.style.alignItems = 'center';
  row.style.justifyContent = 'flex-end';
  row.style.direction = 'ltr';
  row.style.height = rowHeight;
  row.style.minHeight = rowHeight;
  row.style.maxHeight = rowHeight;
  row.style.overflow = 'hidden';

  const editorClasses = editor.classList;
  const rowClasses = row.classList;
  const wasOverflowing = !!(editorClasses?.contains?.('is-overflowing'));
  editorClasses?.toggle?.('is-overflowing', expressionOverflows);
  rowClasses?.toggle?.('is-overflowing', expressionOverflows);

  // The editor fills the row and is right-anchored. Native selection controls
  // scrolling when text exceeds the row, without overriding middle-caret edits.
  const geometryChanged = Math.abs(previousFontSize - chosenFont) > 0.1 || Math.abs(previousWidth - targetEditorWidth) > 1 || wasOverflowing !== expressionOverflows;
  if (geometryChanged && document.activeElement === editor && !editor.readOnly) {
    revealCalculatorEditorCaret(editor, { restoreSelection: true });
  }
  // Exact reference behavior: always re-apply the right-edge viewport after
  // every fit pass. This is the behavior from the first working ZIP and is
  // intentionally independent of caret position or geometry-change detection.
  scheduleCalculatorExpressionRightAnchor(editor);
}

function scheduleCalculatorResultFit() {
  if (window.__sumaireCalcFitFrame) return;
  const run = () => {
    window.__sumaireCalcFitFrame = 0;
    fitCalculatorExpression();
    fitCalculatorResult(document.getElementById('calc-val'));
  };
  if (typeof window.requestAnimationFrame === 'function') {
    window.__sumaireCalcFitFrame = window.requestAnimationFrame(run);
  } else {
    run();
  }
}
function updateCalcDisplayDOM(restoreCaret = true) {
  const displayBox = document.getElementById('calc-display-box');
  const exprEl = getCalcEditor();
  const valEl = document.getElementById('calc-val');
  if (!displayBox || !exprEl || !valEl) return;
  if (STATE.isResultMode) {
    // Capture the editable expression row's real on-screen Y position before
    // result-mode CSS changes the layout. Reuse this exact offset for the
    // committed answer so it replaces the expression in-place, not merely in
    // the same DOM row with a slightly different vertical alignment.
    const expressionRowForAnchor = document.getElementById('calc-expr-row');
    if (expressionRowForAnchor && !displayBox.dataset.resultRowAnchorTop) {
      const parentRect = displayBox.getBoundingClientRect();
      const rowRect = expressionRowForAnchor.getBoundingClientRect();
      const anchorTop = rowRect.top - parentRect.top - (displayBox.clientTop || 0);
      if (Number.isFinite(anchorTop)) {
        displayBox.dataset.resultRowAnchorTop = String(anchorTop);
        displayBox.style.setProperty('--calc-result-row-anchor-top', `${anchorTop}px`);
      }
    }
    displayBox.classList.add('result-mode');
    displayBox.classList.remove('preview-error-mode');
    // '=' is a committed-result screen: the expression is retained in state
    // for DEL/continuation, but only the calculated value is visible.
    exprEl.readOnly = true;
    // Commit the answer into the primary expression row. Keep the original
    // expression only in STATE.calcExpr/calcResultExpression so DEL or a new
    // edit can restore it without exposing the preview row as the result UI.
    const committedResult = String(STATE.calcVal ?? '0');
    const displayCommittedResult = globalThis.SALocalization?.localizeDigits ? globalThis.SALocalization.localizeDigits(committedResult) : committedResult;
    const isCommittedError = committedResult === 'Error';
    if (exprEl.value !== displayCommittedResult) exprEl.value = displayCommittedResult;
    exprEl.setAttribute('aria-label', isCommittedError ? 'Calculation error' : 'Calculation result');
    displayBox.classList.toggle('result-error-mode', isCommittedError);
    // Never duplicate a committed Error in the preview row. The primary row
    // already contains the canonical `Error` result; the detailed message is
    // retained in state for diagnostics/accessibility but is not rendered as a
    // second result surface.
    valEl.textContent = '';
    valEl.classList.remove('is-preview-error');
    valEl.setAttribute('aria-label', 'Live preview');
    valEl.__sumaireCanonicalText = committedResult;
    fitCalculatorExpression();
  } else {
    displayBox.classList.remove('result-mode', 'result-error-mode');
    // Release result-only inline layout locks when the user resumes editing.
    const expressionRow = document.getElementById('calc-expr-row');
    const previewRow = document.getElementById('calc-preview-row');
    if (displayBox) {
      displayBox.style.removeProperty('justify-content');
      displayBox.style.removeProperty('--calc-result-row-anchor-top');
      delete displayBox.dataset.resultRowAnchorTop;
    }
    if (expressionRow) {
      ['display', 'visibility', 'opacity', 'margin-top', 'margin-left', 'margin-right', 'flex', 'align-self', 'position', 'top', 'left', 'right', 'width', 'box-sizing'].forEach(name => expressionRow.style.removeProperty(name));
    }
    if (previewRow) {
      ['display', 'visibility', 'height', 'min-height', 'margin', 'padding'].forEach(name => previewRow.style.removeProperty(name));
    }
    exprEl.readOnly = false;
    exprEl.setAttribute('aria-label', 'Calculation expression');
    if (exprEl.value !== STATE.calcExpr) exprEl.value = STATE.calcExpr;
    if (STATE.calcExpr && STATE.liveCalc) {
      const preview = evaluateLiveExpression(STATE.calcExpr);
      const previewIsError = /^(?:Error|Result is outside|Check the |Complete the |This calculation)/.test(String(preview));
      valEl.textContent = preview !== '' ? preview : '';
      valEl.classList.toggle('is-preview-error', previewIsError);
      // Keep an explicit parent error state so late/cascading layout rules can
      // never collapse an error that the evaluator has already produced.
      displayBox.classList.toggle('preview-error-mode', previewIsError);
      valEl.setAttribute('aria-label', preview ? `Live preview: ${preview}` : 'Live preview');
    } else {
      // Keep a fresh/cleared calculator display visually empty.
      // STATE.calcVal remains '0' internally for arithmetic semantics.
      valEl.textContent = '';
      valEl.classList.remove('is-preview-error');
      displayBox.classList.remove('preview-error-mode');
      valEl.setAttribute('aria-label', 'Live preview');
    }
    fitCalculatorExpression();
    valEl.__sumaireCanonicalText = String(valEl.textContent ?? '');
    if (restoreCaret && document.activeElement === exprEl) {
      setCalcEditorSelection(STATE.calcSelectionStart, STATE.calcSelectionEnd, false);
    }
  }
  fitCalculatorResult(valEl);
}
function calcSelection() {
  const editor = getCalcEditor();
  if (editor && document.activeElement === editor) syncCalcSelectionFromEditor();
  const len = STATE.calcExpr.length;
  const start = Math.max(0, Math.min(len, STATE.calcSelectionStart ?? STATE.calcCursor ?? len));
  const end = Math.max(start, Math.min(len, STATE.calcSelectionEnd ?? start));
  return {start, end, direction: STATE.calcSelectionDirection || 'none'};
}
function countDigitsInOperandAt(expression, position) {
  const left = String(expression).slice(0, position);
  const right = String(expression).slice(position);
  const separators = /[+−×÷*/^()%]/;
  const leftToken = left.split(separators).pop() || '';
  const rightToken = (right.split(separators)[0] || '');
  const token = leftToken + rightToken;
  return numericSignificantDigitCount(token.replace(/[eE][+-]?\d*$/, ''));
}
const CALCULATOR_MAX_OPERAND_DIGITS = 16;

function calculatorNumericTokens(expression) {
  // Scientific exponent digits describe magnitude, not entered mantissa precision.
  return String(expression ?? '').match(/(?:\d+\.?\d*|\.\d+)(?:[eE][+-]?\d+)?/g) || [];
}

function calculatorOperandMantissaDigits(token) {
  // Count significant digits, not every typed digit. Leading zeroes and
  // insignificant trailing zeroes do not reduce the 16-digit input compatibility (IEEE-754 precision remains finite).
  const mantissa = String(token ?? '').replace(/[eE][+-]?\d+$/, '');
  return numericSignificantDigitCount(mantissa);
}

function calculatorHasNewOverLimitOperand(candidate, previousExpression = STATE.calcExpr) {
  const previousCounts = new Map();
  calculatorNumericTokens(previousExpression).forEach(token => {
    previousCounts.set(token, (previousCounts.get(token) || 0) + 1);
  });
  for (const token of calculatorNumericTokens(candidate)) {
    if (calculatorOperandMantissaDigits(token) <= CALCULATOR_MAX_OPERAND_DIGITS) continue;
    const unchangedCount = previousCounts.get(token) || 0;
    if (unchangedCount > 0) {
      previousCounts.set(token, unchangedCount - 1);
      continue; // Preserve an unchanged computed/recalled operand.
    }
    return true;
  }
  return false;
}

function calcCandidateAllowed(candidate, cursor, previousExpression = STATE.calcExpr) {
  const value = String(candidate ?? '');
  if (value.length > 250 || /[\r\n]/.test(value)) return false;
  return !calculatorHasNewOverLimitOperand(value, previousExpression);
}
function calculatorSignToggleEdit(expression, selectionStart, selectionEnd) {
  const source = String(expression ?? '');
  const start = Math.max(0, Math.min(source.length, Number(selectionStart) || 0));
  const end = Math.max(start, Math.min(source.length, Number(selectionEnd) || start));
  const left = source.slice(0, start);
  const match = left.match(/(?:^|[+−×÷*/^(])([-−]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d*)?)$/);
  if (!match) return { start, end, text: '−' };
  const token = match[1];
  const tokenStart = left.length - token.length;
  return { start: tokenStart, end, text: /^[-−]/.test(token) ? token.slice(1) : '−' + token };
}
function replaceCalcRange(text, start, end, focus = true) {
  STATE.calcResultExpression = null;
  const previousExpression = STATE.calcExpr;
  const candidate = previousExpression.slice(0, start) + text + previousExpression.slice(end);
  const continuation = STATE.calcScientificContinuation;
  if (continuation && !candidate.includes(continuation.displayToken)) STATE.calcScientificContinuation = null;
  const caret = start + text.length;
  if (!calcCandidateAllowed(candidate, caret, previousExpression)) {
    showToast(candidate.length > 250 ? 'Expression limit: 250 characters' : `Maximum ${CALCULATOR_MAX_OPERAND_DIGITS} significant digits for accurate results`);
    return false;
  }
  STATE.calcExpr = candidate; STATE.isResultMode = false; STATE.calcErrorMessage = ''; STATE.calcScientificErrorPreview = false; STATE.calcScientificErrorExpression = null; STATE.calcRawValue = null; STATE.calcRepeat = null;
  STATE.calcSelectionStart = STATE.calcSelectionEnd = STATE.calcCursor = caret;
  STATE.calcSelectionDirection = 'none';
  updateCalcDisplayDOM(false);
  setCalcEditorSelection(caret, caret, focus);
  return true;
}
function insertCalcText(text) {
  const {start, end} = calcSelection();
  return replaceCalcRange(text, start, end, true);
}
function saveCalcResultExpression(expression = STATE.calcExpr, selectionStart = STATE.calcSelectionStart, selectionEnd = STATE.calcSelectionEnd, selectionDirection = STATE.calcSelectionDirection) {
  const source = String(expression ?? '');
  const start = Math.max(0, Math.min(source.length, Number(selectionStart) || 0));
  const end = Math.max(start, Math.min(source.length, Number(selectionEnd) || start));
  STATE.calcResultExpression = source;
  STATE.calcResultSelectionStart = start;
  STATE.calcResultSelectionEnd = end;
  STATE.calcResultSelectionDirection = selectionDirection === 'backward' || selectionDirection === 'forward' ? selectionDirection : 'none';
}

function restoreCalcExpressionFromResult() {
  if (!STATE.isResultMode) return false;
  const expression = STATE.calcResultExpression !== null
    ? String(STATE.calcResultExpression)
    : String(STATE.calcExpr || '');
  const start = Math.max(0, Math.min(expression.length, STATE.calcResultSelectionStart ?? expression.length));
  const end = Math.max(start, Math.min(expression.length, STATE.calcResultSelectionEnd ?? start));
  const direction = STATE.calcResultSelectionDirection || 'none';
  STATE.calcExpr = expression;
  STATE.calcCursor = start;
  STATE.calcSelectionStart = start;
  STATE.calcSelectionEnd = end;
  STATE.calcSelectionDirection = direction;
  STATE.calcVal = '0';
  STATE.calcErrorMessage = '';
  STATE.calcScientificErrorPreview = false; STATE.calcScientificErrorExpression = null;
  STATE.calcRawValue = null;
  STATE.calcRepeat = null;
  STATE.calcResultExpression = null;
  STATE.calcScientificContinuation = null;
  STATE.isResultMode = false;
  updateCalcDisplayDOM(false);
  setCalcEditorSelection(start, end, false, direction);
  return true;
}

function deleteCalcBackward() {
  // First DEL after '=' restores the exact source expression. A second DEL
  // edits that expression normally instead of unexpectedly clearing it.
  if (STATE.isResultMode) {
    restoreCalcExpressionFromResult();
    return;
  }
  const {start,end}=calcSelection();
  const scientificToken = getScientificDeletionRange(STATE.calcExpr, start, end, 'backward');
  if (scientificToken) {
    // A rendered scientific result is an atomic mathematical value. Deleting
    // at its exponent boundary removes the complete value, never just `195`.
    replaceCalcRange('', scientificToken.start, scientificToken.end, true);
    return;
  }
  let a=start, b=end;
  if (a===b && a>0) a--;
  if (a===b) return;
  replaceCalcRange('',a,b,true);
}

function deleteCalcForward() {
  if (STATE.isResultMode) {
    restoreCalcExpressionFromResult();
    return;
  }
  const {start,end}=calcSelection();
  const scientificToken = getScientificDeletionRange(STATE.calcExpr, start, end, 'forward');
  if (scientificToken) {
    replaceCalcRange('', scientificToken.start, scientificToken.end, true);
    return;
  }
  let a=start, b=end;
  if (a===b && b<STATE.calcExpr.length) b++;
  if (a===b) return;
  replaceCalcRange('',a,b,true);
}
function initCalcCursorSystem() {
  const editor = getCalcEditor(); if (!editor) return;
  editor.value = STATE.calcExpr;
  let composing = false;
  editor.addEventListener('focus', () => syncCalcSelectionFromEditor());
  editor.addEventListener('blur', () => {
    syncCalcSelectionFromEditor(true);
    scheduleCalculatorExpressionRightAnchor(editor);
  });
  editor.addEventListener('click', () => syncCalcSelectionFromEditor());
  document.addEventListener('pointerdown', event => {
    if (event.target && event.target.closest && event.target.closest('.main-keypad, .calc-edit-action')) syncCalcSelectionFromEditor(true);
  }, true);
  editor.addEventListener('keyup', () => syncCalcSelectionFromEditor());
  editor.addEventListener('select', () => syncCalcSelectionFromEditor());
  editor.addEventListener('selectionchange', () => syncCalcSelectionFromEditor());
  document.addEventListener('selectionchange', () => syncCalcSelectionFromEditor());
  editor.addEventListener('compositionstart', () => {
    syncCalcSelectionFromEditor(true);
    composing = true;
  });

  const commitNativeEditorValue = () => {
    const value = String(editor.value ?? '');
    const start = Number.isFinite(editor.selectionStart) ? editor.selectionStart : value.length;
    const end = Number.isFinite(editor.selectionEnd) ? editor.selectionEnd : start;

    // Android/WebView can occasionally deliver a non-cancelable deletion after
    // beforeinput. If that mutation detached the exponent from the scientific
    // token, roll back the mutation instead of accepting the exponent as a new
    // ordinary number. This is the final safety net for the `...×10¹⁹⁵ -> 195`
    // failure seen in the recording.
    const previous = String(STATE.calcExpr ?? '');
    const previousTokens = getScientificDisplayTokenRanges(previous);
    if (previousTokens.length) {
      const exponentOnly = previousTokens.some(range => {
        const token = previous.slice(range.start, range.end);
        const exponent = (token.match(/[⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+$/) || [''])[0];
        return exponent && value === exponent.split('').map(ch => ({'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁺':'+','⁻':'-'}[ch] ?? ch)).join('');
      });
      const orphanSuperscript = /^(?:[⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻]+)$/.test(value);
      if (exponentOnly || orphanSuperscript) {
        editor.value = previous;
        const rollback = Math.max(0, Math.min(previous.length, STATE.calcSelectionStart ?? STATE.calcCursor ?? previous.length));
        setCalcEditorSelection(rollback, rollback, false, STATE.calcSelectionDirection || 'none');
        updateCalcDisplayDOM(false);
        return false;
      }
    }
    if (!calcCandidateAllowed(value, start, STATE.calcExpr)) {
      const rejectedLength = value.length > 250;
      // Android IME and paste paths can emit non-cancelable input events.
      // Roll back to the last committed value and preserve its saved selection.
      editor.value = STATE.calcExpr;
      const rollbackStart = Math.max(0, Math.min(editor.value.length, STATE.calcSelectionStart ?? STATE.calcCursor ?? editor.value.length));
      const rollbackEnd = Math.max(rollbackStart, Math.min(editor.value.length, STATE.calcSelectionEnd ?? rollbackStart));
      setCalcEditorSelection(rollbackStart, rollbackEnd, false, STATE.calcSelectionDirection || 'none');
      showToast(rejectedLength ? 'Expression limit: 250 characters' : `Maximum ${CALCULATOR_MAX_OPERAND_DIGITS} significant digits per number`);
      return false;
    }
    STATE.calcExpr = value;
    STATE.calcScientificErrorPreview = false; STATE.calcScientificErrorExpression = null;
    STATE.isResultMode = false;
    STATE.calcCursor = start;
    STATE.calcSelectionStart = start;
    STATE.calcSelectionEnd = end;
    STATE.calcSelectionDirection = editor.selectionDirection || 'none';
    updateCalcDisplayDOM(false);
    return true;
  };

  editor.addEventListener('beforeinput', event => {
    // Composition text is provisional; validating each IME update breaks
    // Android keyboards that compose multi-stage characters.
    if (composing || event.isComposing || !event.inputType) return;

    const {start,end}=calcSelection();
    const inputType = String(event.inputType);

    // Scientific display tokens are atomic. Native Backspace/Delete must not
    // leave the superscript exponent behind as a standalone number.
    if (inputType === 'deleteContentBackward' || inputType === 'deleteContentForward' ||
        inputType === 'deleteByCut' || inputType === 'deleteByDrag') {
      const direction = inputType === 'deleteContentForward' ? 'forward' : 'backward';
      const token = getScientificDeletionRange(STATE.calcExpr, start, end, direction);
      if (token && event.cancelable) {
        event.preventDefault();
        replaceCalcRange('', token.start, token.end, true);
        return;
      }
      return;
    }

    const text = event.data || (event.dataTransfer && event.dataTransfer.getData('text/plain')) || '';
    if (!inputType.startsWith('insert') || inputType === 'insertCompositionText') return;

    // If the user taps into the superscript portion of a scientific result and
    // types, append at the token boundary instead of creating an orphaned
    // exponent. This preserves the semantic invariant: `195` is only an
    // exponent when attached to its mantissa/10 token.
    const token = getScientificDisplayTokenAt(STATE.calcExpr, start, end);
    if (token && start === end && event.cancelable) {
      event.preventDefault();
      if (text) replaceCalcRange(text, token.end, token.end, true);
      else setCalcEditorSelection(token.end, token.end, true);
      return;
    }

    if (text && !calcCandidateAllowed(STATE.calcExpr.slice(0,start)+text+STATE.calcExpr.slice(end),start+text.length,STATE.calcExpr) && event.cancelable) {
      event.preventDefault();
      showToast(text.length + STATE.calcExpr.length - (end - start) > 250 ? 'Expression limit: 250 characters' : `Maximum ${CALCULATOR_MAX_OPERAND_DIGITS} significant digits per number`);
    }
  });
  editor.addEventListener('input', event => {
    if (composing || event.isComposing) return;
    commitNativeEditorValue();
    // fitCalculatorExpression may not change geometry once the font has
    // reached 40px. Re-pin after every committed keystroke so overflow never
    // starts drifting to the right at the minimum-size threshold.
    scheduleCalculatorExpressionRightAnchor(editor);
  });
  editor.addEventListener('compositionend', () => {
    composing = false;
    // Android may dispatch the final input immediately before or after
    // compositionend. A frame lets the final committed value settle first.
    const finish = () => {
      commitNativeEditorValue();
      scheduleCalculatorExpressionRightAnchor(editor);
    };
    if (typeof window.requestAnimationFrame === 'function') window.requestAnimationFrame(finish);
    else finish();
  });
  if (!window.__sumaireCalcKeyboardBound) {
    window.__sumaireCalcKeyboardBound = true;
    document.addEventListener('keydown', event => {
      if (event.defaultPrevented || event.ctrlKey || event.metaKey || event.altKey) return;
      const target = event.target;
      // The earlier global keyboard handler already routes keys when the
      // calculator editor is not focused. This listener owns only Enter in
      // the native expression editor; handling other targets here caused a
      // single physical key to activate the keypad twice (and could hijack
      // typing in tool inputs).
      if (target !== editor) return;
      // Enter evaluates instead of inserting an invisible newline into the
      // one-line editor. Native Backspace, arrows, selection and IME remain.
      if (event.key === 'Enter' && !event.shiftKey && !event.isComposing) {
        event.preventDefault();
        document.querySelector('[data-calc="="]')?.click();
      }
    });
  }
}

// Limit each numeric operand to 16 significant digits (IEEE-754 Number precision),
// while allowing harmless leading/trailing zeroes and long expressions.
function currentOperandDigitCount(expression) {
  const tail = String(expression || '').split(/[+−×÷*/^()%\-]/).pop() || '';
  const mantissa = tail.replace(/[eE][+-]?\d+$/, '');
  return numericSignificantDigitCount(mantissa);
}

function parseDisplayedCalculatorValue(value) {
  const normalized = String(value ?? '').replace(/[ ,]/g, '');
  const number = Number(normalized);
  return Number.isFinite(number) ? number : NaN;
}

function initCalculators() {
  initCalcCursorSystem();
  if (!window.__sumaireCalcResizeBound) {
    window.__sumaireCalcResizeBound = true;
    window.addEventListener('resize', scheduleCalculatorResultFit, { passive: true });
    window.addEventListener('orientationchange', scheduleCalculatorResultFit, { passive: true });
    if (window.visualViewport && typeof window.visualViewport.addEventListener === 'function') {
      window.visualViewport.addEventListener('resize', scheduleCalculatorResultFit, { passive: true });
    }
    const displayBox = document.getElementById('calc-display-box');
    const displayRow = document.querySelector('.calc-preview-row');
    if (typeof ResizeObserver === 'function' && (displayBox || displayRow)) {
      window.__sumaireCalcResizeObserver = new ResizeObserver(scheduleCalculatorResultFit);
      if (displayBox) window.__sumaireCalcResizeObserver.observe(displayBox);
      if (displayRow && displayRow !== displayBox) window.__sumaireCalcResizeObserver.observe(displayRow);
      const expressionRow = document.getElementById('calc-expr-row');
      const expressionEditor = getCalcEditor();
      if (expressionRow) window.__sumaireCalcResizeObserver.observe(expressionRow);
      if (expressionEditor) window.__sumaireCalcResizeObserver.observe(expressionEditor);
    }
    if (document.fonts && document.fonts.ready && typeof document.fonts.ready.then === 'function') {
      document.fonts.ready.then(scheduleCalculatorResultFit).catch(() => {});
    }
    window.addEventListener('pageshow', scheduleCalculatorResultFit);
  }
  document.querySelectorAll('[data-calc]').forEach(btn => {
    btn.addEventListener('click', () => {
      triggerHaptic(); const action=btn.getAttribute('data-calc');
      if (action==='C') { STATE.calcResultExpression=null; STATE.calcScientificContinuation=null; STATE.calcExpr=''; STATE.calcVal='0'; STATE.calcErrorMessage=''; STATE.calcScientificErrorPreview=false; STATE.calcRawValue=null; STATE.calcRepeat=null; STATE.isResultMode=false; STATE.calcCursor=0; STATE.calcSelectionStart=STATE.calcSelectionEnd=0; updateCalcDisplayDOM(false); setCalcEditorSelection(0,0,true); return; }
      if (action==='=') {
        // A lone number is an editable entry, not a completed calculation.
        // Keep the real caret visible and leave the expression in edit mode.
        // This prevents `9` -> `=` from replacing the expression with a
        // committed result, while compound expressions still commit normally.
        if (/^[+-]?(?:\d+(?:\.\d*)?|\.\d+)$/.test(String(STATE.calcExpr || '').trim())) {
          updateCalcDisplayDOM(true);
          setCalcEditorSelection(STATE.calcSelectionStart, STATE.calcSelectionEnd, true);
          return;
        }
        // Errors are preview-only. '=' must never turn a scientific-key error
        // (or any other live-preview Error) into the primary result row.
        const livePreviewBeforeEquals = evaluateLiveExpression(STATE.calcExpr);
        if (livePreviewBeforeEquals === 'Error') {
          updateCalcDisplayDOM(false);
          setCalcEditorSelection(STATE.calcSelectionStart, STATE.calcSelectionEnd, true);
          return;
        }
        if (STATE.isResultMode) {
          if (!Number.isFinite(STATE.calcRawValue) || !STATE.calcRepeat) return;
          try {
            const previousValue = STATE.calcRawValue;
            const repeatExpression = `${previousValue}${STATE.calcRepeat.operator}(${STATE.calcRepeat.rhs})`;
            const repeated = evaluateArithmetic(repeatExpression, STATE.implicitMult);
            if (!Number.isFinite(repeated)) throw Error('range');
            STATE.calcRawValue = repeated;
            STATE.calcExpr = repeatExpression;
            STATE.calcCursor = STATE.calcSelectionStart = STATE.calcSelectionEnd = repeatExpression.length;
            saveCalcResultExpression(repeatExpression, repeatExpression.length, repeatExpression.length);
            STATE.calcVal = formatCalculatorExpressionResult(repeatExpression, repeated); STATE.calcErrorMessage = '';
            recordHistoryEntry(repeatExpression, STATE.calcVal);
            updateCalcDisplayDOM(false);
          } catch (error) { STATE.calcRawValue=null; STATE.calcVal='Error'; STATE.calcErrorMessage=calculatorErrorMessage(error); updateCalcDisplayDOM(false); }
          return;
        }
        if(!STATE.calcExpr.trim())return;
        saveCalcResultExpression(STATE.calcExpr, STATE.calcSelectionStart, STATE.calcSelectionEnd);
        try { const clean=normalizedCalcExpression(STATE.calcExpr); if(!clean)throw Error('empty'); const res=evaluateArithmetic(clean,STATE.implicitMult); if(!Number.isFinite(res))throw Error('range'); const repeat=getCalculatorRepeatOperation(clean); const answer=formatCalculatorExpressionResult(STATE.calcExpr, res); STATE.calcRawValue=res; STATE.calcRepeat=repeat; STATE.calcScientificContinuation=null;
          recordHistoryEntry(STATE.calcExpr, answer);
          STATE.calcVal=answer;STATE.calcErrorMessage='';STATE.isResultMode=true;getCalcEditor()?.blur();updateCalcDisplayDOM(false);
          if(STATE.autoCopy&&navigator.clipboard)navigator.clipboard.writeText(answer).catch(()=>{});
        } catch(error){
          // Never destroy the user's expression on an evaluation/precision error.
          // The reference-calculator workflow keeps the editable expression in
          // place and exposes the failure only in the preview row. This also
          // prevents the video-observed `large expression -> 0` reset.
          STATE.calcRawValue=null;
          STATE.calcVal='Error';
          STATE.calcErrorMessage='';
          STATE.calcScientificErrorPreview=true; STATE.calcScientificErrorExpression=String(STATE.calcExpr ?? '');
          STATE.isResultMode=false;
          updateCalcDisplayDOM(false);
          setCalcEditorSelection(STATE.calcSelectionStart, STATE.calcSelectionEnd, true);
        } return;
      }
      if(action==='DEL' && STATE.isResultMode){deleteCalcBackward();return;}
      if(action==='±'){
        if (STATE.isResultMode) {
          const committed = calculatorExpressionFromCommittedResult();
          STATE.calcExpr = String(committed);
          STATE.calcCursor = STATE.calcSelectionStart = STATE.calcSelectionEnd = STATE.calcExpr.length;
          STATE.isResultMode = false; STATE.calcResultExpression = null;
        }
        const selection = calcSelection();
        const edit = calculatorSignToggleEdit(STATE.calcExpr, selection.start, selection.end);
        replaceCalcRange(edit.text, edit.start, edit.end, true);
        return;
      }
      if(STATE.isResultMode){
        STATE.calcResultExpression = null;
        if(['+','-','*','/','^'].includes(action)){const base=calculatorExpressionFromCommittedResult();STATE.calcExpr=base;STATE.calcCursor=STATE.calcSelectionStart=STATE.calcSelectionEnd=base.length;STATE.isResultMode=false;}
        else if(action==='()'){STATE.calcScientificContinuation=null;STATE.calcExpr='';STATE.calcCursor=STATE.calcSelectionStart=STATE.calcSelectionEnd=0;STATE.isResultMode=false;}
        else if(action==='%'){STATE.calcExpr=calculatorExpressionFromCommittedResult();STATE.calcCursor=STATE.calcSelectionStart=STATE.calcSelectionEnd=STATE.calcExpr.length;STATE.isResultMode=false;}
        else {STATE.calcScientificContinuation=null;STATE.calcExpr='';STATE.calcCursor=STATE.calcSelectionStart=STATE.calcSelectionEnd=0;STATE.isResultMode=false;}
      }
      let {start,end}=calcSelection();
      if(['+','-','*','/','^'].includes(action)){
        const op=action==='*'?'×':action==='/'?'÷':action==='-'?'−':action==='^'?'^':'+';
        // Power is a binary operator and must exist only once at a given
        // operator boundary. Repeated taps such as ^^^^^^ therefore never
        // grow the expression; the existing ^ remains selected by the real
        // caret/selection system.
        if (action==='^' && start===end && STATE.calcExpr[start-1]==='^') return;
        if(start===end&&start>0&&['+','−','×','÷'].includes(STATE.calcExpr[start-1]))start--;
        insertCalcAt(start,end,op); return;
      }
      if(action==='()'){
        const before=STATE.calcExpr.slice(0,start), after=STATE.calcExpr.slice(end);
        const opens=(before.match(/\(/g)||[]).length+(after.match(/\(/g)||[]).length;
        const closes=(before.match(/\)/g)||[]).length+(after.match(/\)/g)||[]).length;
        const last=before.slice(-1); const text=opens>closes&&last&& !/[+−×÷(]/.test(last)?')':'(';
        insertCalcAt(start,end,text); return;
      }
      // Percent is postfix and may be repeated: 9%%%%%% is a valid
      // expression (each % applies another division by 100).
      if(action==='%'){ if(start>0&&/[0-9)%]/.test(STATE.calcExpr[start-1]))insertCalcAt(start,end,'%'); return; }
      if(action==='DEL'){deleteCalcBackward();return;}
      if(action==='.'){
        const left=STATE.calcExpr.slice(0,start), token=left.split(/[+−×÷*/^()%]/).pop()||'';
        const fullToken=token+(STATE.calcExpr.slice(end).split(/[+−×÷*/^()%]/)[0]||'');
        if(!fullToken.includes('.'))insertCalcAt(start,end,token===''?'0.':'.'); return;
      }
      if(action==='00'){
        if(start===0||/[+−×÷*(^]$/.test(STATE.calcExpr.slice(0,start)))insertCalcAt(start,end,'0');
        else if(/[0-9]$/.test(STATE.calcExpr.slice(0,start)))insertCalcAt(start,end,'00'); return;
      }
      if(/^\d$/.test(action)){insertCalcAt(start,end,action);return;}
    });
  });
}
function insertCalcAt(start,end,text){
  // Keypad insertion must obey the same atomic scientific-token rule as the
  // native editor. If the caret lands inside `1.380878 × 10¹⁹⁵`, the new
  // character is appended after the complete value rather than being inserted
  // into/detaching the superscript exponent.
  const token = getScientificDisplayTokenAt(STATE.calcExpr, start, end);
  if (token) {
    if (start === end) return replaceCalcRange(text, token.end, token.end, true);
    return replaceCalcRange(text, token.start, token.end, true);
  }
  return replaceCalcRange(text,start,end,true);
}

// CALCULATOR MEMORY (MC / MR / M+ / M- / MS)
// SCIENTIFIC FUNCTIONS MODAL
function getModalFocusableElements(modal) {
  if (!modal?.querySelectorAll) return [];
  const candidates = modal.querySelectorAll('button, a[href], input, select, textarea, [contenteditable="true"], [tabindex]');
  return Array.from(candidates).filter(element => {
    if (element.tabIndex < 0 || element.matches(':disabled')) return false;
    if (element.closest('[inert], [aria-hidden="true"]')) return false;
    if (!element.getClientRects().length) return false;
    const style = getComputedStyle(element);
    return style.visibility !== 'hidden' && style.display !== 'none';
  });
}

function keepModalTabFocus(event, modal) {
  if (event.key !== 'Tab' || !modal) return;
  const focusable = getModalFocusableElements(modal);
  const active = document.activeElement;
  if (!focusable.length) {
    // A dialog with no tabbable descendants must still retain keyboard focus.
    event.preventDefault();
    modal.focus?.();
    return;
  }

  const first = focusable[0];
  const last = focusable[focusable.length - 1];
  const activeIndex = focusable.indexOf(active);
  const activeIsInsideTabOrder = activeIndex !== -1;

  // Focus may be on the dialog itself (or a static/non-tabbable child) after
  // initial focus, validation, or a programmatic update. Native Shift+Tab
  // from those positions can escape the modal, so explicitly choose an edge.
  if (!modal.contains(active) || !activeIsInsideTabOrder) {
    event.preventDefault();
    (event.shiftKey ? last : first).focus();
    return;
  }

  if (event.shiftKey && activeIndex === 0) {
    event.preventDefault();
    last.focus();
  } else if (!event.shiftKey && activeIndex === focusable.length - 1) {
    event.preventDefault();
    first.focus();
  }
}

function initScientific() {
  const screen = document.getElementById('screen-scientific');
  const editor = document.getElementById('sci-expression');
  const result = document.getElementById('sci-result');
  const status = document.getElementById('sci-status');
  if (!screen || !editor || !result || screen.dataset.bound === 'true') return;
  screen.dataset.bound = 'true';
  const sci = { expression: '', result: 0, resultMode: false, angle: (() => { try { return localStorage.getItem('sa_scientific_angle_v1') === 'rad' ? 'rad' : 'deg'; } catch { return 'deg'; } })(), memory: 0, hasMemory: false, history: [], lastAnswer: 0, hasAnswer: false };
  try { const saved = JSON.parse(localStorage.getItem('sa_scientific_memory_v1') || 'null'); if (saved && saved.hasMemory === true && Number.isFinite(Number(saved.value))) { sci.memory = Number(saved.value); sci.hasMemory = true; } } catch {}
  const persistScientificMemory = () => { try { if (sci.hasMemory) localStorage.setItem('sa_scientific_memory_v1', JSON.stringify({value:sci.memory,hasMemory:true})); else localStorage.removeItem('sa_scientific_memory_v1'); } catch {} };
  try { const savedHistory = JSON.parse(localStorage.getItem('sa_scientific_history_v1') || '[]'); if (Array.isArray(savedHistory)) sci.history = savedHistory.filter(item => item && typeof item.expression === 'string' && Number.isFinite(Number(item.result))).slice(0,50); } catch {}
  sci.hasAnswer = sci.history.length > 0; if (sci.hasAnswer) sci.lastAnswer = Number(sci.history[0].result);
  const historyList = document.getElementById('sci-history-list');
  const renderHistory = () => { if (!historyList) return; historyList.replaceChildren(); if (!sci.history.length) { const empty = document.createElement('p'); empty.textContent = 'No scientific calculations yet.'; historyList.appendChild(empty); return; } sci.history.forEach(item => { const button = document.createElement('button'); button.type = 'button'; button.className = 'scientific-history-item'; button.dataset.sciHistoryExpression = item.expression; const expression = document.createElement('span'); expression.textContent = item.expression; const answer = document.createElement('strong'); answer.textContent = String(item.result); button.append(expression, answer); historyList.appendChild(button); }); };
  const saveHistory = () => { try { localStorage.setItem('sa_scientific_history_v1', JSON.stringify(sci.history.slice(0,50))); } catch {} renderHistory(); };
  renderHistory();
  const render = (evaluate = true) => {
    // Avoid assigning an unchanged value: doing so resets the caret and horizontal scroll
    // in Android WebView, making long scientific expressions difficult to edit.
    const editorValueChanged = editor.value !== sci.expression;
    if (editorValueChanged) { editor.value = sci.expression; editor.scrollLeft = editor.scrollWidth; }
    const angleIndicator = document.getElementById('sci-angle-indicator'); if (angleIndicator) angleIndicator.textContent = sci.angle.toUpperCase(); const memoryIndicator = document.getElementById('sci-memory-indicator'); if (memoryIndicator) memoryIndicator.textContent = sci.hasMemory ? 'M ✓' : 'M —';
    if (!sci.expression) { result.textContent = '0'; if (status) status.textContent = 'Scientific mode'; return; }
    if (!evaluate) return;
    try {
      const value = evaluateArithmetic(sci.expression, true, sci.angle);
      if (!Number.isFinite(value)) throw new Error('Out of range');
      sci.result = value;
      result.textContent = Number(value.toPrecision(12)).toString();
      if (status) status.textContent = 'Live result';
    } catch (error) {
      // Incomplete expressions are neutral while typing; malformed complete
      // expressions are reported only on explicit equals.
      result.textContent = '';
      if (status) status.textContent = 'Enter expression';
    }
  };
  const insert = token => {
    if (sci.resultMode) {
      const isPrefixFunction = /^[a-z][a-z0-9]*\($/i.test(token) || token === '1/(' || token === 'sqrt(' || token === 'cbrt(' || token.endsWith('^(');
      if (isPrefixFunction) {
        sci.expression = `${token}${sci.expression})`;
        sci.resultMode = false;
        render();
        const caret = sci.expression.length;
        editor.focus({ preventScroll: true }); editor.setSelectionRange(caret, caret);
        return;
      }
      if (/^[0-9.]$/.test(token) || token === '00' || token === '(') sci.expression = '';
    }
    sci.resultMode = false;
    const start = sci.resultMode && !sci.expression ? 0 : (editor.selectionStart ?? sci.expression.length);
    const end = sci.resultMode && !sci.expression ? 0 : (editor.selectionEnd ?? start);
    sci.expression = sci.expression.slice(0, start) + token + sci.expression.slice(end);
    render();
    const caret = start + token.length;
    editor.focus({ preventScroll: true });
    editor.setSelectionRange(caret, caret);
    if (caret >= editor.value.length) editor.scrollLeft = editor.scrollWidth;
  };
  const clear = () => { sci.expression = ''; sci.result = 0; sci.resultMode = false; render(); editor.focus({preventScroll:true}); };
  const del = () => {
    const start = sci.resultMode && !sci.expression ? 0 : (editor.selectionStart ?? sci.expression.length);
    const end = sci.resultMode && !sci.expression ? 0 : (editor.selectionEnd ?? start);
    if (start !== end) sci.expression = sci.expression.slice(0,start) + sci.expression.slice(end);
    else if (start > 0) sci.expression = sci.expression.slice(0,start-1) + sci.expression.slice(start);
    sci.resultMode = false; render(); editor.focus({preventScroll:true});
    const caret = start === end ? Math.max(0,start-1) : start; editor.setSelectionRange(caret,caret);
  };
  const moveCursor = direction => { const start = editor.selectionStart ?? editor.value.length; const end = editor.selectionEnd ?? start; const next = direction < 0 ? Math.max(0, (start === end ? start - 1 : start)) : Math.min(editor.value.length, (start === end ? end + 1 : end)); editor.focus({preventScroll:true}); editor.setSelectionRange(next,next); };
  const toggleSign = () => { const start = editor.selectionStart ?? sci.expression.length; const end = editor.selectionEnd ?? start; if (start !== end) { const selected = sci.expression.slice(start,end); const changed = selected.startsWith('-') ? selected.slice(1) : `-${selected}`; sci.expression = sci.expression.slice(0,start) + changed + sci.expression.slice(end); render(); editor.focus({preventScroll:true}); editor.setSelectionRange(start,start+changed.length); return; } const prefix = sci.expression.slice(0,start); const match = prefix.match(/(?:^|[+\-*/(])(-?(?:\d+(?:\.\d*)?|\.\d+)(?:e[+\-]?\d+)?)$/i); if (match) { const token = match[1]; const tokenStart = start-token.length; const replacement = token.startsWith('-') ? token.slice(1) : `-${token}`; sci.expression = sci.expression.slice(0,tokenStart)+replacement+sci.expression.slice(start); render(); editor.focus({preventScroll:true}); const caret=tokenStart+replacement.length; editor.setSelectionRange(caret,caret); } else if (!sci.expression) insert('-'); };
  const setAngle = angle => { sci.angle = angle === 'rad' ? 'rad' : 'deg'; try { localStorage.setItem('sa_scientific_angle_v1', sci.angle); } catch {} const angleIndicator = document.getElementById('sci-angle-indicator'); if (angleIndicator) angleIndicator.textContent = sci.angle.toUpperCase(); render(); };
  const equals = () => {
    try {
      if (!sci.expression.trim()) return;
      const value = evaluateArithmetic(sci.expression, true, sci.angle);
      if (!Number.isFinite(value)) throw new Error('Result out of range');
      sci.result = value; sci.lastAnswer = value; sci.hasAnswer = true; result.textContent = Number(value.toPrecision(12)).toString();
      const originalExpression = sci.expression;
      sci.history.unshift({ expression: originalExpression, result: value, at: Date.now() });
      sci.history = sci.history.slice(0,50); saveHistory();
      sci.expression = String(value); sci.resultMode = true; editor.value = sci.expression; editor.setSelectionRange(editor.value.length, editor.value.length); editor.scrollLeft = editor.scrollWidth;
      if (status) status.textContent = 'Calculated';
    } catch (error) {
      if (status) status.textContent = error?.message || 'Invalid expression';
      result.textContent = 'Error';
    }
  };
  screen.addEventListener('click', event => {
    const angle = event.target.closest('[data-sci-angle]');
    if (angle) { setAngle(angle.dataset.sciAngle); return; }
    const action = event.target.closest('[data-sci-action]');
    if (action) {
      const name = action.dataset.sciAction;
      if (name === 'clear') clear(); else if (name === 'delete') del(); else if (name === 'equals') equals(); else if (name === 'ans' && sci.hasAnswer) insert(String(sci.lastAnswer));
      else if (name === 'cursor-left') moveCursor(-1); else if (name === 'cursor-right') moveCursor(1); else if (name === 'sign') toggleSign(); else if (name === 'toggle-angle') setAngle(sci.angle === 'deg' ? 'rad' : 'deg');
      return;
    }
    if (event.target.closest('#sci-shift-toggle')) {
      const shift = document.getElementById('sci-shift-toggle'); const active = shift.getAttribute('aria-pressed') !== 'true'; shift.setAttribute('aria-pressed', String(active)); shift.classList.toggle('active', active);
      screen.querySelectorAll('[data-sci-alt-insert]').forEach(button => { const token = active ? button.dataset.sciAltInsert : button.dataset.sciInsert; const label = active ? button.dataset.sciAltLabel : button.dataset.sciLabel; button.textContent = label || button.textContent; button.dataset.sciActiveInsert = token; }); return;
    }
    if (event.target.closest('#sci-more-toggle')) { const toggle=document.getElementById('sci-more-toggle'); const panel=document.getElementById('sci-more-functions'); if(panel&&toggle){panel.hidden=!panel.hidden;toggle.setAttribute('aria-expanded',String(!panel.hidden));} return; }
    if (event.target.closest('#sci-history-toggle')) { const toggle = document.getElementById('sci-history-toggle'); const panel = document.getElementById('sci-history-panel'); if (panel && toggle) { panel.hidden = !panel.hidden; toggle.setAttribute('aria-expanded', String(!panel.hidden)); } return; }
    if (event.target.closest('#sci-history-clear')) { sci.history = []; sci.hasAnswer = false; sci.lastAnswer = 0; saveHistory(); return; }
    const historyItem = event.target.closest('[data-sci-history-expression]');
    if (historyItem) { sci.expression = historyItem.dataset.sciHistoryExpression || ''; sci.resultMode = false; render(); editor.focus({preventScroll:true}); editor.setSelectionRange(sci.expression.length,sci.expression.length); return; }
    const memory = event.target.closest('[data-sci-memory]');
    if (memory) {
      const op = memory.dataset.sciMemory;
      if (op === 'MC') { sci.memory = 0; sci.hasMemory = false; persistScientificMemory(); }
      else if (op === 'MS') { try { sci.memory = evaluateArithmetic(sci.expression, true, sci.angle); sci.hasMemory = true; persistScientificMemory(); } catch {} }
      else if (op === 'M+') { try { sci.memory += evaluateArithmetic(sci.expression, true, sci.angle); sci.hasMemory = true; persistScientificMemory(); } catch {} }
      else if (op === 'M-') { try { sci.memory -= evaluateArithmetic(sci.expression, true, sci.angle); sci.hasMemory = true; persistScientificMemory(); } catch {} }
      else if (op === 'MR' && sci.hasMemory) insert(String(sci.memory));
      const memoryIndicator = document.getElementById('sci-memory-indicator'); if (memoryIndicator) memoryIndicator.textContent = sci.hasMemory ? 'M ✓' : 'M —'; if (status && op !== 'MR') status.textContent = op === 'MC' ? 'Memory cleared' : 'Memory updated'; return;
    }
    const key = event.target.closest('[data-sci-insert]');
    if (key) { insert(key.dataset.sciActiveInsert || key.dataset.sciInsert); triggerHaptic(); }
  });
  editor.addEventListener('input', () => { sci.expression = editor.value.slice(0,250); sci.resultMode = false; render(); });
  editor.addEventListener('keydown', event => {
    if (event.key === 'Enter' || event.key === '=') { event.preventDefault(); equals(); }
    else if (event.key === 'Escape') { event.preventDefault(); clear(); }
  });
  render(false);
  const angleIndicator = document.getElementById('sci-angle-indicator'); if (angleIndicator) angleIndicator.textContent = sci.angle.toUpperCase();
  const memoryIndicator = document.getElementById('sci-memory-indicator'); if (memoryIndicator) memoryIndicator.textContent = sci.hasMemory ? 'M ✓' : 'M —';
}

const CURRENCY_CATALOG = ['ALL', 'DZD', 'AOA', 'ARS', 'AUD', 'AZN', 'BHD', 'BDT', 'BYN', 'BTN', 'BOB', 'BAM', 'BRL', 'GBP', 'BND', 'BGN', 'MMK', 'BIF', 'KHR', 'CAD', 'XAF', 'XOF', 'XPF', 'CLP', 'CNY', 'COP', 'CRC', 'HRK', 'CZK', 'DKK', 'DOP', 'EGP', 'ETB', 'EUR', 'FJD', 'GHS', 'HKD', 'HUF', 'ISK', 'INR', 'IDR', 'IRR', 'IQD', 'ILS', 'JPY', 'JOD', 'KZT', 'KES', 'KWD', 'KGS', 'LAK', 'LBP', 'MOP', 'MKD', 'MGA', 'MYR', 'MVR', 'MUR', 'MXN', 'MNT', 'MAD', 'NGN', 'NAD', 'NPR', 'TWD', 'NZD', 'NIO', 'NOK', 'OMR', 'PKR', 'PGK', 'PYG', 'PEN', 'PHP', 'PLN', 'QAR', 'RON', 'RUB', 'RWF', 'SAR', 'RSD', 'SCR', 'SGD', 'ZAR', 'KRW', 'LKR', 'SDG', 'SEK', 'CHF', 'SYP', 'TJS', 'TZS', 'THB', 'TND', 'TRY', 'TMT', 'UGX', 'UAH', 'AED', 'UYU', 'USD', 'UZS', 'VND', 'YER', 'ZMW'];

// 2. CURRENCY CONVERTER
// Currency names use the selected locale, with a bundled CLDR fallback for older WebViews.
// The picker uses a fixed, curated 105-currency catalogue. Provider-only codes
// never expand the user-facing list; unavailable pair rates are labelled explicitly.
let currencyDisplayNames = null;
let currencyDisplayNamesLocale = '';
const CURRENCY_LOCALE_BY_LANGUAGE = { en:'en', hi:'hi', ur:'ur', es:'es', fr:'fr', de:'de', ar:'ar', zh:'zh' };
function localizedCurrencyName(code) {
  const normalized = String(code || '').toUpperCase();
  const language = STATE.language || 'en';
  const locale = CURRENCY_LOCALE_BY_LANGUAGE[language] || 'en';
  try {
    if (!currencyDisplayNames || currencyDisplayNamesLocale !== locale) {
      currencyDisplayNames = new Intl.DisplayNames([locale], { type: 'currency', fallback: 'code' });
      currencyDisplayNamesLocale = locale;
    }
    const localized = currencyDisplayNames.of(normalized);
    if (localized && localized !== normalized && localized !== 'Unknown Currency') return localized;
  } catch (_) { /* Older Android WebViews use the stable English fallback below. */ }
  const bundled = window.SA_CURRENCY_LOCALIZED_NAMES?.[language]?.[normalized];
  if (bundled) return bundled;
  const explicit = CURRENCY_DISPLAY_NAMES[normalized] || RUNTIME_CURRENCY_NAMES[normalized];
  if (explicit && globalThis.SALocalization) return globalThis.SALocalization.translate(explicit, language);
  return explicit || normalized;
}
function refreshCurrencyLocalization() {
  const from = document.getElementById('cur-from');
  const to = document.getElementById('cur-to');
  if (from && to) populateCurrencyOptions(from.value || 'USD', to.value || 'INR');
  updateCurrencySelectionLabels();
}

// ISO 4217 display-name registry. Keep this explicit instead of relying only on
// Intl.DisplayNames because older Android WebViews can return the code itself or
// an unknown label. Every selectable currency must therefore have a stable full name.
const CURRENCY_DISPLAY_NAMES = {
  "AED": "United Arab Emirates Dirham",
  "AFN": "Afghani",
  "ALL": "Albanian Lek",
  "AMD": "Armenian Dram",
  "ANG": "Netherlands Antillean Guilder",
  "AOA": "Angolan Kwanza",
  "ARS": "Argentine Peso",
  "AUD": "Australian Dollar",
  "AWG": "Aruban Florin",
  "AZN": "Azerbaijan Manat",
  "BAM": "Bosnia and Herzegovina Convertible Mark",
  "BBD": "Barbados Dollar",
  "BDT": "Bangladeshi Taka",
  "BGN": "Bulgarian Lev",
  "BHD": "Bahraini Dinar",
  "BIF": "Burundi Franc",
  "BMD": "Bermudian Dollar",
  "BND": "Brunei Dollar",
  "BOB": "Bolivian Boliviano",
  "BOV": "Mvdol",
  "BRL": "Brazilian Real",
  "BSD": "Bahamian Dollar",
  "BTN": "Bhutanese Ngultrum",
  "BWP": "Botswana Pula",
  "BYN": "Belarusian Ruble",
  "BZD": "Belize Dollar",
  "CAD": "Canadian Dollar",
  "CDF": "Congolese Franc",
  "CHE": "WIR Euro",
  "CHF": "Swiss Franc",
  "CHW": "WIR Franc",
  "CLF": "Unidad de Fomento",
  "CLP": "Chilean Peso",
  "CNY": "Chinese Yuan",
  "COP": "Colombian Peso",
  "COU": "Unidad de Valor Real",
  "CRC": "Costa Rican Colon",
  "CUC": "Peso Convertible",
  "CUP": "Cuban Peso",
  "CVE": "Cabo Verde Escudo",
  "CZK": "Czech Koruna",
  "DJF": "Djibouti Franc",
  "DKK": "Danish Krone",
  "DOP": "Dominican Peso",
  "DZD": "Algerian Dinar",
  "EGP": "Egyptian Pound",
  "ERN": "Nakfa",
  "ETB": "Ethiopian Birr",
  "EUR": "Euro",
  "FJD": "Fijian Dollar",
  "FKP": "Falkland Islands Pound",
  "GBP": "British Pound",
  "GEL": "Lari",
  "GHS": "Ghanaian Cedi",
  "GIP": "Gibraltar Pound",
  "GMD": "Dalasi",
  "GNF": "Guinean Franc",
  "GTQ": "Quetzal",
  "GYD": "Guyana Dollar",
  "HKD": "Hong Kong Dollar",
  "HNL": "Lempira",
  "HRK": "Croatian Kuna",
  "HTG": "Gourde",
  "HUF": "Hungarian Forint",
  "IDR": "Indonesian Rupiah",
  "ILS": "Israeli New Shekel",
  "INR": "Indian Rupee",
  "IQD": "Iraqi Dinar",
  "IRR": "Iranian Rial",
  "ISK": "Icelandic Krona",
  "JMD": "Jamaican Dollar",
  "JOD": "Jordanian Dinar",
  "JPY": "Japanese Yen",
  "KES": "Kenyan Shilling",
  "KGS": "Kyrgyzstani Som",
  "KHR": "Cambodian Riel",
  "KMF": "Comorian Franc",
  "KPW": "North Korean Won",
  "KRW": "South Korean Won",
  "KWD": "Kuwaiti Dinar",
  "KYD": "Cayman Islands Dollar",
  "KZT": "Kazakhstani Tenge",
  "LAK": "Lao Kip",
  "LBP": "Lebanese Pound",
  "LKR": "Sri Lankan Rupee",
  "LRD": "Liberian Dollar",
  "LSL": "Loti",
  "LYD": "Libyan Dinar",
  "MAD": "Moroccan Dirham",
  "MDL": "Moldovan Leu",
  "MGA": "Malagasy Ariary",
  "MKD": "Macedonian Denar",
  "MMK": "Burmese Kyat",
  "MNT": "Mongolian Tugrik",
  "MOP": "Macau Pataca",
  "MRU": "Ouguiya",
  "MUR": "Mauritian Rupee",
  "MVR": "Maldivian Rufiyaa",
  "MWK": "Malawi Kwacha",
  "MXN": "Mexican Peso",
  "MXV": "Mexican Unidad de Inversion (UDI)",
  "MYR": "Malaysian Ringgit",
  "MZN": "Mozambique Metical",
  "NAD": "Namibian Dollar",
  "NGN": "Naira",
  "NIO": "Nicaraguan Cordoba",
  "NOK": "Norwegian Krone",
  "NPR": "Nepalese Rupee",
  "NZD": "New Zealand Dollar",
  "OMR": "Omani Rial",
  "PAB": "Balboa",
  "PEN": "Peruvian Sol",
  "PGK": "Papua New Guinean Kina",
  "PHP": "Philippine Peso",
  "PKR": "Pakistani Rupee",
  "PLN": "Polish Zloty",
  "PYG": "Paraguayan Guarani",
  "QAR": "Qatari Riyal",
  "RON": "Romanian Leu",
  "RSD": "Serbian Dinar",
  "RUB": "Russian Ruble",
  "RWF": "Rwandan Franc",
  "SAR": "Saudi Riyal",
  "SBD": "Solomon Islands Dollar",
  "SCR": "Seychelles Rupee",
  "SDG": "Sudanese Pound",
  "SEK": "Swedish Krona",
  "SGD": "Singapore Dollar",
  "SHP": "Saint Helena Pound",
  "SLE": "Leone",
  "SLL": "Leone",
  "SOS": "Somali Shilling",
  "SRD": "Surinam Dollar",
  "SSP": "South Sudanese Pound",
  "STN": "Dobra",
  "SVC": "El Salvador Colon",
  "SYP": "Syrian Pound",
  "SZL": "Lilangeni",
  "THB": "Thai Baht",
  "TJS": "Tajikistani Somoni",
  "TMT": "Turkmenistani Manat",
  "TND": "Tunisian Dinar",
  "TOP": "Tongan Paʻanga",
  "TRY": "Turkish Lira",
  "TTD": "Trinidad and Tobago Dollar",
  "TWD": "New Taiwan Dollar",
  "TZS": "Tanzanian Shilling",
  "UAH": "Ukrainian Hryvnia",
  "UGX": "Ugandan Shilling",
  "USD": "US Dollar",
  "USN": "US Dollar (Next day)",
  "UYI": "Uruguay Peso en Unidades Indexadas (UI)",
  "UYU": "Uruguayan Peso",
  "UYW": "Unidad Previsional",
  "UZS": "Uzbekistani Som",
  "VED": "Bolívar Soberano",
  "VES": "Bolívar Soberano",
  "VND": "Vietnamese Dong",
  "VUV": "Vanuatu Vatu",
  "WST": "Samoan Tala",
  "XAF": "Central African CFA Franc",
  "XAG": "Silver (troy ounce)",
  "XAU": "Gold (troy ounce)",
  "XBA": "Bond Markets Unit European Composite Unit (EURCO)",
  "XBB": "Bond Markets Unit European Monetary Unit (E.M.U.-6)",
  "XBC": "Bond Markets Unit European Unit of Account 9 (E.U.A.-9)",
  "XBD": "Bond Markets Unit European Unit of Account 17 (E.U.A.-17)",
  "XCD": "East Caribbean Dollar",
  "XCG": "Caribbean Guilder",
  "XDR": "SDR (Special Drawing Right)",
  "XOF": "CFA Franc",
  "XPD": "Palladium (troy ounce)",
  "XPF": "CFP Franc",
  "XPT": "Platinum (troy ounce)",
  "XSU": "Sucre",
  "XTS": "Codes specifically reserved for testing purposes",
  "XUA": "ADB Unit of Account",
  "XXX": "The codes assigned for transactions where no currency is involved",
  "YER": "Yemeni Rial",
  "ZAR": "South African Rand",
  "ZMW": "Zambian Kwacha",
  "ZWL": "Zimbabwe Dollar"
};

// Runtime metadata can extend the stable ISO registry when the provider adds a
// supported currency. The explicit registry remains the offline/old-WebView fallback.
const RUNTIME_CURRENCY_NAMES = Object.create(null);

// Public no-key global reference-rate feeds are used directly; no private API key or proxy is required.
const CURRENCY_RATE_CACHE_KEY = 'sumaire_currency_rates_v2';
const CURRENCY_PAIR_STORAGE_KEY = 'sa_currency_selected_pair_v1';

// Currency identity is independent of exchange-rate movement. Persist only the
// user's ISO 4217 pair; rate refreshes may update numeric quotes, never the codes.
function loadSavedCurrencyPair() {
  try {
    const saved = JSON.parse(localStorage.getItem(CURRENCY_PAIR_STORAGE_KEY) || 'null');
    const from = String(saved?.from || '').toUpperCase();
    const to = String(saved?.to || '').toUpperCase();
    const allowed = new Set(CURRENCY_CATALOG);
    if (allowed.has(from) && allowed.has(to)) return { from, to };
  } catch (_) { /* unavailable storage or invalid saved data: use defaults */ }
  return { from: 'USD', to: 'EUR' };
}

function saveSelectedCurrencyPair(from, to) {
  const source = String(from || '').toUpperCase();
  const target = String(to || '').toUpperCase();
  const allowed = new Set(CURRENCY_CATALOG);
  if (!allowed.has(source) || !allowed.has(target)) return false;
  try { localStorage.setItem(CURRENCY_PAIR_STORAGE_KEY, JSON.stringify({ from: source, to: target, savedAt: Date.now() })); return true; }
  catch (_) { return false; }
}
const CURRENCY_RATE_CACHE_MAX_AGE = 7 * 24 * 60 * 60 * 1000;

const NON_CURRENCY_CODES = new Set(['AFA','AOK','AON','AOR','ARP','ARY','ARZ','ATS','AZM','BAD','BEC','BEF','BEL','BGL','BGM','BOP','BRB','BRC','BRE','BRN','BRR','BRZ','BYB','BYR','CSD','CSK','CYP','DDM','DEM','ECS','ECV','EEK','ESA','ESB','ESP','FIM','FRF','GEK','GHC','GHP','GHR','GNE','GNS','GQE','GRD','GWE','GWP','HRK','IEP','ILP','ILR','ISJ','ITL','LTL','LTT','LUF','LVR','LVL','MAF','MCF','MDC','MGF','MKN','MTL','MTP','MVQ','MXP','MZE','MZM','NIC','NLG','PEH','PEI','PES','PLZ','PTE','RHD','ROL','RUR','SDD','SDP','SIT','SLL','SVC','SKK','SRG','SUR','TJR','TMM','TPE','TRL','UAK','UGS','USS','UYN','VEB','VEF','VNC','XEU','XFO','XFU','YDD','YUD','YUM','ZAL','ZMK','ZRN','ZRZ','ZWC','ZWD','ZWN','ZWR','ZWL','ANG','BGN','BOV','CHE','CHW','CLF','COU','MXV','USN','UYI','UYW','XAG','XAU','XBA','XBB','XBC','XBD','XDR','XPD','XPT','XSU','XTS','XUA','XXX','CUC','STD','MRO']);

function setRuntimeCurrencyNames(payload) {
  if (!payload || typeof payload !== 'object') return 0;
  let count = 0;
  Object.entries(payload).forEach(([code, rawName]) => {
    const normalized = String(code || '').toUpperCase();
    const name = String(rawName || '').trim();
    if (/^[A-Z]{3}$/.test(normalized) && name && name !== normalized) {
      RUNTIME_CURRENCY_NAMES[normalized] = name;
      count++;
    }
  });
  return count;
}

function currencyLabel(code) {
  const normalized = String(code || '').toUpperCase();
  const name = localizedCurrencyName(normalized);
  return name && name !== normalized ? `${name} · ${normalized}` : normalized;
}

function getAvailableCurrencyCodes() {
  // Keep the picker identical to the reference recording: a fixed, curated fiat list.
  // Rate-provider additions and ISO accounting/metal/test codes must not silently add rows.
  return [...new Set(CURRENCY_CATALOG)]
    .filter(code => Boolean(CURRENCY_DISPLAY_NAMES[code] || RUNTIME_CURRENCY_NAMES[code]))
    .sort((a, b) => currencyLabel(a).localeCompare(currencyLabel(b), CURRENCY_LOCALE_BY_LANGUAGE[STATE.language] || 'en'));
}

function getSupportedCurrencyRateCount(rates = STATE.currencies) {
  // Count only the currencies users can actually select in this converter;
  // provider-only codes are intentionally excluded from the UI count.
  return getAvailableCurrencyCodes().reduce((count, code) => {
    const value = Number(rates?.[code]);
    return count + (Number.isFinite(value) && value > 0 ? 1 : 0);
  }, 0);
}

function populateCurrencyOptions(preferredFrom = 'USD', preferredTo = 'INR') {
  const from = document.getElementById('cur-from');
  const to = document.getElementById('cur-to');
  if (!from || !to) return;
  const selectors = [[from, preferredFrom], [to, preferredTo]];
  const codes = getAvailableCurrencyCodes();
  selectors.forEach(([select, preferred]) => {
    const current = select.value;
    const fragment = document.createDocumentFragment();
    codes.forEach(code => {
      const option = document.createElement('option');
      option.value = code;
      // Match Unit Converter option presentation: the closed selector shows
      // only the compact ISO code via .currency-code-display, while the native
      // option list shows the full currency name followed by the short ISO code.
      option.textContent = `${code} — ${localizedCurrencyName(code) || currencyLabel(code) || code}`;
      option.disabled = false;
      fragment.appendChild(option);
    });
    select.replaceChildren(fragment);
    const desired = preferred && [...select.options].some(o => o.value === preferred)
      ? preferred
      : (current && [...select.options].some(o => o.value === current)
        ? current : select.options[0]?.value);
    if (desired) select.value = desired;
  });
  updateCurrencySelectionLabels();
}

// Representative territory flag for every currency in the selectable catalog.
// Regional currencies use a region flag where one exists (EUR); CFA/CFP use
// the main issuing-region/territory flag as a visual identifier. ISO code and
// full currency name remain the authoritative identity, never the flag alone.
const CURRENCY_FLAG_REGIONS = {
  ALL:'AL', DZD:'DZ', AOA:'AO', ARS:'AR', AUD:'AU', AZN:'AZ', BHD:'BH', BDT:'BD', BYN:'BY', BTN:'BT',
  BOB:'BO', BAM:'BA', BRL:'BR', GBP:'GB', BND:'BN', BGN:'BG', MMK:'MM', BIF:'BI', KHR:'KH', CAD:'CA',
  XAF:'CM', XOF:'SN', XPF:'PF', CLP:'CL', CNY:'CN', COP:'CO', CRC:'CR', HRK:'HR', CZK:'CZ', DKK:'DK',
  DOP:'DO', EGP:'EG', ETB:'ET', EUR:'EU', FJD:'FJ', GHS:'GH', HKD:'HK', HUF:'HU', ISK:'IS', INR:'IN',
  IDR:'ID', IRR:'IR', IQD:'IQ', ILS:'IL', JPY:'JP', JOD:'JO', KZT:'KZ', KES:'KE', KWD:'KW', KGS:'KG',
  LAK:'LA', LBP:'LB', MOP:'MO', MKD:'MK', MGA:'MG', MYR:'MY', MVR:'MV', MUR:'MU', MXN:'MX', MNT:'MN',
  MAD:'MA', NGN:'NG', NAD:'NA', NPR:'NP', TWD:'TW', NZD:'NZ', NIO:'NI', NOK:'NO', OMR:'OM', PKR:'PK',
  PGK:'PG', PYG:'PY', PEN:'PE', PHP:'PH', PLN:'PL', QAR:'QA', RON:'RO', RUB:'RU', RWF:'RW', SAR:'SA',
  RSD:'RS', SCR:'SC', SGD:'SG', ZAR:'ZA', KRW:'KR', LKR:'LK', SDG:'SD', SEK:'SE', CHF:'CH', SYP:'SY',
  TJS:'TJ', TZS:'TZ', THB:'TH', TND:'TN', TRY:'TR', TMT:'TM', UGX:'UG', UAH:'UA', AED:'AE', UYU:'UY',
  USD:'US', UZS:'UZ', VND:'VN', YER:'YE', ZMW:'ZM'
};
function regionCodeToFlag(region) {
  const code = String(region || '').toUpperCase();
  if (code === 'EU') return '🇪🇺';
  if (code === 'UN') return '🇺🇳';
  if (!/^[A-Z]{2}$/.test(code)) return '🌐';
  return String.fromCodePoint(...[...code].map(char => 127397 + char.charCodeAt(0)));
}
function currencyFlagForCode(currencyCode) {
  return regionCodeToFlag(CURRENCY_FLAG_REGIONS[String(currencyCode || '').toUpperCase()]);
}
function currencyRegionNameForCode(currencyCode) {
  const region = CURRENCY_FLAG_REGIONS[String(currencyCode || '').toUpperCase()];
  if (!region) return 'International currency';
  try {
    const locale = CURRENCY_LOCALE_BY_LANGUAGE[STATE.language] || 'en';
    return new Intl.DisplayNames([locale], { type: 'region' }).of(region) || region;
  } catch (_) { return region; }
}

function updateCurrencyDisplayChrome() { updateCurrencySelectionLabels(); }

function updateCurrencySelectionLabels() {
  const from = document.getElementById('cur-from');
  const to = document.getElementById('cur-to');
  if (!from || !to) return;
  const fromCode = String(from.value || 'USD').toUpperCase();
  const toCode = String(to.value || 'INR').toUpperCase();
  const fromName = localizedCurrencyName(fromCode);
  const toName = localizedCurrencyName(toCode);
  setElementText('cur-from-name', fromName);
  setElementText('cur-to-name', toName);
  setElementText('cur-from-code-display', fromCode || '—');
  setElementText('cur-to-code-display', toCode || '—');
  const currencyFlag = currencyFlagForCode;
  setElementText('cur-from-flag', currencyFlag(fromCode));
  setElementText('cur-to-flag', currencyFlag(toCode));
  document.getElementById('cur-from')?.closest('.currency-select-wrap')?.setAttribute('data-currency', fromCode);
  document.getElementById('cur-to')?.closest('.currency-select-wrap')?.setAttribute('data-currency', toCode);
  from.setAttribute('aria-label', `From currency: ${fromCode}`);
  to.setAttribute('aria-label', `To currency: ${toCode}`);
  from.title = fromCode;
  to.title = toCode;
  updateCurrencyProviderAttribution(fromCode, toCode);
}

function loadCachedCurrencyRates() {
  // A first launch without internet must still allow basic conversions. Keep
  // the small bundled table, but label it as estimates until a dated feed lands.
  STATE.currencies = { ...BUILTIN_CURRENCY_RATES };
  STATE.currencyUpdatedAt = 0;
  STATE.currencyRateDate = null;
  STATE.currencyRateDates = {};
  STATE.currencyRateSources = {};
  STATE.currencyRateSource = 'built-in fallback';
  try {
    const raw = localStorage.getItem(CURRENCY_RATE_CACHE_KEY);
    if (!raw) return false;
    const parsed = JSON.parse(raw);
    const rates = parsed?.rates;
    const savedAt = Number(parsed?.savedAt || 0);
    if (!rates || typeof rates !== 'object' || !savedAt || savedAt > Date.now() + 60000 || Date.now() - savedAt > CURRENCY_RATE_CACHE_MAX_AGE) return false;
    const clean = {};
    const cleanDates = {};
    const suppliedDates = parsed.rateDates && typeof parsed.rateDates === 'object' ? parsed.rateDates : null;
    // Older cache entries have only one aggregate date. It is safe to apply that
    // date to every pair; a cache with no observation date is not safe to reuse.
    const legacyDate = parsed.rateDate ? String(parsed.rateDate) : '';
    if (!suppliedDates && !legacyDate) return false;
    Object.entries(rates).forEach(([code, value]) => {
      const c=String(code).toUpperCase(), n=Number(value);
      if (!/^[A-Z]{3}$/.test(c) || !Number.isFinite(n) || n<=0 || n>=1e12) return;
      const rawDate = suppliedDates ? suppliedDates[c] : legacyDate;
      try { cleanDates[c] = validateCurrencyRateDate(rawDate, `Cached ${c} rates`); }
      catch (_) { return; }
      clean[c]=n;
    });
    if (Object.keys(clean).length < 10) return false;
    const dateValues = Object.values(cleanDates).sort();
    STATE.currencies=clean; STATE.currencyRateDates=cleanDates; STATE.currencyUpdatedAt=savedAt;
    STATE.currencyRateDate=dateValues.length ? dateValues[dateValues.length-1] : null;
    STATE.currencyRateSources = parsed.rateSources && typeof parsed.rateSources === 'object' ? Object.fromEntries(Object.entries(parsed.rateSources).filter(([c,v]) => clean[c] && typeof v === 'string').map(([c,v]) => [c, sanitizeCurrencySourceLabel(v) || 'cached'])) : Object.fromEntries(Object.keys(clean).map(c => [c, String(parsed.source || 'cached')]));
    STATE.currencyRateSource=String(parsed.source || 'cached');
    setRuntimeCurrencyNames(parsed.names);
    return true;
  } catch (_) { return false; }
}

function saveCurrencyRateCache(bundle) {
  try {
    localStorage.setItem(CURRENCY_RATE_CACHE_KEY, JSON.stringify({
      savedAt: Date.now(), rates: bundle.rates, rateDate: bundle.rateDate || null, rateDates: bundle.rateDates || Object.fromEntries(Object.keys(bundle.rates || {}).map(code => [code, bundle.rateDate || null])), rateSources: bundle.rateSources || Object.fromEntries(Object.keys(bundle.rates || {}).map(code => [code, bundle.source || 'online'])), source: bundle.source || 'online', names: RUNTIME_CURRENCY_NAMES
    }));
  } catch (_) {}
}

let currencyAutoRefreshTimer = null;
let currencyLastRefreshAttempt = 0;
const CURRENCY_REFRESH_META_KEY = 'sa_currency_refresh_meta_v1';

function formatCurrencyRefreshTimestamp(timestamp) {
  const value = Number(timestamp);
  if (!Number.isFinite(value) || value <= 0 || value > Date.now() + 60000) return 'Not yet';
  try {
    return new Intl.DateTimeFormat(globalThis.SALocalization?.locale || undefined, { year: 'numeric', month: 'short', day: '2-digit', hour: '2-digit', minute: '2-digit', second: '2-digit' }).format(new Date(value));
  } catch (_) { return new Intl.DateTimeFormat(globalThis.SALocalization?.locale || undefined).format(new Date(value)); }
}

function renderCurrencyRefreshTimes() {
  const node = document.getElementById('cur-refresh-time');
  if (!node) return;
  const checked = formatCurrencyRefreshTimestamp(STATE.currencyLastRefreshAt);
  const updated = formatCurrencyRefreshTimestamp(STATE.currencyLastSuccessfulRefreshAt);
  const message = `Last checked: ${checked} · Rates last updated: ${updated}`;
  node.textContent = message;
  node.setAttribute('aria-label', `${message}. Times are shown in your device's local time.`);
}

function loadCurrencyRefreshMeta() {
  try {
    const raw = localStorage.getItem(CURRENCY_REFRESH_META_KEY);
    if (!raw) {
      // Migrate the v87 cached-success timestamp when no dedicated refresh metadata exists yet.
      if (Number(STATE.currencyUpdatedAt) > 0) {
        STATE.currencyLastRefreshAt = Number(STATE.currencyUpdatedAt);
        STATE.currencyLastSuccessfulRefreshAt = Number(STATE.currencyUpdatedAt);
      }
      renderCurrencyRefreshTimes();
      return false;
    }
    const meta = JSON.parse(raw);
    const validTime = value => Number.isFinite(Number(value)) && Number(value) > 0 && Number(value) <= Date.now() + 60000 ? Number(value) : null;
    STATE.currencyLastRefreshAt = validTime(meta.lastRefreshAt);
    STATE.currencyLastSuccessfulRefreshAt = validTime(meta.lastSuccessfulRefreshAt);
    renderCurrencyRefreshTimes();
    return true;
  } catch (_) { renderCurrencyRefreshTimes(); return false; }
}

function saveCurrencyRefreshMeta() {
  try {
    localStorage.setItem(CURRENCY_REFRESH_META_KEY, JSON.stringify({ lastRefreshAt: STATE.currencyLastRefreshAt || null, lastSuccessfulRefreshAt: STATE.currencyLastSuccessfulRefreshAt || null }));
  } catch (_) {}
  renderCurrencyRefreshTimes();
}

let currencyRetryDelay = 0;
let currencyRetryTimer = null;

function scheduleCurrencyAutoRefresh() {
  if (currencyAutoRefreshTimer) clearInterval(currencyAutoRefreshTimer);
  // Reference-rate providers publish daily data. Check hourly while the app is
  // open, and refresh on resume/network recovery without continuous polling.
  currencyAutoRefreshTimer = setInterval(() => {
    if (document.hidden || navigator.onLine === false) return;
    refreshCurrencyRates(false);
  }, 60 * 60 * 1000);
  if (!window.__sumaireCurrencyNetworkListeners) {
    window.__sumaireCurrencyNetworkListeners = true;
    document.addEventListener('visibilitychange', () => { if (!document.hidden && navigator.onLine !== false && !currencyRetryTimer && (currencyRetryDelay > 0 || Date.now()-currencyLastRefreshAttempt > 30*60*1000)) refreshCurrencyRates(false); });
    window.addEventListener('online', () => { currencyRetryDelay=0; if (currencyRetryTimer) { clearTimeout(currencyRetryTimer); currencyRetryTimer=null; } refreshCurrencyRates(false); });
    window.addEventListener('offline', () => { const status=document.getElementById('cur-rate-status'); const hasRates=STATE.currencies&&Object.keys(STATE.currencies).length; const fallback=STATE.currencyRateSource==='built-in fallback'; const pair=[document.getElementById('cur-from')?.value||'USD',document.getElementById('cur-to')?.value||'INR']; const pairSources=getCurrencyPairSources(pair[0],pair[1]); if(status)setCurrencyRateStatus(hasRates?(fallback?'Offline · showing built-in estimate rates':'Offline · showing last known reference rates'):'Network required for current rates',pairSources.join(' + ')); });
  }
}

function getCurrencySwapAmounts(fromAmount, toAmount) {
  // Preserve exact raw values when reversing a conversion pair.
  return { from: String(toAmount ?? '0'), to: String(fromAmount ?? '0') };
}

function initCurrencies() {
  const fromSel = document.getElementById('cur-from');
  const toSel = document.getElementById('cur-to');
  if (!fromSel || !toSel) return;
  loadCachedCurrencyRates();
  loadCurrencyRefreshMeta();
  // v87 excludes charts and saved currency pairs; clear their obsolete local data.
  try { localStorage.removeItem('sa_currency_watchlist_v1'); localStorage.removeItem('sa_currency_history_v1'); } catch (_) {}
  const savedPair = loadSavedCurrencyPair();
  populateCurrencyOptions(savedPair.from, savedPair.to);
  // Currency selects use the single accessible Sumaire picker. Do not attach a
  // second pointer handler: it races Android WebView's native select UI.
  requestAnimationFrame(() => updateCurrencySelectionLabels());
  setTimeout(() => updateCurrencySelectionLabels(), 0);
  const initialStatus = document.getElementById('cur-rate-status');
  if (initialStatus) {
    if (STATE.currencyRateSource === 'built-in fallback') setCurrencyRateStatus('Offline estimates · checking for current reference rates');
    else if (Object.keys(STATE.currencies || {}).length) { const pair = [fromSel.value || 'USD', toSel.value || 'INR']; setCurrencyRateStatus('Cached reference observations · checking for fresh data…', getCurrencyPairSources(pair[0], pair[1]).join(' + ')); }
    else setCurrencyRateStatus('Connecting to exchange-rate providers…');
  }
  observeCurrencyDisplaySizes();
  fromSel.addEventListener('change', () => { saveSelectedCurrencyPair(fromSel.value, toSel.value); updateCurrencyDisplayChrome(); calcCurrency(); if (!STATE.currencies?.[fromSel.value] || !STATE.currencies?.[toSel.value]) refreshCurrencyRates(false); });
  toSel.addEventListener('change', () => { saveSelectedCurrencyPair(fromSel.value, toSel.value); updateCurrencyDisplayChrome(); calcCurrency(); if (!STATE.currencies?.[fromSel.value] || !STATE.currencies?.[toSel.value]) refreshCurrencyRates(false); });
  const swapBtn = document.getElementById('btn-cur-swap');
  swapBtn?.addEventListener('click', () => {
    const from=fromSel.value,to=toSel.value;
    const fromEl=document.getElementById('cur-amount');
    const toEl=document.getElementById('cur-to-amount');
    if(!from||!to||!fromEl||!toEl) return;
    // A true pair swap exchanges both visible amounts as well as both codes.
    // Read derived raw values before changing the pair so precision is retained.
    const swappedAmounts=getCurrencySwapAmounts(getCurrencyAmountRaw('cur-amount'),getCurrencyAmountRaw('cur-to-amount'));
    swapBtn.classList.add('is-swapping'); swapBtn.setAttribute('aria-busy','true');
    fromSel.value=to; toSel.value=from; saveSelectedCurrencyPair(fromSel.value, toSel.value); updateCurrencySelectionLabels();
    setCurrencyAmountRaw('cur-amount',swappedAmounts.from,false);
    setCurrencyAmountRaw('cur-to-amount',swappedAmounts.to,true);
    setActiveInput(fromEl); calcCurrency();
    requestAnimationFrame(()=>{swapBtn.classList.remove('is-swapping');swapBtn.removeAttribute('aria-busy');fitCurrencyDisplays();});
  });
  document.getElementById('btn-refresh-rates')?.addEventListener('click', () => {
    const now = Date.now();
    // Prevent repeated taps from stacking identical provider requests/toasts.
    if (currencyRefreshPromise || now < currencyManualRefreshCooldownUntil) return;
    currencyManualRefreshCooldownUntil = now + 5000;
    refreshCurrencyRates(true);
  });
  // Currency conversion is live: amount edits, pair changes and swaps call calcCurrency().
  // No manual Convert action is needed.
  const amountEl=document.getElementById('cur-amount');
  if(amountEl && !amountEl.querySelector('.input-text')?.textContent.trim()) amountEl.querySelector('.input-text').textContent='0';
  setActiveInput(amountEl); calcCurrency(); refreshCurrencyRates(false); scheduleCurrencyAutoRefresh();
}


// Respect provider throttling. Retry-After may be seconds or an HTTP date.
function parseRetryAfter(value, now = Date.now()) {
  if (value == null || value === '') return 0;
  const raw = String(value).trim();
  if (/^\d+(?:\.\d+)?$/.test(raw)) return Math.max(0, Math.min(24 * 60 * 60 * 1000, Math.ceil(Number(raw) * 1000)));
  const timestamp = Date.parse(raw);
  return Number.isFinite(timestamp) ? Math.max(0, Math.min(24 * 60 * 60 * 1000, timestamp - now)) : 0;
}

// Bound both the network response and JSON parsing. AbortController is an
// optimization; Promise.race keeps older/restricted WebViews from hanging forever.
async function fetchWithTimeout(url, timeoutMs = 9000) {
  const controller = typeof AbortController !== 'undefined' ? new AbortController() : null;
  let timeoutId = null;
  const timeoutPromise = new Promise((_, reject) => {
    timeoutId = setTimeout(() => {
      try { controller?.abort(); } catch (_) {}
      reject(new Error('Currency rate request timed out'));
    }, timeoutMs);
  });
  // Keep both the network response and body parsing inside the same deadline.
  // Some restricted WebViews can stall while consuming response.json().
  const requestPromise = (async () => {
    const response = await fetch(url, { cache: 'no-store', signal: controller?.signal });
    if (!response.ok) {
      const error = new Error(`HTTP ${response.status}`);
      error.status = response.status;
      error.retryAfterMs = parseRetryAfter(response.headers?.get?.('Retry-After'));
      throw error;
    }
    return response.json();
  })();
  try {
    return await Promise.race([requestPromise, timeoutPromise]);
  } finally {
    if (timeoutId !== null) clearTimeout(timeoutId);
  }
}

function normalizeCurrencyApiRates(payload) {
  if (!payload?.usd || typeof payload.usd !== 'object' || !payload?.date) throw new Error('Invalid Currency API response');
  const rates = { USD: 1 };
  Object.entries(payload.usd).forEach(([rawCode, rawValue]) => {
    const code = String(rawCode || '').toUpperCase(), value = Number(rawValue);
    if (/^[A-Z]{3}$/.test(code) && !NON_CURRENCY_CODES.has(code) && Number.isFinite(value) && value > 0 && value < 1e12) rates[code] = value;
  });
  if (Object.keys(rates).length < 100) throw new Error('Incomplete Currency API rate table');
  const rateDate = validateCurrencyRateDate(payload.date, 'Fawaz Exchange API', 4);
  return { rates, rateDate, rateDates: Object.fromEntries(Object.keys(rates).map(code => [code, rateDate])), rateSources: Object.fromEntries(Object.keys(rates).map(code => [code, 'Fawaz Exchange API'])), source: 'Fawaz Exchange API' };
}
function normalizeOpenExchangeRates(payload) {
  if (payload?.result !== 'success' || String(payload?.base_code || '').toUpperCase() !== 'USD' || !payload?.rates || typeof payload.rates !== 'object') throw new Error(payload?.['error-type'] || 'Invalid open exchange-rate response');
  const rates = { USD: 1 };
  Object.entries(payload.rates).forEach(([rawCode, rawValue]) => { const code=String(rawCode||'').toUpperCase(), value=Number(rawValue); if (/^[A-Z]{3}$/.test(code)&&!NON_CURRENCY_CODES.has(code)&&Number.isFinite(value)&&value>0&&value<1e12) rates[code]=value; });
  if (Object.keys(rates).length < 40) throw new Error('Incomplete open exchange-rate table');
  const updated=payload.time_last_update_utc?new Date(payload.time_last_update_utc):null;
  if (!updated || !Number.isFinite(updated.getTime())) throw new Error('Open ER-API: missing update timestamp');
  const rateDate = validateCurrencyRateDate(updated.toISOString().slice(0,10), 'Open ER-API', 4);
  return { rates, rateDate, rateDates: Object.fromEntries(Object.keys(rates).map(code => [code, rateDate])), rateSources: Object.fromEntries(Object.keys(rates).map(code => [code, 'Open ER-API'])), source:'Open ER-API' };
}
function validateCurrencyRateDate(rawDate, label, maxAgeDays = 10) {
  const value = String(rawDate || '');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) throw new Error(`${label}: invalid rate date`);
  const parsed = new Date(`${value}T00:00:00.000Z`);
  // Date.parse alone normalizes impossible dates (for example, Feb 31) on some engines.
  if (!Number.isFinite(parsed.getTime()) || parsed.toISOString().slice(0, 10) !== value) throw new Error(`${label}: invalid rate date`);
  const ageDays = (Date.now() - parsed.getTime()) / 86400000;
  if (ageDays < -1 || ageDays > maxAgeDays) throw new Error(`${label}: rate data is stale or future-dated`);
  return value;
}
function normalizeFrankfurterV2Rates(payload) {
  if (!Array.isArray(payload) || payload.length < 20) throw new Error('Frankfurter v2: incomplete rate table');
  const rates = { USD: 1 };
  let rateDate = null;
  const rateDates = {};
  const rateSources = {};
  let acceptedRows = 0;
  for (const row of payload) {
    if (String(row?.base || '').toUpperCase() !== 'USD') continue;
    const code = String(row?.quote || '').toUpperCase(), value = Number(row?.rate);
    if (!/^[A-Z]{3}$/.test(code) || NON_CURRENCY_CODES.has(code) || !Number.isFinite(value) || value <= 0 || value >= 1e12 || !row?.date) continue;
    let rowDate;
    try { rowDate = validateCurrencyRateDate(row.date, 'Frankfurter v2'); } catch (_) { continue; }
    // Frankfurter combines providers with different publication calendars. Never
    // let one fresh row make an old row look current; discard stale rows individually.
    rates[code] = value;
    rateDates[code] = rowDate;
    // Frankfurter's expanded provider metadata contains objects, not always
    // strings. Keep the UI attribution concise and never stringify objects.
    rateSources[code] = 'Frankfurter v2';
    acceptedRows++;
    if (!rateDate || rowDate > rateDate) rateDate = rowDate;
  }
  if (acceptedRows < 20) throw new Error('Frankfurter v2: invalid, stale, or incomplete USD rates');
  rateDates.USD = rateDate;
  rateSources.USD = 'USD base';
  return { rates, rateDate, rateDates, rateSources, source: 'Frankfurter v2 (per-currency dates validated)' };
}
async function fetchCurrencyRateBundle(requiredCodes = []) {
  // Public, keyless global reference-rate APIs only. Frankfurter is primary:
  // free for commercial use, no API key, broad multi-source coverage and
  // per-currency observation dates. Open ER-API and Fawaz are independent
  // fallbacks. Merge by each quote's own observation date; never call these
  // reference rates live executable bank/card/remittance quotes.
  const providers=[
    {name:'Frankfurter v2', urls:['https://api.frankfurter.dev/v2/rates?base=USD&expand=providers'],normalize:normalizeFrankfurterV2Rates},
    {name:'Open ER-API', urls:['https://open.er-api.com/v6/latest/USD'],normalize:normalizeOpenExchangeRates},
    {name:'Fawaz Exchange API', urls:['https://cdn.jsdelivr.net/npm/@fawazahmed0/currency-api@latest/v1/currencies/usd.min.json','https://latest.currency-api.pages.dev/v1/currencies/usd.min.json'],normalize:normalizeCurrencyApiRates}
  ];
  const failures=[]; let retryAfterMs=0; let combined=null;
  const missing = () => requiredCodes.filter(code => code && code !== 'USD' && !combined?.rates?.[code]);
  for (const provider of providers) {
    let bundle=null;
    for (const url of provider.urls) {
      try { bundle=provider.normalize(await fetchWithTimeout(url,10000)); break; }
      catch(error) { retryAfterMs=Math.max(retryAfterMs,Number(error?.retryAfterMs)||0); failures.push(`${new URL(url).hostname}: ${error?.message||'Provider unavailable'}`); }
    }
    if (!bundle) continue;
    if (!combined) combined={...bundle, rates:{...bundle.rates}, rateDates:{...bundle.rateDates}, rateSources:{...(bundle.rateSources||{})}, source:bundle.source};
    else {
      const merged=mergeCurrencyRateBundles(combined.rates, combined.rateDates, bundle.rates, bundle.rateDates, combined.rateSources, bundle.rateSources);
      (merged.acceptedCodes || []).forEach(code => {
        combined.rateSources[code] = bundle.rateSources?.[code] || bundle.source;
      });
      combined.rates=merged.rates; combined.rateDates=merged.rateDates; combined.rateDate=merged.rateDate;
      combined.source='Multi-source reference rates';
    }
  }
  if (!combined) { const error = new Error(`All exchange-rate providers failed: ${failures.join('; ')}`); error.retryAfterMs = retryAfterMs; throw error; }
  combined.missingRequired=missing(); combined.retryAfterMs=retryAfterMs;
  return combined;
}

function sanitizeCurrencySourceLabel(value) {
  if (typeof value !== 'string') return '';
  const source = value.trim();
  if (!source) return '';
  // Older builds persisted expanded provider objects as the literal text
  // `[object Object]`. Recover the stable provider family from those caches.
  if (/\[object Object\]/i.test(source)) {
    const family = source.split(/[·|]/, 1)[0].trim();
    return family || 'Currency reference provider';
  }
  return source;
}

function getCurrencyPairSources(fromCode, toCode, sources = STATE.currencyRateSources) {
  return [...new Set([fromCode, toCode].map(code => sanitizeCurrencySourceLabel(sources?.[code])).filter(source => source && source !== 'USD base'))];
}
function updateCurrencyProviderAttribution(fromCode, toCode) {
  const attribution = document.getElementById('cur-provider-attribution');
  if (attribution) attribution.hidden = !getCurrencyPairSources(fromCode, toCode).some(source => String(source).toLowerCase().includes('open er-api'));
}
function setCurrencyRateStatus(message, source = '') {
  const attribution = document.getElementById('cur-provider-attribution');
  if (attribution) attribution.hidden = !String(source || '').toLowerCase().includes('open er-api');
  const status = document.getElementById('cur-rate-status');
  if (!status) return;
  status.hidden = false;
  status.removeAttribute('aria-hidden');
  const cleanMessage = String(message || '');
  const sourceLabel = String(source || '');
  status.textContent = sourceLabel && !cleanMessage.toLowerCase().includes(sourceLabel.toLowerCase())
    ? `${cleanMessage} · ${sourceLabel}` : cleanMessage;
}

// Keep the newest observation per currency; late/older responses cannot roll rates back.
function mergeCurrencyRateBundles(currentRates, currentDates, incomingRates, incomingDates, currentSources, incomingSources) {
  currentSources = currentSources || {};
  incomingSources = incomingSources || {};
  const rates = { ...(currentRates || {}) };
  const dates = { ...(currentDates || {}) };
  const acceptedCodes = [];
  Object.entries(incomingRates || {}).forEach(([rawCode, rawValue]) => {
    const code = String(rawCode || '').toUpperCase();
    const value = Number(rawValue);
    const incomingDate = String(incomingDates?.[code] || '');
    if (!/^[A-Z]{3}$/.test(code) || !Number.isFinite(value) || value <= 0 || value >= 1e12) return;
    try { validateCurrencyRateDate(incomingDate, `Incoming ${code} rate`); } catch (_) { return; }
    const currentDate = String(dates[code] || '');
    if (currentDate && incomingDate < currentDate) return;
    // For same-day observations, keep the already-selected provider's value
    // unless the observation is from that same provider. This avoids silently
    // replacing one same-date source with another during fallback merging.
    const currentSource = String(currentSources?.[code] || '');
    const incomingSource = String(incomingSources?.[code] || '');
    if (currentDate && incomingDate === currentDate && currentSource && incomingSource && currentSource !== incomingSource) return;
    rates[code] = value; dates[code] = incomingDate; acceptedCodes.push(code);
  });
  const allDates = Object.values(dates).filter(v => /^\d{4}-\d{2}-\d{2}$/.test(v)).sort();
  return { rates, rateDates: dates, rateDate: allDates.length ? allDates[allDates.length - 1] : null, accepted: acceptedCodes.length, acceptedCodes };
}
function getCurrencyPairObservationDate(fromCode, toCode, rateDates, fallbackDate = null) {
  if (fromCode === toCode) return null;
  if (fromCode === 'USD') return rateDates?.[toCode] || null;
  if (toCode === 'USD') return rateDates?.[fromCode] || null;
  const a = rateDates?.[fromCode], b = rateDates?.[toCode];
  if (a && b) return a < b ? a : b;
  return null;
}

let currencyRefreshPromise = null;
let currencyManualRefreshCooldownUntil = 0;
async function refreshCurrencyRates(showFeedback = true) {
  if(currencyRefreshPromise) return currencyRefreshPromise;
  currencyLastRefreshAttempt=Date.now();
  const btn=document.getElementById('btn-refresh-rates'); if(btn){btn.disabled=true;btn.setAttribute('aria-busy','true');}
  let requestedPair = [];
  currencyRefreshPromise=(async()=>{
    try {
      requestedPair=[document.getElementById('cur-from')?.value || 'USD', document.getElementById('cur-to')?.value || 'INR'];
      const bundle=await fetchCurrencyRateBundle(requestedPair);
      const incomingDates = bundle.rateDates || Object.fromEntries(Object.keys(bundle.rates || {}).map(code => [code, bundle.rateDate || null]));
      const merged = mergeCurrencyRateBundles(STATE.currencies, STATE.currencyRateDates, bundle.rates, incomingDates, STATE.currencyRateSources, bundle.rateSources);
      if (merged.accepted === 0 && Object.keys(STATE.currencies || {}).length) throw new Error('Provider returned no newer usable currency observations');
      STATE.currencies = merged.rates;
      STATE.currencyRateSource = bundle.source || 'online';
      STATE.currencyRateSources = { ...(STATE.currencyRateSources || {}) };
      (merged.acceptedCodes || []).forEach(code => { STATE.currencyRateSources[code] = bundle.rateSources?.[code] || bundle.source || 'online'; });
      STATE.currencyRateDates = merged.rateDates;
      STATE.currencyRateDate = merged.rateDate;
      STATE.currencyUpdatedAt = Date.now();
      STATE.currencyLastSuccessfulRefreshAt = STATE.currencyUpdatedAt;
      const missingRequired = Array.isArray(bundle.missingRequired) ? bundle.missingRequired : [];
      if (missingRequired.length) {
        // A partial provider response is useful, but it is not a complete pair.
        // Keep the accepted observations and retry the missing selected currency
        // with bounded backoff instead of silently treating the refresh as done.
        const exponential = Math.min(currencyRetryDelay ? currencyRetryDelay * 2 : 5 * 60 * 1000, 6 * 60 * 60 * 1000);
        const jittered = Math.round(exponential * (0.85 + Math.random() * 0.30));
        currencyRetryDelay = Math.max(Number(bundle.retryAfterMs) || 0, jittered, 5 * 60 * 1000);
        if (currencyRetryTimer) clearTimeout(currencyRetryTimer);
        currencyRetryTimer = setTimeout(() => {
          currencyRetryTimer = null;
          if (!document.hidden && navigator.onLine !== false) refreshCurrencyRates(false);
        }, currencyRetryDelay);
      } else {
        currencyRetryDelay = 0;
        if (currencyRetryTimer) { clearTimeout(currencyRetryTimer); currencyRetryTimer = null; }
      }
      saveCurrencyRateCache({ ...bundle, rates: STATE.currencies, rateDates: STATE.currencyRateDates, rateSources: STATE.currencyRateSources, rateDate: STATE.currencyRateDate });
      const from = document.getElementById('cur-from')?.value || 'USD';
      const to = document.getElementById('cur-to')?.value || 'INR';
      populateCurrencyOptions(from, to);
      updateCurrencySelectionLabels();
      calcCurrency();
      const selectedPair = [document.getElementById('cur-from')?.value || 'USD', document.getElementById('cur-to')?.value || 'INR'];
      const pairSource = getCurrencyPairSources(selectedPair[0], selectedPair[1]).join(' + ');
      updateCurrencyProviderAttribution(selectedPair[0], selectedPair[1]);
      const missingText = missingRequired.length ? ` · unavailable: ${missingRequired.join(', ')} (retry scheduled)` : '';
      setCurrencyRateStatus(`Reference rates updated · ${bundle.source || 'Online provider'}${missingText}`, pairSource);
      if (showFeedback) {
        const catalogCount = getAvailableCurrencyCodes().length;
        const supportedRateCount = getSupportedCurrencyRateCount(STATE.currencies);
        showToast(supportedRateCount === catalogCount
          ? `Exchange rates updated · ${supportedRateCount} supported currencies`
          : `Exchange rates updated · ${supportedRateCount} of ${catalogCount} supported currencies`);
      }
      return true;
    } catch(error) {
      const hasCached=Object.keys(STATE.currencies||{}).length>0 && STATE.currencyRateSource!=='built-in fallback';
      const hasFallback=Object.keys(STATE.currencies||{}).length>0 && STATE.currencyRateSource==='built-in fallback';
      const providerDelay = Number(error?.retryAfterMs) || 0;
      const exponential = Math.min(currencyRetryDelay ? currencyRetryDelay * 2 : 30000, 30 * 60 * 1000);
      const jittered = Math.round(exponential * (0.85 + Math.random() * 0.30));
      currencyRetryDelay = providerDelay > 0 ? Math.max(providerDelay, 30 * 1000) : jittered;
      if (currencyRetryTimer) clearTimeout(currencyRetryTimer);
      currencyRetryTimer = setTimeout(() => {
        currencyRetryTimer = null;
        if (!document.hidden && navigator.onLine !== false) refreshCurrencyRates(false);
      }, currencyRetryDelay);
      const status=document.getElementById('cur-rate-status');
      if (status) {
        const pair = [document.getElementById('cur-from')?.value || 'USD', document.getElementById('cur-to')?.value || 'INR'];
        const pairSources = getCurrencyPairSources(pair[0], pair[1]);
        setCurrencyRateStatus(hasCached ? 'Cached reference rates · live refresh unavailable' : (hasFallback ? 'Built-in estimate rates · live refresh unavailable' : (navigator.onLine === false ? 'Network required for current rates' : 'Live rate unavailable · retry scheduled')), pairSources.join(' + '));
      }
      if(showFeedback) showToast(hasCached?'Showing last known rates; live refresh failed.':(hasFallback?'Showing built-in estimates; connect to update rates.':'Live rate refresh failed.'));
      return false;
    } finally {
      STATE.currencyLastRefreshAt = Date.now();
      saveCurrencyRefreshMeta();
      if(btn){btn.disabled=false;btn.removeAttribute('aria-busy');}
      currencyRefreshPromise=null;
      const selectedPair=[document.getElementById('cur-from')?.value || 'USD', document.getElementById('cur-to')?.value || 'INR'];
      if (selectedPair.some((code,index)=>code!==requestedPair[index]) && selectedPair.some(code=>code!=='USD' && !STATE.currencies?.[code]) && navigator.onLine !== false) {
        setTimeout(() => refreshCurrencyRates(false), 0);
      }
    }
  })();
  return currencyRefreshPromise;
}

// Currency values must remain fully readable on narrow phones and with 15-digit inputs.
function fitCurrencyTextElement(element, maxSize, minSize) {
  if (!element) return;
  const text = (element.textContent || '').trim();
  if (!text || text === '—') return;

  // The sizing contract is intentionally staged: the same 20px size used by
  // Unit Converter is kept for 0 and every value that still fits comfortably.
  // Only after the actual inner boundary is reached do we shrink, and we do
  // so continuously rather than jumping at a digit-count threshold.
  const parent = element.parentElement;
  const box = parent || element;
  const boxWidth = box.clientWidth || box.getBoundingClientRect().width || 24;
  const style = getComputedStyle(element);
  const weight = style.fontWeight || '600';
  const family = style.fontFamily || 'sans-serif';
  const letterSpacing = style.letterSpacing === 'normal' ? 0 : parseFloat(style.letterSpacing) || 0;
  const horizontalPadding = 20;
  const available = Math.max(24, boxWidth - horizontalPadding);
  const canvas = fitCurrencyTextElement.canvas || (fitCurrencyTextElement.canvas = document.createElement('canvas'));
  const ctx = canvas.getContext('2d');
  if (!ctx) return;

  const base = Math.min(20, Number(maxSize) || 20);
  const floor = Math.max(12, Number(minSize) || 12);
  const measure = size => {
    ctx.font = `${weight} ${size}px ${family}`;
    const width = ctx.measureText(text).width;
    return width + Math.max(0, text.length - 1) * letterSpacing;
  };

  const baseWidth = measure(base);
  let target = base;
  if (baseWidth > available) {
    // Proportional first pass gives the requested gentle, progressive shrink.
    target = Math.max(floor, base * (available / baseWidth));
    // Fine tune downward by a tiny amount so the final glyphs never touch the
    // clipping boundary after Android/WebView font rasterization.
    for (let i = 0; i < 6 && measure(target) > available; i++) target -= 0.25;
    target = Math.max(floor, target);
  }

  // Avoid visible jitter when the same value is recalculated repeatedly.
  const rounded = Math.min(base, Math.max(floor, target)).toFixed(2);
  if (element.style.fontSize !== `${rounded}px`) element.style.fontSize = `${rounded}px`;
  element.style.letterSpacing = text.length > 18 ? '-0.02em' : 'normal';
  element.title = text;
}
function fitCurrencyDisplays() {
  fitCurrencyTextElement(document.querySelector('#cur-amount .input-text'), 20, 12);
  fitCurrencyTextElement(document.querySelector('#cur-to-amount .input-text'), 20, 12);
}
let currencyDisplayObserver = null;
function observeCurrencyDisplaySizes() {
  if (typeof ResizeObserver === 'undefined' || currencyDisplayObserver) return;
  currencyDisplayObserver = new ResizeObserver(() => {
    if (window.currencyFitFrame) cancelAnimationFrame(window.currencyFitFrame);
    window.currencyFitFrame = requestAnimationFrame(() => {
      window.currencyFitFrame = 0;
      fitCurrencyDisplays();
    });
  });
  ['#screen-currencies .input-row', '#cur-amount', '#cur-to-amount']
    .forEach(selector => { const el = document.querySelector(selector); if (el) currencyDisplayObserver.observe(el); });
}

// V45 decimal-safe currency math: avoid IEEE-754 integer loss for 15-digit inputs.
function decimalParts(value) {
  let s = String(value ?? '').trim();
  if (!s) return null;
  if (/e/i.test(s)) {
    const n = Number(s);
    if (!Number.isFinite(n)) return null;
    s = n.toFixed(20).replace(/0+$/, '').replace(/\.$/, '');
  }
  const sign = s.startsWith('-') ? -1 : 1;
  s = s.replace(/^[+-]/, '');
  if (!/^\d+(?:\.\d+)?$/.test(s)) return null;
  const [whole, frac=''] = s.split('.');
  const digits = (whole.replace(/^0+(?=\d)/, '') + frac).replace(/^0+(?=\d)/, '') || '0';
  return { sign, digits, scale: frac.length };
}
function decimalMultiply(a, b) {
  const A = decimalParts(a), B = decimalParts(b);
  if (!A || !B) return null;
  let digits = (BigInt(A.digits) * BigInt(B.digits)).toString();
  const scale = A.scale + B.scale;
  if (scale > 0) {
    if (digits.length <= scale) digits = digits.padStart(scale + 1, '0');
    const cut = digits.length - scale;
    digits = digits.slice(0, cut) + '.' + digits.slice(cut);
  }
  digits = digits.replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '') || '0';
  return (A.sign * B.sign < 0 && digits !== '0' ? '-' : '') + digits;
}
function decimalDivide(a, b, maxScale = 12) {
  const A = decimalParts(a), B = decimalParts(b);
  if (!A || !B || BigInt(B.digits) === 0n) return null;
  let numerator = BigInt(A.digits), denominator = BigInt(B.digits);
  const shift = maxScale + B.scale - A.scale;
  if (shift >= 0) numerator *= 10n ** BigInt(shift); else denominator *= 10n ** BigInt(-shift);
  let q = numerator / denominator, r = numerator % denominator;
  if (r * 2n >= denominator) q += 1n;
  let digits = q.toString();
  if (maxScale > 0) {
    if (digits.length <= maxScale) digits = digits.padStart(maxScale + 1, '0');
    const cut = digits.length - maxScale;
    digits = digits.slice(0, cut) + '.' + digits.slice(cut);
  }
  digits = digits.replace(/(\.\d*?)0+$/, '$1').replace(/\.$/, '') || '0';
  return (A.sign * B.sign < 0 && digits !== '0' ? '-' : '') + digits;
}
function formatCurrencyExact(value, currencyCode) {
  const raw = String(value ?? '');
  if (!raw || raw === '—') return raw;
  if (!Number.isFinite(Number(raw))) return 'Error';
  let decimals = 2;
  try { decimals = new Intl.NumberFormat('en', {style:'currency', currency:currencyCode}).resolvedOptions().maximumFractionDigits; } catch (_) {}
  const p = decimalParts(raw); if (!p) return 'Error';
  const negative = p.sign < 0;
  const unsigned = negative ? raw.slice(1) : raw;
  let [whole, fraction=''] = unsigned.split('.');
  fraction = (fraction + '0'.repeat(decimals + 1));
  let kept = fraction.slice(0, decimals);
  const roundUp = Number(fraction.charAt(decimals) || '0') >= 5;
  let digits = BigInt((whole || '0') + (kept || ''));
  if (roundUp) digits += 1n;
  let rounded = digits.toString().padStart(decimals + 1, '0');
  let w = decimals ? rounded.slice(0, -decimals) : rounded;
  let f = decimals ? rounded.slice(-decimals) : '';
  const separator = typeof STATE !== 'undefined' ? STATE.thousandsSep : 'comma';
  let grouped = w;
  if (separator === 'comma') grouped = w.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  else if (separator === 'space') grouped = w.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  else if (separator === 'lakh') {
    if (w.length > 3) grouped = w.slice(0, -3).replace(/\B(?=(\d{2})+(?!\d))/g, ',') + ',' + w.slice(-3);
  }
  return (negative && digits !== 0n ? '-' : '') + grouped + (decimals ? '.' + f : '');
}

function getCurrencyAmountRaw(id) {
  const el = document.getElementById(id);
  if (el?.dataset.currencyRaw && el.getAttribute('data-derived') === 'true') return String(el.dataset.currencyRaw);
  const text = el?.querySelector('.input-text')?.textContent ?? '';
  return String(text).replace(/,/g, '').trim() || '0';
}

function setCurrencyAmountRaw(id, value, derived = false) {
  const el = document.getElementById(id);
  if (!el) return;
  const raw = String(value ?? '0');
  el.dataset.currencyDerived = derived ? 'true' : 'false';
  if (derived) { el.dataset.currencyRaw = raw; el.setAttribute('data-derived', 'true'); }
  else { delete el.dataset.currencyRaw; el.removeAttribute('data-derived'); }
  const span = el.querySelector('.input-text');
  if (span) span.textContent = raw;
  else el.textContent = raw;
}

function currencyObservationAgeDays(rateDate) {
  if (!/^\d{4}-\d{2}-\d{2}$/.test(String(rateDate || ''))) return null;
  const observed = Date.parse(`${rateDate}T00:00:00.000Z`);
  const today = Date.parse(`${new Date().toISOString().slice(0, 10)}T00:00:00.000Z`);
  return Number.isFinite(observed) && Number.isFinite(today) ? Math.max(0, Math.floor((today - observed) / 86400000)) : null;
}

function calcCurrency() {
  const fromCode = document.getElementById('cur-from')?.value;
  const toCode = document.getElementById('cur-to')?.value;
  const fromEl = document.getElementById('cur-amount');
  const toEl = document.getElementById('cur-to-amount');
  const fromText = fromEl?.querySelector('.input-text');
  const toText = toEl?.querySelector('.input-text');
  if (!fromEl || !toEl || !fromText || !toText) return;

  const active = STATE.currentScreen === 'currencies' ? STATE.activeInputTarget : null;
  const editingTo = active === toEl;
  const editingFrom = active === fromEl || !active;
  const fromRaw = limitCurrencyFraction((fromEl.dataset.currencyRaw && fromEl.getAttribute('data-derived') === 'true' ? fromEl.dataset.currencyRaw : fromText.textContent || '').trim() || '0', 10);
  const toRaw = limitCurrencyFraction((toEl.dataset.currencyRaw && toEl.getAttribute('data-derived') === 'true' ? toEl.dataset.currencyRaw : toText.textContent || '').trim() || '0', 10);
  const fromValid = Boolean(decimalParts(fromRaw));
  const toValid = Boolean(decimalParts(toRaw));
  const rateF = Number(STATE.currencies?.[fromCode]);
  const rateT = Number(STATE.currencies?.[toCode]);
  const note = document.getElementById('cur-rate-note');
  const status = document.getElementById('cur-rate-status');

  const write = (el, text, derived) => {
    const span = el.querySelector('.input-text');
    if (!span) return;
    if (derived) { el.dataset.currencyRaw = String(text ?? '0'); span.textContent = formatCurrencyExact(String(text ?? '0'), el.id === 'cur-to-amount' ? toCode : fromCode); el.setAttribute('data-derived', 'true'); }
    else { span.textContent = String(text ?? '0'); el.removeAttribute('data-derived'); delete el.dataset.currencyRaw; }
  };

  if (!fromCode || !toCode || !Number.isFinite(rateF) || rateF <= 0 || !Number.isFinite(rateT) || rateT <= 0) {
    if (editingFrom) write(toEl, '—', true); else if (editingTo) write(fromEl, '—', true);
    if (note) note.textContent = `* 1 ${fromCode || 'USD'} = Rate unavailable for ${toCode || 'INR'}`;
    if (status && navigator.onLine === false) status.textContent = 'Offline · last known rates only';
    else if (status && Object.keys(STATE.currencies || {}).length) status.textContent = `Selected currency pair not provided by ${STATE.currencyRateSource || 'current rate source'}`;
    return;
  }

  const oneRateRaw = fromCode === toCode ? '1' : decimalDivide(String(rateT), String(rateF), 12);
  const oneRate = Number(oneRateRaw);
  if (!Number.isFinite(oneRate)) {
    if (note) note.textContent = 'Live rate unavailable for selected currency';
    return;
  }

  if (editingTo && toValid) {
    const convertedFrom = fromCode === toCode ? toRaw : decimalDivide(toRaw, oneRateRaw, 12);
    write(fromEl, limitCurrencyFraction(convertedFrom ?? 'Error', 10), true);
  } else if (editingFrom && fromValid) {
    const convertedTo = fromCode === toCode ? fromRaw : decimalMultiply(fromRaw, oneRateRaw);
    write(toEl, limitCurrencyFraction(convertedTo ?? 'Error', 10), true);
  } else if (editingFrom) {
    write(toEl, '0', true);
  }

  if (note) {
    const rateText = Number.isFinite(oneRate) ? limitCurrencyFraction(oneRate.toString(), 10) : '—';
    const pairDate = getCurrencyPairObservationDate(fromCode, toCode, STATE.currencyRateDates, STATE.currencyRateDate);
    const pairSources = getCurrencyPairSources(fromCode, toCode);
    updateCurrencyProviderAttribution(fromCode, toCode);
    const sourceLabel = pairSources.length ? ` · ${pairSources.join(' / ')}` : '';
    const observationAge = currencyObservationAgeDays(pairDate);
    const freshnessLabel = observationAge !== null && observationAge > 3 ? ' · older reference observation' : '';
    note.textContent = `* 1 ${fromCode} = ${rateText} ${toCode}${pairDate ? ` · rate date ${pairDate}${freshnessLabel}` : ''}${sourceLabel}`;
  }

  if (typeof requestAnimationFrame === 'function') {
    if (window.currencyFitFrame) cancelAnimationFrame(window.currencyFitFrame);
    window.currencyFitFrame = requestAnimationFrame(() => {
      window.currencyFitFrame = 0;
      try { fitCurrencyDisplays(); } catch (_) {}
    });
  }
}


// Shared adaptive sizing for every tool result and custom numeric entry.
// Currency Converter keeps its dedicated fitter to avoid competing font-size writers.
const TOOL_RESULT_SELECTOR = [
  '#screen-viewport .result-value',
  '#screen-viewport #unit-result-val',
  '#screen-viewport .input-val-box .input-text',
  '#screen-viewport .unit-result-value',
  '#screen-viewport .unit-result-val',
  '#screen-viewport #gpa-val-res',
  '#screen-viewport #gpa-credits-res',
  '#screen-viewport .hex-value',
  '#screen-viewport .body-metric-result strong',
  '#screen-viewport .discount-reference-row > strong',
  '#screen-viewport .world-base-time',
  '#screen-viewport .world-clock-time',
  '#screen-viewport .unit-price-grid > span[id^="up-u-"]'
].join(',');
const TOOL_FIT_SKIP_TEXT = new Set(['—', 'Please enter your data', 'Enter your data']);
const TOOL_FIT_CONTAINER_SELECTOR = '.input-val-box, .result-row, .body-metric-result-row, .unit-result-row, .hex-convert-row, .gpa-result-card, .discount-reference-row, .world-base-card, .world-clock-row, .unit-price-grid, .calc-card, .result-card';
const toolFitObservedContainers = new WeakSet();

function getToolFitAvailableWidth(element, parent) {
  const style = getComputedStyle(parent);
  const horizontalPadding = (parseFloat(style.paddingLeft) || 0) + (parseFloat(style.paddingRight) || 0);
  const border = (parseFloat(style.borderLeftWidth) || 0) + (parseFloat(style.borderRightWidth) || 0);
  if (!parent.clientWidth) return 0;
  let available = Math.max(0, parent.clientWidth - horizontalPadding - border - 4);
  const direction = style.flexDirection || 'row';
  const isStacked = direction === 'column' || direction === 'column-reverse' || parent.classList.contains('world-base-card');
  if (!isStacked) {
    let occupied = 0;
    let visibleSiblingCount = 0;
    Array.from(parent.children || []).forEach(sibling => {
      if (sibling === element || sibling.contains(element)) return;
      const siblingStyle = getComputedStyle(sibling);
      if (siblingStyle.display === 'none' || siblingStyle.visibility === 'hidden') return;
      const rect = sibling.getBoundingClientRect();
      if (rect.width <= 0 || rect.height <= 0) return;
      const marginLeft = parseFloat(siblingStyle.marginLeft) || 0;
      const marginRight = parseFloat(siblingStyle.marginRight) || 0;
      occupied += rect.width + marginLeft + marginRight;
      visibleSiblingCount += 1;
    });
    const columnGap = parseFloat(style.columnGap);
    const gap = Number.isFinite(columnGap) ? columnGap : (parseFloat(style.gap) || 0);
    if (occupied > 0) available -= occupied + (gap * visibleSiblingCount);
  }
  return Math.max(24, available);
}

function fitAdaptiveToolResult(element) {
  if (!element || !element.isConnected) return;
  // Do not run the shared fitter over Currency Converter: its own three-result
  // layout has a separate, measured fitter and must remain the sole font writer.
  if (element.closest('#screen-currencies')) return;
  const text = String(element.textContent || '').trim();
  if (!text || TOOL_FIT_SKIP_TEXT.has(text)) {
    if (element.__sumaireFitApplied && element.__sumaireFitOriginal) {
      const originalSize = element.__sumaireFitOriginal.inlineFontSize;
      if (originalSize) element.style.fontSize = originalSize;
      else element.style.removeProperty('font-size');
      element.__sumaireFitApplied = false;
    }
    if (element.title) element.removeAttribute('title');
    return;
  }

  const parent = element.closest(TOOL_FIT_CONTAINER_SELECTOR) || element.parentElement;
  if (!parent) return;

  // Restore the author/CSS font before measuring. Without this reset, a value
  // shrunk once could never grow again when the viewport or settings get larger.
  if (!element.__sumaireFitOriginal) {
    element.__sumaireFitOriginal = { inlineFontSize: element.style.fontSize || '' };
  }
  const originalInline = element.__sumaireFitOriginal.inlineFontSize;
  if (element.__sumaireFitApplied) {
    if (originalInline) element.style.fontSize = originalInline;
    else element.style.removeProperty('font-size');
  }
  const computed = getComputedStyle(element);
  const base = Math.max(10, Math.min(40, parseFloat(computed.fontSize) || 18));
  const isEntry = !!element.closest('.input-val-box');
  const min = Math.min(base, Math.max(9, Number(element.dataset.minFontSize) || (isEntry ? 10 : 11)));
  const available = getToolFitAvailableWidth(element, parent);
  if (!available) return;

  const canvas = fitAdaptiveToolResult.canvas || (fitAdaptiveToolResult.canvas = document.createElement('canvas'));
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  const font = computed.font && computed.font !== '' ? computed.font : `${computed.fontWeight || 600} ${base}px ${computed.fontFamily || 'sans-serif'}`;
  const letterSpacing = parseFloat(computed.letterSpacing) || 0;
  const measureAt = size => {
    // Replace only the pixel size in the computed font shorthand, preserving
    // weight, style and family across Android WebView/system fonts.
    ctx.font = font.replace(/\b\d+(?:\.\d+)?px\b/, `${size}px`);
    const measured = ctx.measureText(text).width + Math.max(0, text.length - 1) * letterSpacing;
    return measured;
  };

  let low = min, high = base, best = min;
  if (measureAt(base) <= available) best = base;
  else if (measureAt(min) <= available) {
    for (let i = 0; i < 14; i++) {
      const middle = (low + high) / 2;
      if (measureAt(middle) <= available) { best = middle; low = middle; }
      else high = middle;
    }
  }

  const nextSize = `${Math.max(min, Math.min(base, best)).toFixed(2)}px`;
  if (element.style.fontSize !== nextSize) element.style.fontSize = nextSize;
  element.__sumaireFitApplied = true;
  element.style.maxWidth = '100%';
  element.style.minWidth = '0';
  element.style.fontVariantNumeric = 'tabular-nums';
  if (isEntry) {
    element.style.whiteSpace = 'nowrap';
    element.style.overflow = 'visible';
    element.style.textOverflow = 'clip';
    parent.style.minWidth = '0';
  } else {
    element.style.whiteSpace = 'normal';
    element.style.overflowWrap = 'anywhere';
    element.style.wordBreak = 'normal';
    element.style.textAlign = element.matches('.body-metric-result strong, .result-value') ? 'right' : '';
  }
  element.title = text;
}

function fitAllToolResults(root = document) {
  if (!root) return;
  if (root.matches?.(TOOL_RESULT_SELECTOR)) fitAdaptiveToolResult(root);
  root.querySelectorAll?.(TOOL_RESULT_SELECTOR).forEach(fitAdaptiveToolResult);
}
let toolResultResizeObserver = null;
let toolResultMutationObserver = null;
let toolResultFitFrame = 0;
// Coalesce every resize/mutation request into one frame without dropping roots.
// Previously each call cancelled the pending frame and replaced its root; when
// several screens changed together, only the final screen was refitted.
const pendingToolFitRoots = new Set();
let pendingToolFitAll = false;
function scheduleAllToolFits(root = document) {
  if (root === document) {
    pendingToolFitAll = true;
    pendingToolFitRoots.clear();
  } else if (root && !pendingToolFitAll) {
    pendingToolFitRoots.add(root);
  }
  if (toolResultFitFrame) return;
  toolResultFitFrame = requestAnimationFrame(() => {
    toolResultFitFrame = 0;
    if (pendingToolFitAll) {
      pendingToolFitAll = false;
      pendingToolFitRoots.clear();
      fitAllToolResults(document);
      return;
    }
    const roots = [...pendingToolFitRoots];
    pendingToolFitRoots.clear();
    roots.forEach(pendingRoot => {
      if (pendingRoot?.isConnected !== false) fitAllToolResults(pendingRoot);
    });
  });
}
function observeToolFitContainers(root = document) {
  if (!toolResultResizeObserver || !root?.querySelectorAll) return;
  const selector = '#screen-viewport .calc-card, #screen-viewport .result-card, #screen-viewport .input-row, #screen-viewport .result-row, #screen-viewport .unit-result-row, #screen-viewport .body-metric-result-row, #screen-viewport .input-val-box, #screen-viewport .hex-convert-row, #screen-viewport .gpa-result-card, #screen-viewport .discount-reference-row, #screen-viewport .world-base-card, #screen-viewport .world-clock-row, #screen-viewport .unit-price-grid';
  const nodes = [];
  if (root.matches?.(selector)) nodes.push(root);
  root.querySelectorAll(selector).forEach(node => nodes.push(node));
  nodes.forEach(node => {
    if (toolFitObservedContainers.has(node)) return;
    toolFitObservedContainers.add(node);
    toolResultResizeObserver.observe(node);
  });
}
function initAdaptiveToolResults() {
  fitAllToolResults();
  if (typeof ResizeObserver === 'function' && !toolResultResizeObserver) {
    toolResultResizeObserver = new ResizeObserver(entries => {
      const roots = new Set();
      entries.forEach(entry => {
        const screen = entry.target.closest?.('.screen');
        if (screen) roots.add(screen);
      });
      roots.forEach(scheduleAllToolFits);
    });
    observeToolFitContainers(document);
  }
  if (typeof MutationObserver === 'function' && !toolResultMutationObserver) {
    toolResultMutationObserver = new MutationObserver(records => {
      const roots = new Set();
      records.forEach(record => {
        const node = record.target.nodeType === 1 ? record.target : record.target.parentElement;
        const screen = node?.closest?.('.screen');
        if (screen) roots.add(screen);
        record.addedNodes?.forEach(added => {
          if (added.nodeType === 1) observeToolFitContainers(added);
        });
      });
      roots.forEach(scheduleAllToolFits);
    });
    document.querySelectorAll('#screen-viewport > .screen').forEach(screen =>
      toolResultMutationObserver.observe(screen, {subtree:true, childList:true, characterData:true}));
  }
  if (!window.__sumaireToolFitResizeBound) {
    window.__sumaireToolFitResizeBound = true;
    const schedule = () => scheduleAllToolFits(document);
    window.addEventListener('resize', schedule, {passive:true});
    window.addEventListener('orientationchange', schedule, {passive:true});
    if (document.fonts?.ready) document.fonts.ready.then(schedule).catch(() => {});
  }
}

// 3. UNIT CONVERTER
const UNIT_DATA = {
  length: { base: 'm', units: {
    'Millimeter (mm)': 0.001, 'Centimeter (cm)': 0.01, 'Meter (m)': 1, 'Kilometer (km)': 1000,
    'Inch (in)': 0.0254, 'Foot (ft)': 0.3048, 'Yard (yd)': 0.9144, 'Mile (mi)': 1609.344, 'Nautical mile': 1852
  }},
  mass: { base: 'kg', units: {
    'Milligram (mg)': 1e-6, 'Gram (g)': 1e-3, 'Kilogram (kg)': 1, 'Metric ton (t)': 1000,
    'Ounce (oz)': 0.028349523125, 'Pound (lb)': 0.45359237, 'Stone (st)': 6.35029318
  }},
  area: { base: 'm²', units: {
    'Square millimeter (mm²)': 1e-6, 'Square centimeter (cm²)': 1e-4, 'Square meter (m²)': 1,
    'Square kilometer (km²)': 1e6, 'Hectare (ha)': 10000, 'Acre (ac)': 4046.8564224,
    'Square inch (in²)': 0.00064516, 'Square foot (ft²)': 0.09290304, 'Square yard (yd²)': 0.83612736
  }},
  volume: { base: 'L', units: {
    'Milliliter (mL)': 0.001, 'Liter (L)': 1, 'Cubic centimeter (cm³)': 0.001, 'Cubic meter (m³)': 1000,
    'US fluid ounce (fl oz)': 0.0295735295625, 'US cup': 0.2365882365, 'US pint (pt)': 0.473176473,
    'US gallon (gal)': 3.785411784, 'Imperial gallon (Imp gal)': 4.54609
  }},
  time: { base: 's', units: {
    'Millisecond (ms)': 0.001, 'Second (s)': 1, 'Minute (min)': 60, 'Hour (h)': 3600,
    'Day (d)': 86400, 'Week (wk)': 604800, 'Year (365 d)': 31536000
  }},
  energy: { base: 'J', units: {
    'Joule (J)': 1, 'Kilojoule (kJ)': 1000, 'Calorie (cal)': 4.184, 'Kilocalorie (kcal)': 4184,
    'Watt hour (Wh)': 3600, 'Kilowatt hour (kWh)': 3.6e6
  }},
  power: { base: 'W', units: { 'Watt (W)': 1, 'Kilowatt (kW)': 1000, 'Megawatt (MW)': 1e6, 'Horsepower (HP)': 745.6998715822702 }},
  pressure: { base: 'Pa', units: {
    'Pascal (Pa)': 1, 'Hectopascal (hPa)': 100, 'Kilopascal (kPa)': 1000, 'Bar (bar)': 100000,
    'Atmosphere (atm)': 101325, 'PSI (psi)': 6894.757293168, 'mmHg': 133.322387415
  }},
  speed: { base: 'm/s', units: { 'm/s': 1, 'km/h': 1 / 3.6, 'mph': 0.44704, 'Knot (kn)': 1852 / 3600 }},
  temperature: { base: '°C', units: { 'Celsius (°C)': 1, 'Fahrenheit (°F)': 1, 'Kelvin (K)': 1 }},
  fuel: { base: 'km/L', units: { 'Kilometers per liter (km/L)': 1, 'Liters per 100 km (L/100 km)': 1, 'Miles per US gallon (mpg US)': 1, 'Miles per Imperial gallon (mpg UK)': 1 }},
  data: { base: 'B', units: { 'Bit (bit)': 0.125, 'Byte (B)': 1, 'Kilobyte (KB)': 1024, 'Megabyte (MB)': 1048576, 'Gigabyte (GB)': 1073741824, 'Terabyte (TB)': 1099511627776, 'Petabyte (PB)': 1125899906842624 }}
};

function convertUnitValue(category, value, from, to) {
  if (category === 'temperature') {
    // Kelvin is an absolute temperature scale: values below absolute zero are
    // physically invalid. Reject them in either direction rather than
    // displaying a plausible-looking but impossible conversion.
    if (from.startsWith('Kelvin') && value < 0) return NaN;
    const toC = from.startsWith('Fahrenheit') ? (value - 32) * 5 / 9 : from.startsWith('Kelvin') ? value - 273.15 : value;
    const converted = to.startsWith('Fahrenheit') ? toC * 9 / 5 + 32 : to.startsWith('Kelvin') ? toC + 273.15 : toC;
    if (to.startsWith('Kelvin') && converted < 0) return NaN;
    return converted;
  }
  if (category === 'fuel') {
    const toKmL = from.startsWith('Liters per 100') ? (value === 0 ? Infinity : 100 / value)
      : from.startsWith('Miles per US') ? value / 2.35214583
      : from.startsWith('Miles per Imperial') ? value / 2.82480936 : value;
    return to.startsWith('Liters per 100') ? (toKmL === 0 ? Infinity : 100 / toKmL)
      : to.startsWith('Miles per US') ? toKmL * 2.35214583
      : to.startsWith('Miles per Imperial') ? toKmL * 2.82480936 : toKmL;
  }
  const factorF = UNIT_DATA[category].units[from];
  const factorT = UNIT_DATA[category].units[to];
  return (value * factorF) / factorT;
}

function initUnits() {
  const catSel = document.getElementById('unit-category');
  catSel.value = 'length';
  catSel.onchange = updateUnitSelects;
  document.getElementById('unit-from').onchange = () => { updateUnitSelectionLabels(); calcUnits(); };
  document.getElementById('unit-to').onchange = () => { updateUnitSelectionLabels(); calcUnits(); };
  document.getElementById('btn-unit-swap').onclick = () => {
    const f = document.getElementById('unit-from');
    const t = document.getElementById('unit-to');
    if (!f || !t) return;
    // Swap the actual selected options, not merely the numeric conversion.
    // The visible unit names therefore change together with the direction.
    const fromValue = f.value;
    const toValue = t.value;
    f.value = toValue;
    t.value = fromValue;
    updateUnitSelectionLabels();
    calcUnits();
  };
  document.getElementById('unit-convert-action')?.addEventListener('click', () => {
    calcUnits();
    const result = document.getElementById('unit-result-val');
    result?.setAttribute('aria-live', 'polite');
  });
  updateUnitSelects();
}

function updateUnitSelectionLabels() {
  const f = document.getElementById('unit-from');
  const t = document.getElementById('unit-to');
  if (!f || !t) return;
  const fromOption = f.options?.[f.selectedIndex];
  const toOption = t.options?.[t.selectedIndex];
  const fromName = fromOption?.dataset?.sourceLabel || fromOption?.textContent?.trim() || f.value || '';
  const toName = toOption?.dataset?.sourceLabel || toOption?.textContent?.trim() || t.value || '';
  f.setAttribute('aria-label', fromName ? `From unit: ${fromName}` : 'Source unit');
  t.setAttribute('aria-label', toName ? `To unit: ${toName}` : 'Target unit');
  f.title = fromName;
  t.title = toName;
  const fromCard = f.closest('.calc-card');
  const toCard = t.closest('.calc-card');
  // Keep stable section headings as shown in the reference; selected unit names
  // are displayed in the full-width selectors and remain available as tooltips.
}

function updateUnitSelects() {
  const cat = document.getElementById('unit-category').value;
  const f = document.getElementById('unit-from');
  const t = document.getElementById('unit-to');
  const category = UNIT_DATA[cat];
  if (!category || !category.units || !f || !t) {
    if (f) f.replaceChildren();
    if (t) t.replaceChildren();
    setElementText('unit-result-val', '—');
    setElementText('unit-note', 'Choose a valid category');
    return;
  }
  const units = Object.keys(category.units);
  const fromFragment = document.createDocumentFragment();
  const toFragment = document.createDocumentFragment();
  units.forEach(unit => {
    const fromOption = document.createElement('option');
    fromOption.value = unit;
    fromOption.dataset.sourceLabel = unit;
    fromOption.textContent = unit;
    fromFragment.appendChild(fromOption);

    const toOption = document.createElement('option');
    toOption.value = unit;
    toOption.dataset.sourceLabel = unit;
    toOption.textContent = unit;
    toFragment.appendChild(toOption);
  });
  f.replaceChildren(fromFragment);
  t.replaceChildren(toFragment);
  if (cat === 'length') { f.value = 'Meter (m)'; t.value = 'Kilometer (km)'; }
  else if (cat === 'data') { f.value = 'Petabyte (PB)'; t.value = 'Bit (bit)'; }
  else { f.selectedIndex = Math.min(1, f.options.length - 1); t.selectedIndex = Math.min(4, t.options.length - 1); }
  updateUnitSelectionLabels();
  calcUnits();
}

function calcUnits() {
  const cat = document.getElementById('unit-category').value;
  const f = document.getElementById('unit-from').value;
  const t = document.getElementById('unit-to').value;
  const val = readModuleNumber('unit-input-val');
  if (!UNIT_DATA[cat] || !Object.prototype.hasOwnProperty.call(UNIT_DATA[cat].units, f) || !Object.prototype.hasOwnProperty.call(UNIT_DATA[cat].units, t)) {
    setElementText('unit-result-val', '—'); setElementText('unit-note', 'Choose valid units'); return;
  }
  const oneRate = convertUnitValue(cat, 1, f, t);
  const oneRateText = Number.isInteger(oneRate) ? new Intl.NumberFormat(globalThis.SALocalization?.locale || undefined,{maximumFractionDigits:0}).format(oneRate) : new Intl.NumberFormat(globalThis.SALocalization?.locale || undefined,{maximumFractionDigits:6}).format(oneRate);
  setElementText('unit-note', `* 1 ${f} = ${oneRateText} ${t}`);
  if (!Number.isFinite(val)) { setElementText('unit-result-val', '—'); return; }
  const res = convertUnitValue(cat, val, f, t);
  if (!Number.isFinite(res)) { setElementText('unit-result-val', '—'); setElementText('unit-note', 'Conversion is undefined for this value'); return; }
  setElementText('unit-result-val', formatUnitResultNumber(res));
  renderAllUnitResults(cat, val, f);
}

function renderAllUnitResults() {
  // The converter intentionally shows only the selected From -> To result.
  // Do not render a second 'all equivalent units' result surface.
  const list = document.getElementById('unit-all-results');
  if (list) list.replaceChildren();
}

// 4. DISCOUNT CALCULATOR — added tax, original price, discount, savings and final price
function calcDiscount() {
  const read = id => readModuleNumber(id);
  const taxPct=read('disc-tax'), orig=read('disc-orig'), discPct=read('disc-pct');
  if (![taxPct,orig,discPct].every(Number.isFinite) || orig<0 || taxPct<0 || discPct<0 || discPct>100) {
    setElementText('disc-saved','Please enter your data'); setElementText('disc-final','Please enter your data'); return;
  }
  const saved=orig*(discPct/100); const subtotal=orig-saved; const finalPrice=subtotal*(1+taxPct/100);
  setElementText('disc-saved',`$ ${formatResultNumber(saved)}`); setElementText('disc-final',`$ ${formatResultNumber(finalPrice)}`);
}

// 5. PERCENT CALCULATOR — two modes
function calcPercent() {
  const read = id => readModuleNumber(id);
  const initial=read('pct-init'), final=read('pct-final'), x=read('pct-x'), y=read('pct-y');
  setElementText('pct-change-res',Number.isFinite(initial)&&Number.isFinite(final)&&initial!==0?`${((final-initial)/Math.abs(initial)>=0?'+':'')}${formatResultNumber((final-initial)/Math.abs(initial)*100)}%`:'—');
  setElementText('pct-xy-res',Number.isFinite(x)&&Number.isFinite(y)?formatResultNumber(x*y/100):'—');
}
function initPercentModes() {
  document.querySelectorAll('[data-percent-mode]').forEach(button=>button.addEventListener('click',()=>{
    const mode=button.dataset.percentMode;
    document.querySelectorAll('[data-percent-mode]').forEach(b=>b.classList.toggle('active',b===button));
    document.querySelectorAll('.percent-mode-panel').forEach(panel=>panel.classList.toggle('active',panel.id===`percent-panel-${mode}`));
    const selector=document.getElementById('percent-mode-select'); if(selector) selector.value=mode;
    const first=document.querySelector(`#percent-panel-${mode} .input-val-box`); if(first)setActiveInput(first);
    calcPercent();
  }));
  document.getElementById('percent-mode-select')?.addEventListener('change', event => {
    document.querySelector(`[data-percent-mode="${event.target.value}"]`)?.click();
  });
  document.getElementById('percent-calculate')?.addEventListener('click', calcPercent);
  document.getElementById('discount-calculate')?.addEventListener('click', calcDiscount);
  calcPercent(); calcDiscount();
}

// 6. SALES TAX CALCULATOR
function calcSalesTax() {
  const rate = readModuleNumber('tax-rate');
  const orig = readModuleNumber('tax-orig');
  if (!Number.isFinite(rate) || !Number.isFinite(orig) || rate < 0 || rate > 1000 || orig < 0) {
    setElementText('tax-amt', 'Please enter your data'); setElementText('tax-total', 'Please enter your data'); return;
  }
  const mode = document.getElementById('tax-mode')?.value;
  if (mode !== 'exclusive' && mode !== 'inclusive') {
    setElementText('tax-amt', 'Please enter your data'); setElementText('tax-total', 'Please enter your data'); return;
  }

  let tax = 0, total = 0;
  if (mode === 'exclusive') {
    tax = orig * (rate / 100);
    total = orig + tax;
  } else {
    tax = rate > -100 ? orig - (orig / (1 + rate / 100)) : 0;
    total = orig;
  }
  setElementText('tax-amt', `$ ${formatResultNumber(tax)}`);
  setElementText('tax-total', `$ ${formatResultNumber(total)}`);
}

// 7. BODY METRICS (BMI & BMR)
function calcBodyMetrics() {
  const read = id => readModuleNumber(id);
  const hCm = read('bmi-height');
  const w = read('bmi-weight');
  const age = read('bmi-age');
  const h = hCm / 100;
  const gender = document.getElementById('bmi-gender')?.value || '';
  const resultCard = document.getElementById('body-metric-result');
  const raw = ['bmi-height', 'bmi-weight', 'bmi-age'].map(id => (document.getElementById(id)?.querySelector('.input-text')?.textContent || '').trim());
  const hasAny = raw.some(Boolean) || !!gender;
  if (!Number.isFinite(hCm) || !Number.isFinite(w) || !Number.isFinite(age) || !(h > 0) || !(w > 0) || !(age > 0) || hCm < 50 || hCm > 300 || w > 700 || age > 120) {
    if (resultCard?.dataset) resultCard.dataset.state = hasAny ? 'incomplete' : 'empty';
    setElementText('bmi-val', hasAny ? 'Complete measurements' : 'Enter your data');
    const emptyStatus = document.getElementById('bmi-status');
    if (emptyStatus) { emptyStatus.textContent = ''; emptyStatus.hidden = true; }
    setElementText('bmr-val', hasAny ? 'Complete measurements' : 'Enter your data');
    return;
  }
  const bmi = w / (h * h);
  setElementText('bmi-val', formatResultNumber(bmi));

  const statusEl = document.getElementById('bmi-status');
  if (statusEl) statusEl.hidden = false;
  if (bmi < 18.5) {
    statusEl.textContent = 'Underweight';
    statusEl.style.color = '#e65100';
  } else if (bmi < 25) {
    statusEl.textContent = 'Normal Weight';
    statusEl.style.color = '#2e7d32';
  } else if (bmi < 30) {
    statusEl.textContent = 'Overweight';
    statusEl.style.color = '#f57c00';
  } else {
    statusEl.textContent = 'Obese';
    statusEl.style.color = '#c62828';
  }

  // BMR (Mifflin-St Jeor): gender is required; never silently assume female.
  if (gender !== 'male' && gender !== 'female') {
    if (resultCard?.dataset) resultCard.dataset.state = 'incomplete';
    setElementText('bmr-val', 'Select gender');
    return;
  }
  if (resultCard?.dataset) resultCard.dataset.state = 'success';
  const bmr = (10 * w) + (6.25 * hCm) - (5 * age) + (gender === 'male' ? 5 : -161);
  setElementText('bmr-val', `${Math.round(bmr)} kcal`);
}

// 8. DATE CALCULATOR — persistent date reminders / anniversaries
// Strict local-calendar validation for the Date Calculator.
// HTML <input type="date"> returns an ISO calendar date (YYYY-MM-DD),
// but its value must be validated independently before persistence.
function validISODate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value)) return false;
  const [y, m, d] = value.split('-').map(Number);
  if (y < 1 || y > 9999 || m < 1 || m > 12 || d < 1) return false;
  const daysInMonth = [31, (y % 4 === 0 && y % 100 !== 0) || y % 400 === 0 ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  return d <= daysInMonth[m - 1];
}

const localDateInputValue = (date) => { const y=date.getFullYear(); const m=String(date.getMonth()+1).padStart(2,'0'); const d=String(date.getDate()).padStart(2,'0'); return `${y}-${m}-${d}`; };
const todayStr = localDateInputValue(new Date());
let dateEvents = [];
let editingDateEventId = null;
function loadDateEvents() {
  try {
    const raw = localStorage.getItem('sumaire_date_events_v1');
    if (raw && raw.length <= 250000) {
      const parsed = JSON.parse(raw);
      if (Array.isArray(parsed)) dateEvents = parsed.filter(x => x && typeof x.id === 'string' && typeof x.title === 'string' && x.title.trim() && validISODate(x.date) && typeof x.repeat === 'boolean').slice(0, 500);
    }
  } catch (_) { dateEvents = []; }
}
let dateSaveInFlight = false;
function saveDateEvents() {
  try {
    const clean = dateEvents.filter(x => x && typeof x.id === 'string' && typeof x.title === 'string' && x.title.trim() && validISODate(x.date) && typeof x.repeat === 'boolean').slice(-500);
    const payload = JSON.stringify(clean);
    localStorage.setItem('sumaire_date_events_v1', payload);
    if (localStorage.getItem('sumaire_date_events_v1') !== payload) throw new Error('Storage verification failed');
    dateEvents = clean;
    return true;
  } catch (_) {
    showToast('Date could not be saved on this device');
    return false;
  }
}
function dateEventDays(event, now = new Date()) {
  const today = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate()));
  let target = new Date(`${event.date}T00:00:00Z`);
  if (event.repeat) {
    const month = target.getUTCMonth(), day = target.getUTCDate();
    let year = today.getUTCFullYear();
    // Keep Feb 29 anniversaries on Feb 28 in non-leap years.
    const safeDay = month === 1 && day === 29 && !((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) ? 28 : day;
    target = new Date(Date.UTC(year, month, safeDay));
    if (target < today) {
      year++;
      const nextSafeDay = month === 1 && day === 29 && !((year % 4 === 0 && year % 100 !== 0) || year % 400 === 0) ? 28 : day;
      target = new Date(Date.UTC(year, month, nextSafeDay));
    }
  }
  return Math.round((target - today) / 86400000);
}
function renderDateEvents() {
  const list = document.getElementById('date-event-list');
  if (!list) return;
  list.replaceChildren();
  if (!dateEvents.length) {
    const empty = document.createElement('div'); empty.className = 'date-event-empty'; empty.textContent = 'Please click here to add'; list.appendChild(empty); return;
  }
  const sorted = [...dateEvents].sort((a,b) => dateEventDays(a) - dateEventDays(b));
  sorted.forEach(event => {
    const row = document.createElement('article'); row.className = 'date-event-card'; row.dataset.eventId = event.id;
    const date = new Date(`${event.date}T00:00:00Z`);
    const day = document.createElement('div'); day.className = 'date-event-day'; day.textContent = new Intl.DateTimeFormat(globalThis.SALocalization?.locale || undefined,{day:'2-digit',timeZone:'UTC'}).format(date);
    const month = document.createElement('div'); month.className = 'date-event-month'; month.textContent = new Intl.DateTimeFormat(globalThis.SALocalization?.locale || undefined,{month:'short',year:'numeric',timeZone:'UTC'}).format(date);
    const main = document.createElement('div'); main.className = 'date-event-main';
    const title = document.createElement('strong'); title.textContent = event.title;
    const detail = document.createElement('span'); detail.textContent = `${event.repeat ? 'Every year · ' : ''}${new Intl.DateTimeFormat(globalThis.SALocalization?.locale || undefined,{year:'numeric',month:'short',day:'numeric',timeZone:'UTC'}).format(date)}`;
    main.append(title,detail);
    const days = dateEventDays(event);
    const count = document.createElement('div'); count.className = 'date-event-count'; count.textContent = days === 0 ? 'Today' : `${Math.abs(days)} ${Math.abs(days) === 1 ? 'day' : 'days'} ${days > 0 ? 'left' : 'ago'}`;
    const actions = document.createElement('div'); actions.className = 'date-event-actions';
    const edit = document.createElement('button'); edit.type='button'; edit.textContent='Edit'; edit.dataset.dateEdit=event.id;
    const remove = document.createElement('button'); remove.type='button'; remove.textContent='×'; remove.dataset.dateDelete=event.id; remove.setAttribute('aria-label',`Delete ${event.title}`);
    actions.append(edit,remove); row.append(day,month,main,count,actions); list.appendChild(row);
  });
}
let dateEventDialogOpener = null;
function closeDateEventDialog() {
  const dlg=document.getElementById('date-event-dialog'); if (!dlg) return;
  dlg.classList.remove('open'); dlg.setAttribute('aria-hidden','true'); editingDateEventId=null;
  const fallback = document.getElementById('date-add-event');
  const openerIsUsable = dateEventDialogOpener && dateEventDialogOpener !== document.body && dateEventDialogOpener !== document.documentElement && dateEventDialogOpener.isConnected;
  const target = openerIsUsable ? dateEventDialogOpener : fallback;
  target?.focus();
  dateEventDialogOpener = null;
}
function openDateEventDialog(event=null) {
  const dlg=document.getElementById('date-event-dialog'); if (!dlg) return;
  dateEventDialogOpener = document.activeElement;
  editingDateEventId=event?.id || null;
  document.getElementById('date-dialog-title').textContent=event?'Edit date':'Add date';
  document.getElementById('date-event-name').value=event?.title || '';
  document.getElementById('date-event-date').value=event?.date || localDateInputValue(new Date());
  document.getElementById('date-event-repeat').checked=!!event?.repeat;
  dlg.classList.add('open'); dlg.setAttribute('aria-hidden','false');
  requestAnimationFrame(()=>{
    if (!dlg.classList.contains('open') || dlg.getAttribute('aria-hidden') === 'true') return;
    const first = getModalFocusableElements(dlg)[0];
    (first || dlg).focus();
  });
}
function dateDifferenceInDays(fromValue, toValue) {
  if (!validISODate(fromValue) || !validISODate(toValue)) return null;
  const toUtcDay = value => { const [year, month, day] = value.split('-').map(Number); return Date.UTC(year, month - 1, day); };
  return Math.round((toUtcDay(toValue) - toUtcDay(fromValue)) / 86400000);
}
function initDateDifference() {
  const from = document.getElementById('date-diff-from');
  const to = document.getElementById('date-diff-to');
  const action = document.getElementById('date-diff-calculate');
  const result = document.getElementById('date-diff-days');
  if (!from || !to || !action || !result || action.dataset.initialized === '1') return;
  action.dataset.initialized = '1';
  const today = localDateInputValue(new Date());
  const nextYear = new Date(); nextYear.setFullYear(nextYear.getFullYear() + 1);
  from.value = today; to.value = localDateInputValue(nextYear);
  const calculate = () => {
    const days = dateDifferenceInDays(from.value, to.value);
    if (days === null) { result.textContent = 'Choose valid dates'; showToast('Choose valid From and To dates'); return; }
    result.textContent = `${Math.abs(days).toLocaleString()} ${Math.abs(days) === 1 ? 'Day' : 'Days'}${days < 0 ? ' (To Date is earlier)' : ''}`;
  };
  action.addEventListener('click', calculate);
  from.addEventListener('change', calculate); to.addEventListener('change', calculate);
  calculate();
}
function initDateEvents() {
  const list=document.getElementById('date-event-list'), dlg=document.getElementById('date-event-dialog');
  initDateDifference();
  if(!list||!dlg||dlg.dataset.initialized==='1') return;
  dlg.dataset.initialized='1'; loadDateEvents(); renderDateEvents();
  document.getElementById('date-add-event')?.addEventListener('click',()=>openDateEventDialog());
  document.getElementById('date-event-cancel')?.addEventListener('click',closeDateEventDialog);
  document.getElementById('date-event-save')?.addEventListener('click',()=>{
    if (dateSaveInFlight) return;
    const saveBtn = document.getElementById('date-event-save');
    const title=document.getElementById('date-event-name').value.trim().replace(/\s+/g, ' ');
    const date=document.getElementById('date-event-date').value;
    const repeat=document.getElementById('date-event-repeat').checked;
    if(!title){showToast('Enter an event name');document.getElementById('date-event-name').focus();return;}
    if(title.length > 80){showToast('Event name is too long');document.getElementById('date-event-name').focus();return;}
    if(!validISODate(date)){showToast('Choose a valid date');document.getElementById('date-event-date').focus();return;}
    const wasEditing = Boolean(editingDateEventId);
    const previous = dateEvents.map(item => ({...item}));
    dateSaveInFlight = true;
    if (saveBtn) { saveBtn.disabled = true; saveBtn.setAttribute('aria-busy','true'); }
    try {
      if (editingDateEventId) {
        const item = dateEvents.find(x => x.id === editingDateEventId);
        if (!item) throw new Error('Event no longer exists');
        Object.assign(item, {title, date, repeat});
      } else {
        dateEvents.push({id:`${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`, title, date, repeat});
        if (dateEvents.length > 500) dateEvents = dateEvents.slice(-500);
      }
      if (!saveDateEvents()) {
        dateEvents = previous;
        renderDateEvents();
        return;
      }
      renderDateEvents();
      closeDateEventDialog();
      showToast(wasEditing ? 'Date updated and saved' : 'Date saved');
    } finally {
      dateSaveInFlight = false;
      if (saveBtn) { saveBtn.disabled = false; saveBtn.removeAttribute('aria-busy'); }
    }
  });
  list.addEventListener('click',event=>{
    if(event.target.closest('.date-event-empty')){openDateEventDialog();return;}
    const edit=event.target.closest('[data-date-edit]'), remove=event.target.closest('[data-date-delete]');
    if(edit){const item=dateEvents.find(x=>x.id===edit.dataset.dateEdit);if(item)openDateEventDialog(item);}
    if(remove){const previous=dateEvents.map(x=>({...x}));dateEvents=dateEvents.filter(x=>x.id!==remove.dataset.dateDelete);if(saveDateEvents()){renderDateEvents();showToast('Date deleted');}else{dateEvents=previous;renderDateEvents();}}
  });
  dlg.addEventListener('click',e=>{if(e.target===dlg)closeDateEventDialog();});
  document.addEventListener('keydown',e=>{if(dlg.classList.contains('open')&&e.key==='Escape'){e.preventDefault();closeDateEventDialog();}});
  window.addEventListener('storage', e => {
    if (e.key !== 'sumaire_date_events_v1') return;
    loadDateEvents();
    renderDateEvents();
  });
}

function readModuleNumber(id, { symbols = '$₹€£%', allowEmpty = false } = {}) {
  const el = document.getElementById(id);
  const raw = (el?.querySelector('.input-text')?.textContent || el?.value || el?.textContent || '').trim();
  if (!raw) return allowEmpty ? null : NaN;

  let value = raw.replace(/[\s\u00a0]/g, '');
  if (symbols) {
    const currencySymbols = symbols.replace(/%/g, '');
    if (currencySymbols) {
      const escaped = currencySymbols.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
      // Currency markers are valid only as a single leading prefix (after an optional sign).
      value = value.replace(new RegExp('^([+-]?)[' + escaped + ']'), '$1');
    }
    // Percent is valid only as a single trailing suffix.
    if (symbols.includes('%')) value = value.replace(/%$/, '');
  }

  // Commas are grouping separators, never disposable symbols. Accept either
  // Western 1,234,567 or Indian 12,34,567 grouping, but never mixed/malformed groups.
  const sign = '[+-]?';
  const exponent = '(?:[eE][+-]?\\d+)?';
  const western = '\\d{1,3}(?:,\\d{3})+';
  const indian = '\\d{1,2}(?:,\\d{2})+,\\d{3}';
  const plain = '(?:\\d+\\.?\\d*|\\.\\d+)';
  const groupedNumber = '(?:' + western + '|' + indian + ')(?:\\.\\d*)?';
  const valid = new RegExp('^' + sign + '(?:' + groupedNumber + '|' + plain + ')' + exponent + '$');
  if (!valid.test(value)) return NaN;

  const number = Number(value.replace(/,/g, ''));
  return Number.isFinite(number) ? number : NaN;
}

// 9. FUEL COST
function calcFuelCost() {
  const d = readModuleNumber('fc-dist');
  const eff = readModuleNumber('fc-eff');
  const p = readModuleNumber('fc-price');
  const result = document.getElementById('fuel-cost-result');
  const note = document.getElementById('fc-empty-note');
  const raw = ['fc-dist', 'fc-eff', 'fc-price'].map(id => (document.getElementById(id)?.querySelector('.input-text')?.textContent || '').trim());
  const hasAny = raw.some(Boolean);
  const setState = (state, message = '') => {
    if (result?.dataset) result.dataset.state = state;
    if (result) result.hidden = state !== 'success';
    if (note) { note.hidden = state === 'success'; if (message) note.textContent = message; }
  };

  if (!hasAny) {
    setState('empty', 'Enter values, then calculate.');
    return;
  }
  if (![d, eff, p].every(Number.isFinite)) {
    setState('incomplete', 'Complete all three fields to calculate.');
    return;
  }
  if (!(d > 0) || !(eff > 0) || !(p >= 0)) {
    setState('error', 'Check distance, efficiency and fuel price.');
    return;
  }
  const fuel = d / eff;
  const cost = fuel * p;
  if (!Number.isFinite(fuel) || !Number.isFinite(cost)) {
    setState('error', 'Values are outside the supported range.');
    return;
  }
  setState('success');
  setElementText('fc-fuel-res', `${formatResultNumber(fuel)} L`);
  setElementText('fc-cost-res', `$ ${formatResultNumber(cost)}`);
}

// 10. FUEL EFFICIENCY — fill-to-fill tank calculation
function calcFuelEfficiency() {
  const read = id => readModuleNumber(id);
  const ids = ['fe-before','fe-after','fe-added','fe-dist'];
  const raw = ids.map(id => (document.getElementById(id)?.querySelector('.input-text')?.textContent || '').trim());
  const hasAny = raw.some(Boolean);
  const resultCard = document.getElementById('fuel-efficiency-result');
  const before=read('fe-before'), after=read('fe-after'), added=read('fe-added'), distance=read('fe-dist');
  const consumed=before+added-after;
  if (![before,after,added,distance].every(Number.isFinite) || before<0 || after<0 || added<0 || distance<=0 || consumed<=0) {
    if (resultCard) resultCard.dataset.state = hasAny ? 'incomplete' : 'empty';
    const prompt = hasAny ? 'Complete all four fields' : 'Enter your data';
    setElementText('fe-consumed-res',prompt); setElementText('fe-kml-res',prompt); setElementText('fe-l100-res',prompt); setElementText('fe-mpg-res',prompt);
    return;
  }
  const kmPerL=distance/consumed;
  if (![consumed,kmPerL,consumed/distance*100,kmPerL*2.35214583].every(Number.isFinite)) {
    if (resultCard) resultCard.dataset.state = 'error';
    setElementText('fe-consumed-res','Value out of range'); setElementText('fe-kml-res','Value out of range'); setElementText('fe-l100-res','Value out of range'); setElementText('fe-mpg-res','Value out of range'); return;
  }
  if (resultCard) resultCard.dataset.state = 'success';
  setElementText('fe-consumed-res',`${formatResultNumber(consumed)} L`);
  setElementText('fe-kml-res',`${formatResultNumber(kmPerL)} km/L`);
  setElementText('fe-l100-res',`${formatResultNumber(consumed/distance*100)} L/100km`);
  setElementText('fe-mpg-res',`${formatResultNumber(kmPerL*2.35214583)} mpg`);
}

// 11. GRADE AVERAGE — dynamic subject rows, weighted GPA
const GPA_GRADE_OPTIONS = [
  ['A+',4.0],['A',4.0],['A-',3.7],['B+',3.3],['B',3.0],['B-',2.7],['C+',2.3],['C',2.0],['C-',1.7],['D+',1.3],['D',1.0],['F',0.0]
];
function createGpaCourseRow(course={}) {
  const container=document.getElementById('gpa-rows');
  if (!container || container.children.length>=100) { showToast('Maximum 100 subjects allowed'); return; }
  const row=document.createElement('div'); row.className='gpa-course-row'; row.setAttribute('role','group');
  const name=document.createElement('input'); name.type='text'; name.className='gpa-subject'; name.maxLength=60; name.placeholder='Subject name'; name.autocomplete='off'; name.value=course.name||''; name.setAttribute('aria-label','Subject name');
  const credit=document.createElement('input'); credit.type='number'; credit.min='0'; credit.max='999999999999999'; credit.step='any'; credit.inputMode='decimal'; credit.className='gpa-credits'; credit.placeholder='Credits'; credit.value=course.credit??''; credit.setAttribute('aria-label','Credits');
  const grade=document.createElement('select'); grade.className='gpa-grade'; grade.setAttribute('aria-label','Grade');
  GPA_GRADE_OPTIONS.forEach(([label,points])=>{const opt=document.createElement('option');opt.value=String(points);opt.textContent=label;opt.dataset.grade=label;grade.appendChild(opt);});
  if (course.gradeLabel) { const option=[...grade.options].find(o=>o.dataset.grade===course.gradeLabel); if(option)grade.value=option.value; }
  const remove=document.createElement('button'); remove.type='button'; remove.className='gpa-remove-row'; remove.textContent='×'; remove.title='Remove subject'; remove.setAttribute('aria-label','Remove subject');
  row.append(name,credit,grade,remove); container.appendChild(row);
  [name,credit,grade].forEach(el=>{el.addEventListener('input',()=>{if(el===credit)enforceGpaCreditLimit(credit);calcGpa();});el.addEventListener('change',calcGpa);});
  remove.addEventListener('click',()=>{row.remove();calcGpa();persistGpaCourses();});
  credit.addEventListener('blur',persistGpaCourses); name.addEventListener('blur',persistGpaCourses); grade.addEventListener('change',persistGpaCourses);
  calcGpa();
  return row;
}
function enforceGpaCreditLimit(input) {
  let raw=String(input.value??'').replace(/[^0-9.]/g,'');
  const dot=raw.indexOf('.'); if(dot!==-1)raw=raw.slice(0,dot+1)+raw.slice(dot+1).replace(/\./g,'');
  let [whole,fraction]=raw.split('.'); whole=(whole||'').slice(0,15); fraction=fraction===undefined?undefined:fraction.slice(0,Math.max(0,15-whole.length));
  input.value=whole+(fraction!==undefined?'.'+fraction:'');
}
function persistGpaCourses() {
  try {
    const courses=[...document.querySelectorAll('#gpa-rows .gpa-course-row')].map(row=>({name:row.querySelector('.gpa-subject').value.slice(0,60),credit:row.querySelector('.gpa-credits').value.slice(0,40),gradeLabel:row.querySelector('.gpa-grade').selectedOptions[0]?.dataset.grade||'A'}));
    localStorage.setItem('sumaire_gpa_courses_v1',JSON.stringify(courses));
  } catch (_) {}
}
function initGpaCourses() {
  const container=document.getElementById('gpa-rows'); if(!container)return;
  container.replaceChildren();
  let saved=[]; try {const raw=localStorage.getItem('sumaire_gpa_courses_v1');if(raw&&raw.length<50000){const data=JSON.parse(raw);if(Array.isArray(data))saved=data.slice(0,100);}}catch(_){}
  saved.forEach(course=>createGpaCourseRow(course));
  const add=document.getElementById('btn-add-course'); if(add)add.addEventListener('click',()=>{createGpaCourseRow();persistGpaCourses();});
  calcGpa();
}
function calcGpa() {
  let points=0,credits=0;
  document.querySelectorAll('#gpa-rows .gpa-course-row').forEach(row=>{
    const c=Number(row.querySelector('.gpa-credits')?.value);
    const g=Number(row.querySelector('.gpa-grade')?.value);
    if(Number.isFinite(c)&&c>0&&Number.isFinite(g)){credits+=c;points+=c*g;}
  });
  setElementText('gpa-credits-res',formatResultNumber(credits));
  setElementText('gpa-val-res',credits>0?formatResultNumber(points/credits):'0');
}

// 12. HEXADECIMAL CONVERTER — synchronized HEX/DEC/OCT/BIN inputs
let hexBase=16, hexDigits='0', hexCursor=1;
function hexCurrentBigInt() { try { const prefix=hexBase===16?'0x':hexBase===8?'0o':hexBase===2?'0b':''; return BigInt(prefix+hexDigits); } catch(_) {return 0n;} }
function renderHexValues() {
  const value=hexCurrentBigInt();
  const vals={16:value.toString(16).toUpperCase(),10:value.toString(10),8:value.toString(8),2:value.toString(2)};
  Object.entries(vals).forEach(([base,text])=>{
    const el=document.getElementById(`hex-input-${base}`); if(!el)return;
    if(Number(base)===hexBase){const pos=Math.max(0,Math.min(hexCursor,hexDigits.length));el.replaceChildren(document.createTextNode(hexDigits.slice(0,pos)));const caret=document.createElement('span');caret.className='hex-caret';caret.textContent='|';el.append(caret,document.createTextNode(hexDigits.slice(pos)));}
    else el.textContent=text;
  });
  document.querySelectorAll('.hex-convert-row').forEach(row=>row.classList.toggle('active',Number(row.dataset.hexBase)===hexBase));
  const allowed = '0123456789ABCDEF'.slice(0, hexBase);
  document.querySelectorAll('[data-hexkey]').forEach(btn=>{
    const key = btn.dataset.hexkey;
    const digitKey = /^[0-9A-F]$/.test(key);
    if (digitKey) {
      const valid = allowed.includes(key);
      btn.disabled = !valid;
      btn.setAttribute('aria-disabled', String(!valid));
    } else { btn.disabled = false; btn.removeAttribute('aria-disabled'); }
  });
}
function openHexKeyboard() {
  const sheet=document.getElementById('hex-keyboard-sheet');
  if(!sheet)return;
  sheet.classList.add('active');
  sheet.setAttribute('aria-hidden','false');
}
function closeHexKeyboard() {
  const sheet=document.getElementById('hex-keyboard-sheet');
  if(!sheet)return;
  sheet.classList.remove('active');
  sheet.setAttribute('aria-hidden','true');
}
function selectHexBase(base) {
  const current=hexCurrentBigInt(); hexBase=base; hexDigits=current.toString(base).toUpperCase(); hexCursor=hexDigits.length; renderHexValues(); openHexKeyboard();
}
function handleHexKey(key) {
  if(key==='DONE'){closeHexKeyboard();return;}
  const radix=hexBase; const allowed='0123456789ABCDEF'.slice(0,radix);
  if(key==='CLR'){hexDigits='0';hexCursor=1;}
  else if(key==='DEL'){if(hexCursor>0&&hexDigits.length>1){hexDigits=hexDigits.slice(0,hexCursor-1)+hexDigits.slice(hexCursor);hexCursor--;}else if(hexDigits.length===1){hexDigits='0';hexCursor=1;}}
  else if(key==='LEFT'){hexCursor=Math.max(0,hexCursor-1);}
  else if(key==='RIGHT'){hexCursor=Math.min(hexDigits.length,hexCursor+1);}
  else {
    if(!allowed.includes(key))return;
    if(hexDigits==='0'&&hexCursor===1){hexDigits=key;hexCursor=1;}
    else {if(hexDigits.length>=32){showToast('Maximum 32 digits allowed');return;}hexDigits=hexDigits.slice(0,hexCursor)+key+hexDigits.slice(hexCursor);hexCursor++;}
  }
  renderHexValues();
}
document.querySelectorAll('.hex-convert-row').forEach(row=>{
  const activate = () => selectHexBase(Number(row.dataset.hexBase));
  row.addEventListener('click', activate);
  row.addEventListener('keydown', event => { if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); activate(); } });
});
document.querySelectorAll('[data-hexkey]').forEach(btn=>btn.addEventListener('click',()=>handleHexKey(btn.dataset.hexkey)));
document.getElementById('hex-keyboard-done')?.addEventListener('click',closeHexKeyboard);
document.addEventListener('keydown',event=>{if(event.key==='Escape'&&document.getElementById('hex-keyboard-sheet')?.classList.contains('active')){event.preventDefault();closeHexKeyboard();}});
window.addEventListener('popstate',closeHexKeyboard);
renderHexValues();

// 13. LOAN CALCULATOR — stable amortization engine with auditable schedule
function calcLoan() {
  const principal = readModuleNumber('loan-p');
  const annualRate = readModuleNumber('loan-r');
  const yearsInput = document.getElementById('loan-years');
  const monthsRaw = yearsInput && yearsInput.querySelector && yearsInput.querySelector('.input-text') ? readModuleNumber('loan-years') * 12 : readModuleNumber('loan-m');
  const graceRaw = readModuleNumber('loan-grace');
  const method = document.getElementById('loan-method')?.value || 'total';
  const tbody = document.querySelector('#loan-amort tbody');
  if (!tbody) return;
  tbody.replaceChildren();
  const valid = [principal, annualRate, monthsRaw, graceRaw].every(Number.isFinite) &&
    principal >= 0 && annualRate >= 0 && annualRate <= 1000 &&
    Number.isInteger(monthsRaw) && monthsRaw >= 1 && monthsRaw <= 1200 &&
    Number.isInteger(graceRaw) && graceRaw >= 0 && graceRaw < monthsRaw &&
    (method === 'total' || method === 'principal');
  if (!valid) {
    setElementText('loan-monthly', 'Enter valid data');
    setElementText('loan-interest', '—');
    setElementText('loan-total', '—');
    setElementText('loan-schedule-note', 'Check principal, annual rate (0–1000%), period (1–1200 months), and grace months.');
    return;
  }
  const months = monthsRaw;
  const graceMonths = graceRaw;
  const monthlyRate = annualRate / 1200;

  const repaymentMonths = months - graceMonths;
  // expm1/log1p avoids cancellation in 1 - (1+r)^-n, especially for tiny rates.
  const annuityDenominator = monthlyRate === 0
    ? 1
    : -Math.expm1(-repaymentMonths * Math.log1p(monthlyRate));
  const fixedPayment = monthlyRate === 0
    ? principal / repaymentMonths
    : (principal * monthlyRate) / annuityDenominator;
  const principalPerMonth = principal / repaymentMonths;
  let balance = principal;
  let totalInterest = 0;
  let totalPaid = 0;
  let firstRegularPayment = 0;
  const rows = document.createDocumentFragment();

  for (let month = 1; month <= months; month++) {
    const openingBalance = balance;
    const interest = openingBalance * monthlyRate;
    let principalPaid = 0;
    let payment = interest;

    if (month > graceMonths) {
      if (method === 'principal') {
        principalPaid = month === months ? balance : Math.min(balance, principalPerMonth);
        payment = interest + principalPaid;
      } else {
        // Force exact payoff in the final period to remove floating-point residue.
        principalPaid = month === months ? balance : Math.min(balance, Math.max(0, fixedPayment - interest));
        payment = interest + principalPaid;
      }
      if (month === graceMonths + 1) firstRegularPayment = payment;
    }

    balance = Math.max(0, balance - principalPaid);
    totalInterest += interest;
    totalPaid += payment;

    const row = document.createElement('tr');
    const values = [
      month,
      formatResultNumber(payment),
      formatResultNumber(principalPaid),
      formatResultNumber(interest),
      formatResultNumber(balance)
    ];
    values.forEach((value, index) => {
      const cell = document.createElement('td');
      cell.textContent = String(value);
      if (index === 0) cell.className = 'schedule-period';
      row.appendChild(cell);
    });
    rows.appendChild(row);
  }
  tbody.appendChild(rows);

  const monthlyLabel = document.getElementById('loan-monthly-label');
  if (monthlyLabel) {
    monthlyLabel.textContent = graceMonths > 0
      ? (method === 'principal' ? 'First payment after interest-only period' : 'Monthly payment after interest-only period')
      : (method === 'principal' ? 'First monthly payment' : 'Monthly payment');
  }
  setElementText('loan-monthly', `$ ${formatResultNumber(graceMonths === months ? principal * monthlyRate : (firstRegularPayment || fixedPayment))}`);
  setElementText('loan-interest', `$ ${formatResultNumber(totalInterest)}`);
  setElementText('loan-total', `$ ${formatResultNumber(totalPaid)}`);
  setElementText('loan-schedule-note', `${months} monthly payments · ${graceMonths} interest-only months · ${method === 'principal' ? 'Equal principal' : 'Equal total payment'}`);
}

// 14. SAVINGS CALCULATOR — simple or periodic compound interest with tax
function calcSavings() {
  const read=id=>readModuleNumber(id);
  const principal=read('sav-p'), rate=read('sav-r')/100, years=read('sav-m'), taxPct=read('sav-tax');
  const frequency=document.getElementById('sav-frequency')?.value||'simple';
  if(![principal,rate,years,taxPct].every(Number.isFinite)||principal<0||rate<0||years<0||years>100||taxPct<0||taxPct>100){setElementText('sav-int-res','Please enter your data');setElementText('sav-bal-res','Please enter your data');return;}
  let grossInterest=0;
  if(frequency==='simple') grossInterest=principal*rate*years;
  else {const n=Number(frequency);if(!Number.isFinite(n)||n<1){setElementText('sav-int-res','Please enter your data');setElementText('sav-bal-res','Please enter your data');return;}grossInterest=principal*(Math.pow(1+rate/n,n*years)-1);}
  const netInterest=grossInterest*(1-taxPct/100); const balance=principal+netInterest;
  if (!Number.isFinite(netInterest) || !Number.isFinite(balance)) {setElementText('sav-int-res','Value out of range');setElementText('sav-bal-res','Value out of range');return;}
  setElementText('sav-int-res',`$ ${formatResultNumber(netInterest)}`);setElementText('sav-bal-res',`$ ${formatResultNumber(balance)}`);
}

// 16. TIP CALCULATOR
function calcTip() {
  const read = id => readModuleNumber(id);
  const billRaw = (document.getElementById('tip-bill')?.querySelector('.input-text')?.textContent || '').trim();
  const pctRaw = (document.getElementById('tip-pct')?.querySelector('.input-text')?.textContent || '').trim();
  const bill = read('tip-bill');
  const pctValue = read('tip-pct');
  const peopleRaw = readModuleNumber('tip-people', { allowEmpty: true });
  const taxRaw = readModuleNumber('tip-tax', { allowEmpty: true });
  const people = peopleRaw === null ? 1 : peopleRaw;
  const tax = taxRaw === null ? 0 : taxRaw;
  const invalid = !billRaw || !pctRaw || !Number.isFinite(bill) || bill < 0 ||
    !Number.isFinite(pctValue) || pctValue < 0 || pctValue > 1000 ||
    !Number.isFinite(people) || !Number.isInteger(people) || people < 1 || people > 1000000 ||
    !Number.isFinite(tax) || tax < 0 || tax > bill;
  if (invalid) {
    setElementText('tip-amt-res', 'Please enter valid data');
    setElementText('tip-tot-res', 'Please enter valid data');
    setElementText('tip-per-res', 'Please enter valid data');
    return;
  }
  const excludeTax = !!document.getElementById('tip-exclude-tax')?.checked;
  const tipBase = excludeTax ? bill - tax : bill;
  const tipAmt = tipBase * (pctValue / 100);
  const total = bill + tipAmt;
  const perPerson = total / people;
  if (![tipAmt, total, perPerson].every(Number.isFinite)) {
    setElementText('tip-amt-res', 'Value out of range'); setElementText('tip-tot-res', 'Value out of range'); setElementText('tip-per-res', 'Value out of range'); return;
  }
  setElementText('tip-amt-res', `$ ${formatResultNumber(tipAmt)}`);
  setElementText('tip-tot-res', `$ ${formatResultNumber(total)}`);
  setElementText('tip-per-res', `$ ${formatResultNumber(perPerson)}`);
}

function reorderReferenceSettings() {
  const host = document.querySelector('#screen-settings .settings-scroll');
  if (!host || host.dataset.referenceOrderApplied === 'true') return;
  const pairs = new Map();
  Array.from(host.children).forEach(node => {
    if (!node.classList?.contains('settings-group-title')) return;
    const card = node.nextElementSibling;
    if (card?.classList.contains('settings-card')) pairs.set(node.textContent.trim().toUpperCase(), [node, card]);
  });
  const order = ['STARTUP PREFERENCES','SOUND & VIBRATION','PRIVACY','THEME & COLORS','CALCULATOR SETTINGS','APPEARANCE','DECIMAL & NUMBER FORMAT','LANGUAGE','FAVORITES MANAGEMENT','HISTORY SETTINGS','CLIPBOARD & COPY','ABOUT & SUPPORT'];
  const used = new Set();
  const fragment = document.createDocumentFragment();
  order.forEach(title => { const pair = pairs.get(title); if (pair) { pair.forEach(node => fragment.appendChild(node)); used.add(title); } });
  pairs.forEach((pair,title) => { if (!used.has(title)) pair.forEach(node => fragment.appendChild(node)); });
  // Preserve any non-section nodes (for example future controls) after the known settings groups.
  Array.from(host.children).forEach(node => { if (!node.classList?.contains('settings-group-title') && !node.classList?.contains('settings-card')) fragment.appendChild(node); });
  host.appendChild(fragment);
  host.dataset.referenceOrderApplied = 'true';
}

function initReferenceScreenActions() {
  document.getElementById('fc-calculate')?.addEventListener('click', calcFuelCost);
  document.getElementById('tax-calculate')?.addEventListener('click', calcSalesTax);
  document.getElementById('loan-calculate')?.addEventListener('click', calcLoan);
  document.getElementById('tip-calculate')?.addEventListener('click', calcTip);
  document.getElementById('unit-price-compare')?.addEventListener('click', calcUnitPrice);
  document.querySelectorAll('[data-tip-preset]').forEach(button => button.addEventListener('click', () => {
    const preset = button.dataset.tipPreset;
    document.querySelectorAll('[data-tip-preset]').forEach(item => item.classList.toggle('active', item === button));
    const custom = document.getElementById('tip-custom-wrap');
    if (custom) custom.classList.toggle('is-custom', preset === 'custom');
    if (preset !== 'custom') {
      const field = document.getElementById('tip-pct');
      const text = field?.querySelector('.input-text');
      if (text) text.textContent = preset;
      if (field) field.classList.remove('active');
      calcTip();
    } else {
      const field = document.getElementById('tip-pct');
      if (field) setActiveInput(field);
    }
  }));
}

function initTipTaxOption() {
  const checkbox = document.getElementById('tip-exclude-tax');
  if (checkbox) checkbox.addEventListener('change', calcTip);
}

// 17. UNIT PRICE CALCULATOR — four-product comparison (A–D)
function calcUnitPrice() {
  const read=id=>readModuleNumber(id);
  const items=['A','B','C','D'].map((key,index)=>{
    const rowId=`up-row-${key}`;
    const heading=document.getElementById(rowId)?.previousElementSibling;
    const label=heading?.tagName==='H3' ? heading.textContent.trim() : `Item ${index+1}`;
    return {key,label,price:read(`up-p-${key.toLowerCase()}`),quantity:read(`up-q-${key.toLowerCase()}`),result:`up-u-${key.toLowerCase()}`,row:rowId};
  });
  items.forEach(item=>{item.valid=Number.isFinite(item.price)&&item.price>=0&&Number.isFinite(item.quantity)&&item.quantity>0;item.unitPrice=item.valid?item.price/item.quantity:NaN;item.valid=item.valid&&Number.isFinite(item.unitPrice);setElementText(item.result,item.valid?formatResultNumber(item.unitPrice):'—');});
  document.querySelectorAll('.unit-price-grid').forEach(row=>row.classList.remove('best-deal'));
  const candidates=items.filter(item=>item.valid);
  if(!candidates.length){setElementText('up-best-banner','Please enter your data');return;}
  const best=Math.min(...candidates.map(item=>item.unitPrice));
  const winners=candidates.filter(item=>Math.abs(item.unitPrice-best)<=Number.EPSILON*Math.max(1,Math.abs(best))*4);
  winners.forEach(item=>document.getElementById(item.row)?.classList.add('best-deal'));
  setElementText('up-best-banner',winners.length>1?`${winners.map(item=>item.label).join(', ')} (Equal lowest unit price)`:`${winners[0].label} (Lowest unit price)`);
}

// 18. WORLD TIME CONVERTER — searchable IANA time-zone database
function availableWorldTimeZones() {
  try {
    if (typeof Intl.supportedValuesOf === 'function') {
      const zones = Intl.supportedValuesOf('timeZone');
      if (Array.isArray(zones) && zones.length > 100) return zones;
    }
  } catch (_) {}
  return [
    'Africa/Cairo','Africa/Johannesburg','America/Anchorage','America/Argentina/Buenos_Aires',
    'America/Chicago','America/Denver','America/Los_Angeles','America/Mexico_City','America/New_York',
    'America/Phoenix','America/Sao_Paulo','America/Toronto','America/Vancouver','Asia/Bangkok',
    'Asia/Dubai','Asia/Hong_Kong','Asia/Jakarta','Asia/Karachi','Asia/Kolkata','Asia/Seoul',
    'Asia/Shanghai','Asia/Singapore','Asia/Tokyo','Australia/Adelaide','Australia/Brisbane',
    'Australia/Melbourne','Australia/Perth','Australia/Sydney','Europe/Amsterdam','Europe/Athens',
    'Europe/Berlin','Europe/Istanbul','Europe/London','Europe/Madrid','Europe/Moscow','Europe/Paris',
    'Pacific/Auckland','Pacific/Honolulu'
  ];
}

function isValidTimeZone(zone) {
  if (typeof zone !== 'string' || zone.length > 80 || !/^[A-Za-z_+-]+(?:\/[A-Za-z0-9_+.-]+)+$/.test(zone)) return false;
  try { new Intl.DateTimeFormat('en-US', {timeZone: zone}).format(new Date()); return true; }
  catch (_) { return false; }
}

function worldZoneLabel(zone) {
  const city = zone.split('/').pop().replace(/_/g, ' ');
  const region = zone.split('/')[0].replace(/_/g, ' ');
  return `${city} · ${region}`;
}

function initWorldTime() {
  const select = document.getElementById('wt-zone-select');
  const add = document.getElementById('wt-add-city');
  const search = document.getElementById('wt-zone-search');
  if (!select || !add) return;
  const zones = availableWorldTimeZones();
  const populate = query => {
    const q = String(query || '').trim().toLowerCase();
    const matches = zones.filter(zone => !q || zone.toLowerCase().includes(q) || worldZoneLabel(zone).toLowerCase().includes(q));
    const fragment = document.createDocumentFragment();
    if (!matches.length) {
      const option = document.createElement('option');
      option.value = ''; option.textContent = 'No matching time zones'; option.disabled = true; option.selected = true;
      fragment.appendChild(option);
    } else {
      matches.forEach(zone => {
        const option = document.createElement('option');
        option.value = zone;
        option.textContent = worldZoneLabel(zone);
        fragment.appendChild(option);
      });
    }
    select.replaceChildren(fragment);
    add.disabled = !matches.length;
  };
  populate('');
  if (search) search.addEventListener('input', () => populate(search.value));
  try {
    const saved = JSON.parse(localStorage.getItem('sumaire_world_cities_v1') || 'null');
    if (Array.isArray(saved)) {
      const safe = [...new Set(saved.filter(isValidTimeZone))].slice(0, 20);
      if (safe.length) STATE.worldTimeZones = safe;
    }
  } catch (_) {}
  STATE.worldTimeZones = [...new Set(STATE.worldTimeZones.filter(isValidTimeZone))].slice(0, 20);
  if (!STATE.worldTimeZones.length) STATE.worldTimeZones = ['America/New_York','Europe/London','Asia/Kolkata','Asia/Tokyo'];
  add.addEventListener('click', () => {
    const zone = select.value;
    if (!isValidTimeZone(zone)) { showToast('Choose a valid city or time zone'); return; }
    if (STATE.worldTimeZones.includes(zone)) { showToast('This city is already on your clock list'); return; }
    if (STATE.worldTimeZones.length >= 20) { showToast('You can add up to 20 world clocks'); return; }
    STATE.worldTimeZones.push(zone);
    persistWorldTimeZones();
    renderWorldTimeClocks();
  });
  renderWorldTimeClocks();
}

function persistWorldTimeZones() {
  try { localStorage.setItem('sumaire_world_cities_v1', JSON.stringify(STATE.worldTimeZones)); } catch (_) {}
}

function renderWorldTimeClocks() {
  const list = document.getElementById('wt-city-list');
  if (!list) return;
  list.replaceChildren();
  if (!STATE.worldTimeZones.length) {
    const empty = document.createElement('div'); empty.className = 'world-help-note'; empty.textContent = 'No cities added yet. Search above to add a world clock.'; list.appendChild(empty);
  }
  STATE.worldTimeZones.forEach(zone => {
    const row = document.createElement('div');
    row.className = 'world-clock-row';
    row.dataset.zone = zone;
    const label = document.createElement('div');
    label.className = 'world-clock-label';
    const name = document.createElement('strong');
    const city = zone.split('/').pop().replace(/_/g, ' ');
    const flags = {'America/New_York':'🇺🇸','Europe/London':'🇬🇧','Asia/Kolkata':'🇮🇳','Asia/Tokyo':'🇯🇵','Asia/Dubai':'🇦🇪'};
    name.textContent = `${flags[zone] || '🌍'}  ${city}`;
    const zoneName = document.createElement('span');
    zoneName.textContent = zone;
    label.append(name, zoneName);
    const time = document.createElement('time');
    time.className = 'world-clock-time';
    time.dataset.zone = zone;
    const remove = document.createElement('button');
    remove.type = 'button'; remove.className = 'world-remove-btn'; remove.textContent = '×';
    remove.title = `Remove ${worldZoneLabel(zone)}`;
    remove.setAttribute('aria-label', remove.title);
    remove.addEventListener('click', () => {
      STATE.worldTimeZones = STATE.worldTimeZones.filter(item => item !== zone);
      persistWorldTimeZones();
      renderWorldTimeClocks();
    });
    const date = document.createElement('span');
    date.className = 'world-clock-date';
    date.dataset.zoneDate = zone;
    row.append(label, time, date, remove);
    list.appendChild(row);
  });
  updateWorldTimeLive();
}

function worldTimeDateTimeValue(zone, date) {
  // The <time datetime> attribute must be machine-readable. Do not use a
  // locale-formatted display string (which varies by language and device).
  // Numeric formatToParts options are more widely supported than dateStyle /
  // timeStyle on older Android System WebView / ICU versions.
  try {
    const parts = new Intl.DateTimeFormat('en-CA', {
      timeZone: zone, year: 'numeric', month: '2-digit', day: '2-digit',
      hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
    }).formatToParts(date);
    const values = Object.create(null);
    parts.forEach(part => { if (part.type !== 'literal') values[part.type] = part.value; });
    if (!values.year || !values.month || !values.day || !values.hour || !values.minute) return '';
    return `${String(values.year).padStart(4, '0')}-${values.month}-${values.day}T${values.hour}:${values.minute}`;
  } catch (_) {
    // Display time remains useful even when formatToParts is unavailable.
    return '';
  }
}

function updateWorldTimeLive() {
  const now = new Date();
  const formatTime = zone => new Intl.DateTimeFormat(globalThis.SALocalization?.locale || undefined, {
    timeZone: zone, hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
  }).format(now);
  const baseTime = document.getElementById('wt-base-time');
  const baseDate = document.getElementById('wt-base-date');
  if (baseTime) baseTime.textContent = formatTime('Asia/Kolkata');
  if (baseDate) {
    const dateText = new Intl.DateTimeFormat(globalThis.SALocalization?.locale || undefined, {timeZone:'Asia/Kolkata', weekday:'short', year:'numeric', month:'short', day:'numeric'}).format(now);
    // `shortOffset` is missing in some older Android System WebView / ICU builds.
    // Keep the world-clock screen usable there instead of aborting the whole update.
    let offset = 'GMT+5:30'; // Asia/Kolkata has no daylight-saving changes.
    try {
      const parts = new Intl.DateTimeFormat('en-US', {
        timeZone: 'Asia/Kolkata', timeZoneName: 'shortOffset'
      }).formatToParts(now);
      offset = parts.find(part => part.type === 'timeZoneName')?.value || offset;
    } catch (_) {
      // Stable India offset fallback for runtimes without shortOffset/formatToParts.
    }
    baseDate.textContent = `${dateText} · ${offset}`;
  }
  document.querySelectorAll('.world-clock-time[data-zone]').forEach(el => {
    const zone = el.dataset.zone;
    try {
      // Keep the visible clock independent from optional <time> metadata.
      el.textContent = formatTime(zone);
      const machineDateTime = worldTimeDateTimeValue(zone, now);
      if (machineDateTime) el.dateTime = machineDateTime;
      else if (typeof el.removeAttribute === 'function') el.removeAttribute('datetime');
    } catch (_) {
      el.textContent = '—';
      if (typeof el.removeAttribute === 'function') el.removeAttribute('datetime');
    }
  });
  document.querySelectorAll('.world-clock-date[data-zone-date]').forEach(el => {
    try { el.textContent = new Intl.DateTimeFormat(globalThis.SALocalization?.locale || undefined, { timeZone: el.dataset.zoneDate, weekday: 'short', month: 'short', day: 'numeric' }).format(now); }
    catch (_) { el.textContent = ''; }
  });
}


// CALCULATION HISTORY
// Persist history safely; restricted/private browser storage must never break the calculator.
function recordHistoryEntry(expr, res) {
  if (!STATE.recordHistory) return false;
  const limit = Math.max(1, Math.min(500, Number.parseInt(STATE.maxHistory, 10) || 50));
  const protectedCount = STATE.history.filter(item => item.locked === true).length;
  if (protectedCount >= limit) {
    showToast('All history slots are protected. Unlock an entry or increase the history limit to record more.');
    return false;
  }
  STATE.history.push({ expr: String(expr ?? '').slice(0, 250), res: String(res ?? '').slice(0, 100), name: '', locked: false });
  trimHistoryToLimit();
  persistHistory();
  updateHistoryDOM();
  return true;
}
function trimHistoryToLimit() {
  const limit = Math.max(1, Math.min(500, Number.parseInt(STATE.maxHistory, 10) || 50));
  const indexed = STATE.history.map((item, index) => ({ item, index }));
  // Protected entries are never silently evicted by the normal history cap.
  // The configured limit applies to unprotected entries; protected records may
  // make the total exceed that limit until the user explicitly unlocks/deletes.
  const locked = indexed.filter(entry => entry.item.locked === true);
  const unlockedSlots = Math.max(0, limit - locked.length);
  const unlocked = unlockedSlots ? indexed.filter(entry => entry.item.locked !== true).slice(-unlockedSlots) : [];
  const keep = new Set([...locked, ...unlocked].map(entry => entry.index));
  STATE.history = indexed.filter(entry => keep.has(entry.index)).map(entry => entry.item);
}
function persistHistory() {
  try {
    trimHistoryToLimit();
    localStorage.setItem('sumaire_history_v1', JSON.stringify(STATE.history));
  } catch (_) { /* Storage can be unavailable or full. */ }
}

function restoreHistory() {
  try {
    const raw = localStorage.getItem('sumaire_history_v1');
    if (!raw) { STATE.history = []; return; }
    const parsed = JSON.parse(raw);
    if (!Array.isArray(parsed)) { STATE.history = []; return; }
    STATE.history = parsed.filter(item => item && typeof item.expr === 'string' &&
      typeof item.res === 'string' && item.expr.length <= 250 && item.res.length <= 100)
      .map(item => ({ expr: item.expr, res: item.res, name: typeof item.name === 'string' ? item.name.slice(0, 60) : '', locked: item.locked === true }));
    persistHistory();
  } catch (_) { STATE.history = []; }
}

let historyModalOpener = null;
function openHistoryModal() {
  const modal = document.getElementById('history-modal');
  if (!modal) return;
  historyModalOpener = document.activeElement;
  modal.classList.add('active');
  document.body.classList.add('history-modal-open');
  modal.setAttribute('aria-hidden', 'false');
  document.querySelectorAll('[data-bottom-nav]').forEach(button => {
    const selected = button.dataset.bottomNav === 'history';
    button.classList.toggle('active', selected);
    if (selected) button.setAttribute('aria-current', 'page'); else button.removeAttribute('aria-current');
  });
  requestAnimationFrame(() => {
    if (!modal.classList.contains('active') || modal.getAttribute('aria-hidden') === 'true') return;
    const first = getModalFocusableElements(modal)[0];
    (first || modal).focus();
  });
}
function closeHistoryModal() {
  const modal = document.getElementById('history-modal');
  if (!modal) return;
  modal.classList.remove('active');
  document.body.classList.remove('history-modal-open');
  modal.setAttribute('aria-hidden', 'true');
  updateBottomNavigation(STATE.currentScreen);
  const target = historyModalOpener?.isConnected && historyModalOpener !== document.body && historyModalOpener !== document.documentElement
    ? historyModalOpener : document.getElementById('btn-history-open');
  target?.focus();
  historyModalOpener = null;
}
function initHistory() {
  const modal = document.getElementById('history-modal');
  document.getElementById('btn-history-open').onclick = openHistoryModal;
  document.getElementById('btn-history-close').onclick = closeHistoryModal;
  document.addEventListener('keydown', event => {
    if (!modal.classList.contains('active')) return;
    if (event.key === 'Escape') { event.preventDefault(); closeHistoryModal(); }
    else keepModalTabFocus(event, modal);
  });
  document.getElementById('btn-history-clear').onclick = () => {
    STATE.history = STATE.history.filter(item => item.locked === true);
    persistHistory();
    updateHistoryDOM();
    showToast('Unlocked history cleared; protected items kept');
  };
  updateHistoryDOM();
}

function copyTextFallback(text) {
  try {
    const area = document.createElement('textarea');
    area.value = String(text ?? '');
    area.setAttribute('readonly', '');
    area.style.position = 'fixed'; area.style.opacity = '0'; area.style.pointerEvents = 'none';
    document.body.appendChild(area); area.select();
    const copied = document.execCommand && document.execCommand('copy');
    area.remove();
    showToast(copied ? 'Copied' : 'Copy unavailable');
  } catch (_) { showToast('Copy unavailable'); }
}
let activeTextInputDialog = null;
function closeTextInputDialog(result = null) {
  const modal = document.getElementById('text-input-modal');
  if (!modal) return;
  modal.classList.remove('active');
  modal.setAttribute('aria-hidden', 'true');
  if (activeTextInputDialog?.resolve) activeTextInputDialog.resolve(result);
  activeTextInputDialog = null;
}
function openTextInputDialog({ title = 'Enter text', label = 'Name', value = '', placeholder = '', confirmText = 'SAVE' } = {}) {
  const modal = document.getElementById('text-input-modal');
  const input = document.getElementById('text-input-modal-field');
  const titleEl = document.getElementById('text-input-modal-title');
  const labelEl = document.getElementById('text-input-modal-label');
  const confirm = document.getElementById('text-input-modal-confirm');
  if (!modal || !input || !titleEl || !labelEl || !confirm) return Promise.resolve(null);
  if (activeTextInputDialog) closeTextInputDialog(null);
  titleEl.textContent = title;
  labelEl.textContent = label;
  input.value = String(value ?? '');
  input.placeholder = placeholder;
  confirm.textContent = confirmText;
  modal.classList.add('active');
  modal.setAttribute('aria-hidden', 'false');
  requestAnimationFrame(() => { input.focus({preventScroll:true}); input.select(); });
  return new Promise(resolve => { activeTextInputDialog = { resolve }; });
}
function initTextInputDialog() {
  const modal = document.getElementById('text-input-modal');
  const input = document.getElementById('text-input-modal-field');
  const confirm = document.getElementById('text-input-modal-confirm');
  const cancel = document.getElementById('text-input-modal-cancel');
  const close = document.getElementById('text-input-modal-close');
  if (!modal || !input || !confirm || !cancel || !close) return;
  const finish = accepted => {
    const value = accepted ? String(input.value || '').trim().slice(0, 60) : null;
    closeTextInputDialog(value);
  };
  confirm.addEventListener('click', () => finish(true));
  cancel.addEventListener('click', () => finish(false));
  close.addEventListener('click', () => finish(false));
  modal.addEventListener('click', event => { if (event.target === modal) finish(false); });
  input.addEventListener('keydown', event => {
    if (event.key === 'Enter') { event.preventDefault(); finish(true); }
    else if (event.key === 'Escape') { event.preventDefault(); finish(false); }
  });
}

function updateHistoryDOM() {
  const list = document.getElementById('history-items');
  if (!list) return;
  list.replaceChildren();
  if (STATE.history.length === 0) {
    const empty = document.createElement('div');
    empty.className = 'history-empty-state';
    const icon = document.createElement('span'); icon.className = 'history-empty-icon'; icon.setAttribute('aria-hidden', 'true'); icon.textContent = '◷';
    const title = document.createElement('strong'); title.textContent = 'No calculations yet';
    const hint = document.createElement('span'); hint.textContent = 'Your recent calculations will appear here.';
    empty.append(icon, title, hint);
    list.appendChild(empty);
    return;
  }
  STATE.history.slice().reverse().forEach(item => {
    const row = document.createElement('div');
    row.className = 'history-item';
    const title = document.createElement('div');
    title.className = 'history-item-title';
    title.textContent = item.name || 'Calculation';
    const expression = document.createElement('div');
    expression.className = 'history-item-expression';
    expression.textContent = `${String(item.expr)} =`;
    const result = document.createElement('div');
    result.className = 'history-item-result';
    result.textContent = String(item.res);
    row.append(title, expression, result);
    if (item.locked) {
      const lock = document.createElement('span');
      lock.className = 'history-protected-label';
      lock.textContent = 'Protected from clear/delete';
      row.appendChild(lock);
    }
    const actions = document.createElement('div');
    actions.className = 'history-actions';
    
    const makeAction = (label, action) => {
      const button = document.createElement('button');
      button.type = 'button'; button.textContent = label;
      button.className = 'history-action-btn';
      button.addEventListener('click', async () => {
        if (action === 'copy') {
          const text = `${item.expr} = ${item.res}`;
          try { await navigator.clipboard.writeText(text); showToast('Copied'); }
          catch (_) { copyTextFallback(text); }
        } else if (action === 'reuse') {
          STATE.calcResultExpression = null; STATE.calcExpr = String(item.expr || ''); STATE.calcCursor = STATE.calcSelectionStart = STATE.calcSelectionEnd = STATE.calcExpr.length; STATE.calcVal = String(item.res || '0');
          STATE.isResultMode = false; updateCalcDisplayDOM();
          closeHistoryModal();
        } else if (action === 'share') {
          const text = `${item.name ? item.name + ': ' : ''}${item.expr} = ${item.res}`;
          if (navigator.share) { try { await navigator.share({text}); } catch (_) {} }
          else { try { await navigator.clipboard.writeText(text); showToast('Copied for sharing'); } catch (_) { copyTextFallback(text); } }
        } else if (action === 'name') {
          const entered = await openTextInputDialog({
            title: item.name ? 'Rename calculation' : 'Name calculation',
            label: 'Calculation name',
            value: item.name || '',
            placeholder: 'e.g. Monthly budget',
            confirmText: 'SAVE'
          });
          if (entered === null) return;
          item.name = entered;
          persistHistory(); updateHistoryDOM();
        } else if (action === 'lock') {
          if (!item.locked && STATE.history.filter(entry => entry.locked === true).length >= Math.max(1, Math.min(500, Number.parseInt(STATE.maxHistory, 10) || 50))) {
            showToast('Protected history limit reached. Increase the history limit first.');
            return;
          }
          item.locked = !item.locked;
          persistHistory(); updateHistoryDOM();
          showToast(item.locked ? 'Calculation protected' : 'Calculation unprotected');
        } else if (action === 'delete' && !item.locked) {
          STATE.history = STATE.history.filter(entry => entry !== item);
          persistHistory(); updateHistoryDOM();
        }
      });
      actions.appendChild(button);
    };
    makeAction('Copy', 'copy'); makeAction('Reuse / Edit', 'reuse'); makeAction('Share', 'share');
    makeAction(item.name ? 'Rename' : 'Name', 'name');
    makeAction(item.locked ? 'Unlock' : 'Protect', 'lock');
    if (!item.locked) makeAction('Delete', 'delete');
    row.appendChild(actions);
    list.appendChild(row);
  });
}

// ANDROID-SAFE THEME PICKER
const THEME_PALETTE = {
  'Violet': '#8b78ff', 'Sky Blue': '#5bd7f2', 'Amber': '#f49a3e', 'Red': '#ef444f',
  'Mocha': '#76504d', 'Purple': '#7738d4', 'Pink': '#e65eae', 'Sand': '#f3c982',
  'Aqua': '#61d5d3', 'Blue': '#6594dc', 'Coral': '#dc5d5d', 'Yellow': '#e8d34b'
};
function currentThemeName() {
  const color = String(STATE.accentColor || '').toLowerCase();
  const found = Object.entries(THEME_PALETTE).find(([, value]) => value.toLowerCase() === color);
  if (found) return found[0];
  return 'Custom';
}
function renderThemePickerSelection() {
  const selected = currentThemeName();
  document.querySelectorAll('#theme-picker-options .theme-option').forEach(button => {
    const active = button.dataset.themeName === selected;
    button.classList.toggle('selected', active);
    button.setAttribute('aria-checked', active ? 'true' : 'false');
  });
  const label = document.getElementById('setting-theme-label');
  if (label) label.textContent = selected;
}
let themePickerOpener = null;
function openThemePicker() {
  const overlay = document.getElementById('theme-picker-overlay');
  const dialog = document.getElementById('theme-picker-dialog');
  if (!overlay || !dialog) return;
  themePickerOpener = document.activeElement;
  renderThemePickerSelection();
  overlay.classList.add('active'); dialog.classList.add('active');
  overlay.setAttribute('aria-hidden', 'false'); dialog.setAttribute('aria-hidden', 'false');
  document.body.classList.add('theme-picker-open');
  // Always begin at the first palette item; never restore a stale scroll offset.
  const list = document.getElementById('theme-picker-options');
  if (list) { list.scrollTop = 0; requestAnimationFrame(() => { list.scrollTop = 0; }); }
  requestAnimationFrame(() => {
    if (!dialog.classList.contains('active') || dialog.getAttribute('aria-hidden') === 'true') return;
    const first = getModalFocusableElements(dialog)[0];
    (first || dialog).focus();
  });
}
function closeThemePicker() {
  const overlay = document.getElementById('theme-picker-overlay');
  const dialog = document.getElementById('theme-picker-dialog');
  if (!overlay || !dialog) return;
  overlay.classList.remove('active'); dialog.classList.remove('active');
  overlay.setAttribute('aria-hidden', 'true'); dialog.setAttribute('aria-hidden', 'true');
  document.body.classList.remove('theme-picker-open');
  const target = themePickerOpener?.isConnected && themePickerOpener !== document.body && themePickerOpener !== document.documentElement
    ? themePickerOpener : document.getElementById('setting-theme-trigger');
  target?.focus();
  themePickerOpener = null;
}
function syncNativeColorScheme() {
  const selected = document.body?.getAttribute('data-theme') || 'light';
  const scheme = document.body?.classList.contains('oled-theme') ? 'dark' : (selected === 'light' ? 'light' : 'dark');
  if (document.documentElement) {
    document.documentElement.style.colorScheme = scheme;
    document.documentElement.setAttribute('data-color-scheme', scheme);
  }
  if (document.body) document.body.style.colorScheme = scheme;
  const themeMeta = document.querySelector('meta[name="theme-color"]');
  if (themeMeta) themeMeta.setAttribute('content', '#111116');
}

function setAccentThemeTokens(color) {
  // Apply the selected accent consistently across the charcoal reference UI.
  color = /^#[0-9a-f]{6}$/i.test(String(color)) ? String(color) : '#8b78ff';
  const root = document.documentElement;
  if (!root) return;
  root.style.setProperty('--primary-blue', color);
  root.style.setProperty('--primary-blue-hover', color);
  root.style.setProperty('--accent-cyan', color);
  root.style.setProperty('--theme-accent', color);
  root.style.setProperty('--theme-accent-soft', `color-mix(in srgb, ${color} 14%, transparent)`);
  root.style.setProperty('--field-border-active', color);
  root.style.setProperty('--field-border-ready', color);
  root.style.setProperty('--ui-focus-color', color);
  // Choose the foreground with the stronger WCAG contrast for this exact
  // accent. A fixed luminance threshold left some mid-tone palettes (notably
  // Pink) with white text below the recommended 4.5:1 small-text contrast.
  const hex = color.length === 4 ? color.slice(1).split('').map(ch => ch + ch).join('') : color.slice(1);
  const channels = [0, 2, 4].map(i => parseInt(hex.slice(i, i + 2), 16) / 255).map(v => v <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4));
  const luminance = 0.2126 * channels[0] + 0.7152 * channels[1] + 0.0722 * channels[2];
  const whiteContrast = 1.05 / (luminance + 0.05);
  const darkContrast = (luminance + 0.05) / 0.05;
  root.style.setProperty('--accent-ink', darkContrast >= whiteContrast ? '#101820' : '#ffffff');
  if (document.body) {
    document.body.style.setProperty('--field-border-active', color);
    document.body.style.setProperty('--primary-blue', color);
    document.body.style.setProperty('--primary-blue-hover', color);
    document.body.style.setProperty('--accent-cyan', color);
    document.body.style.setProperty('--theme-accent', color);
    document.body.style.setProperty('--header-bg', color);
    document.body.style.setProperty('--header-text', 'var(--accent-ink)');
    document.body.setAttribute('data-accent-color', color.toLowerCase());
  }
  // Keep browser chrome and native controls synchronized after palette changes.
  syncNativeColorScheme();
}

function selectPaletteTheme(name) {
  const color = THEME_PALETTE[name];
  if (!color) return;
  STATE.accentColor = color;
  const mode = ['light', 'dark', 'system'].includes(STATE.theme) ? STATE.theme : 'dark';
  applySettingTheme(mode);
  const modeSelect = document.getElementById('setting-theme');
  if (modeSelect) modeSelect.value = mode;
  setAccentThemeTokens(color);
  const accentSelect = document.getElementById('setting-accent');
  if (accentSelect) accentSelect.value = color;
  saveSettingsToStorage();
  renderThemePickerSelection();
  closeThemePicker();
}
function initThemePicker() {
  const options = document.getElementById('theme-picker-options');
  if (options && !options.dataset.rendered) {
    options.replaceChildren();
    Object.entries(THEME_PALETTE).forEach(([name, color]) => {
      const button = document.createElement('button');
      button.type = 'button'; button.className = 'theme-option'; button.dataset.themeName = name;
      button.style.setProperty('--swatch', color); button.setAttribute('role', 'radio');
      const label = document.createElement('span'); label.textContent = name;
      const radio = document.createElement('span'); radio.className = 'theme-radio';
      button.append(label, radio); options.appendChild(button);
    });
    options.dataset.rendered = 'true';
  }
  if (options && !options.dataset.bound) {
    options.dataset.bound = 'true';
    options.addEventListener('click', event => {
      const option = event.target.closest('.theme-option');
      if (option) selectPaletteTheme(option.dataset.themeName);
    });
  }
  document.addEventListener('keydown', event => {
    const dialog = document.getElementById('theme-picker-dialog');
    if (!dialog?.classList.contains('active')) return;
    if (event.key === 'Escape') { event.preventDefault(); closeThemePicker(); }
    else keepModalTabFocus(event, dialog);
  });
  renderThemePickerSelection();
}

// REAL SETTINGS CONTROLS & EVENT HANDLERS
let systemThemeMediaQuery = null;
let systemThemeListenerBound = false;
function bindSystemThemePreference() {
  if (systemThemeListenerBound || !window.matchMedia) return;
  systemThemeMediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
  const onSystemThemeChange = () => {
    if (STATE.theme === 'system') applySettingTheme('system');
  };
  if (typeof systemThemeMediaQuery.addEventListener === 'function') {
    systemThemeMediaQuery.addEventListener('change', onSystemThemeChange);
  } else if (typeof systemThemeMediaQuery.addListener === 'function') {
    systemThemeMediaQuery.addListener(onSystemThemeChange);
  }
  systemThemeListenerBound = true;
}

function applySettingTheme(val) {
  // Keep appearance mode independent from the selected accent palette.
  if (!['dark', 'light', 'system'].includes(val)) val = 'dark';
  STATE.theme = val;
  bindSystemThemePreference();
  const resolved = val === 'dark' ? 'dark' : val === 'light' ? 'light' :
    (window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light');
  document.body.setAttribute('data-theme', resolved);
  document.body.setAttribute('data-theme-mode', val);
  const modeSelect = document.getElementById('setting-theme');
  if (modeSelect && modeSelect.value !== val) modeSelect.value = val;
  document.documentElement.setAttribute('data-theme', resolved);
  document.documentElement.setAttribute('data-theme-mode', val);
  syncNativeColorScheme();
  if (document.getElementById('theme-picker-dialog')) renderThemePickerSelection();
  saveSettingsToStorage();
}

function applySettingPrecision(val) {
  STATE.precision = val;
  saveSettingsToStorage();
  // trigger recalculations
  if (STATE.currentScreen === 'currencies') calcCurrency();
  else if (STATE.currentScreen === 'units') calcUnits();
  else if (STATE.currentScreen === 'discount') calcDiscount();
  else if (STATE.currentScreen === 'percent') calcPercent();
  else if (STATE.currentScreen === 'salestax') calcSalesTax();
  else if (STATE.currentScreen === 'loan') calcLoan();
  else if (STATE.currentScreen === 'savings') calcSavings();
  else if (STATE.currentScreen === 'bodymetrics') calcBodyMetrics();
  else if (STATE.currentScreen === 'fuelcost') calcFuelCost();
  else if (STATE.currentScreen === 'fuelefficiency') calcFuelEfficiency();
  else if (STATE.currentScreen === 'tip') calcTip();
  else if (STATE.currentScreen === 'unitprice') calcUnitPrice();
  else if (STATE.currentScreen === 'calc') updateCalcDisplayDOM();
}

function applySettingSeparator(val) {
  STATE.thousandsSep = val;
  saveSettingsToStorage();
  recalculateCurrentScreen();
  if (STATE.currentScreen === 'calc') updateCalcDisplayDOM();
}

function toggleHaptic(enabled) {
  STATE.hapticEnabled = enabled;
  saveSettingsToStorage();
}

function toggleAutoCopy(enabled) {
  STATE.autoCopy = enabled;
  saveSettingsToStorage();
}

function clearAllHistory() {
  const before = STATE.history.length;
  STATE.history = STATE.history.filter(item => item.locked === true);
  persistHistory();
  updateHistoryDOM();
  const removed = before - STATE.history.length;
  showToast(removed ? `${removed} unlocked history item${removed === 1 ? '' : 's'} cleared; protected items kept` : 'No unlocked history items to clear');
}

function resetAllDefaults() {
  const defaults = {
    hapticEnabled: true, vibeStrength: 'medium', keySound: true, autoCopy: false,
    thousandsSep: 'comma', precision: 'auto', language: 'en', fullscreen: false,
    fontSize: 'medium', screenAwake: false, theme: 'dark', accentColor: '#8b78ff',
    oledBlack: false, liveCalc: true, implicitMult: true, trailingZeros: true,
    startupScreen: 'calc', restoreState: true, recordHistory: true, maxHistory: '50',
    telemetry: false, favorites: ['calc', 'currencies', 'units', 'discount', 'percent', 'salestax']
  };
  Object.assign(STATE, defaults);
  const selects = {
    'setting-theme':'dark','setting-accent':'#8b78ff','setting-fontsize':'medium','setting-precision':'auto',
    'setting-separator':'comma','setting-language':'en','setting-startup-screen':'calc',
    'setting-max-history':'50','setting-vibe-strength':'medium'
  };
  Object.entries(selects).forEach(([id,value]) => { const el=document.getElementById(id); if(el) el.value=value; });
  const checks = {
    'setting-fullscreen':false,'setting-awake':false,'setting-oled':false,'setting-livecalc':true,
    'setting-implicit':true,'setting-trailing-zero':true,'setting-restore-state':true,
    'setting-record-history':true,'setting-autocopy':false,'setting-sound':true,
    'setting-haptic':true,'setting-telemetry':false
  };
  Object.entries(checks).forEach(([id,value]) => { const el=document.getElementById(id); if(el) el.checked=value; });
  applySettingTheme('dark'); applyAccentColor('#087fff'); applyFontSize('medium');
  applySettingPrecision('auto'); applySettingSeparator('comma');
  toggleOLED(false); toggleLiveCalc(true); toggleImplicit(true); toggleTrailingZero(true);
  toggleHaptic(true); toggleKeySound(true); toggleAutoCopy(false); toggleRestoreState(true);
  toggleRecordHistory(true); applyMaxHistory(50); applyVibeStrength('medium'); toggleTelemetry(false); applyLanguage('en');
  if (document.fullscreenElement && document.exitFullscreen) document.exitFullscreen().catch(()=>{});
  if (wakeLockSentinel) { wakeLockSentinel.release().catch(()=>{}); wakeLockSentinel=null; }
  saveSettingsToStorage(); initFavoritesManager(); updateDrawerFavoritesDOM();
  showToast('All settings restored to defaults');
}


// ==========================================
// COMPREHENSIVE SETTINGS CONTROLLER (12 CATEGORIES)
// ==========================================

let audioCtx = null;
function playKeyClickSound() {
  if (!STATE.keySound) return;
  try {
    if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
    if (audioCtx.state === 'suspended') audioCtx.resume();
    const osc = audioCtx.createOscillator();
    const gain = audioCtx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, audioCtx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(300, audioCtx.currentTime + 0.03);
    gain.gain.setValueAtTime(0.08, audioCtx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.03);
    osc.connect(gain);
    gain.connect(audioCtx.destination);
    osc.start();
    osc.stop(audioCtx.currentTime + 0.03);
  } catch(e) {}
}

async function toggleFullScreen(enabled) {
  const control = document.getElementById('setting-fullscreen');
  try {
    if (enabled) {
      if (!document.fullscreenElement && typeof document.documentElement.requestFullscreen === 'function') await document.documentElement.requestFullscreen();
      else if (!document.fullscreenElement) throw new Error('Fullscreen is not supported');
    } else if (document.fullscreenElement && typeof document.exitFullscreen === 'function') {
      await document.exitFullscreen();
    }
    STATE.fullscreen = Boolean(document.fullscreenElement);
    if (control) control.checked = STATE.fullscreen;
  } catch (_) {
    STATE.fullscreen = Boolean(document.fullscreenElement);
    if (control) control.checked = STATE.fullscreen;
    showToast('Fullscreen is not available in this browser');
  }
}
function syncFullscreenSetting() {
  STATE.fullscreen = Boolean(document.fullscreenElement);
  const control = document.getElementById('setting-fullscreen');
  if (control) control.checked = STATE.fullscreen;
}

function applyFontSize(val) {
  STATE.fontSize = val;
  saveSettingsToStorage();
  if (val === 'small') {
    document.body.style.fontSize = '13px';
    document.querySelectorAll('.key-btn').forEach(b => b.style.fontSize = '20px');
  } else if (val === 'large') {
    document.body.style.fontSize = '16px';
    document.querySelectorAll('.key-btn').forEach(b => b.style.fontSize = '25px');
  } else {
    document.body.style.fontSize = '14px';
    document.querySelectorAll('.key-btn').forEach(b => b.style.fontSize = '');
  }
  if (!isLoadingSettings) showToast(`Font scale set to ${val}`);
}

let wakeLockSentinel = null;
async function toggleScreenAwake(enabled) {
  STATE.screenAwake = enabled;
  const setting = document.getElementById('setting-awake');
  if (setting) setting.checked = enabled;
  saveSettingsToStorage();
  if (enabled && 'wakeLock' in navigator) {
    try {
      wakeLockSentinel = await navigator.wakeLock.request('screen');
      wakeLockSentinel.addEventListener('release', () => { wakeLockSentinel = null; });
    } catch(e) {
      STATE.screenAwake = false;
      if (setting) setting.checked = false;
      saveSettingsToStorage();
      showToast('Screen wake lock is unavailable or permission was denied');
    }
  } else if (!enabled && wakeLockSentinel) {
    try {
      await wakeLockSentinel.release();
      wakeLockSentinel = null;
    } catch(e) {}
  } else if (enabled) {
    STATE.screenAwake = false;
    if (setting) setting.checked = false;
    saveSettingsToStorage();
    showToast('Screen wake lock is not supported in this browser');
  }
}

function applyAccentColor(color) {
  // Accept only a validated CSS hex colour; palette buttons provide approved values.
  color = /^#[0-9a-f]{6}$/i.test(String(color)) ? String(color).toLowerCase() : '#8b78ff';
  STATE.accentColor = color;
  setAccentThemeTokens(color);
  saveSettingsToStorage();
  renderThemePickerSelection();
  if (!isLoadingSettings) showToast('Accent color updated');
}

function toggleOLED(enabled) {
  STATE.oledBlack = enabled;
  saveSettingsToStorage();
  if (enabled) { document.body.classList.add('oled-theme'); document.documentElement.classList.add('oled-theme'); }
  else { document.body.classList.remove('oled-theme'); document.documentElement.classList.remove('oled-theme'); }
  syncNativeColorScheme();
  if (!isLoadingSettings) showToast(enabled ? 'OLED True Black enabled' : 'OLED True Black disabled');
}

function toggleLiveCalc(enabled) {
  STATE.liveCalc = enabled;
  saveSettingsToStorage();
  updateCalcDisplayDOM();
  showToast(enabled ? 'Live result preview enabled' : 'Live result preview disabled');
}

function toggleImplicit(enabled) {
  STATE.implicitMult = enabled;
  saveSettingsToStorage();
  updateCalcDisplayDOM();
}

function toggleTrailingZero(enabled) {
  STATE.trailingZeros = enabled;
  saveSettingsToStorage();
  recalculateCurrentScreen();
  if (STATE.currentScreen === 'calc') updateCalcDisplayDOM();
}

const TRANSLATIONS = {
  en: {
    appTitle: 'SA Calculator',
    calc: 'Calculator',
    currencies: 'Currency Converter',
    units: 'Unit Converter',
    discount: 'Discount Calculator',
    percent: 'Percent Calculator',
    salestax: 'Sales Tax Calculator',
    bodymetrics: 'Body Metrics Calculator',
    date: 'Date Calculator',
    fuelcost: 'Fuel Cost Calculator',
    fuelefficiency: 'Fuel Efficiency',
    gradeavg: 'Grade Average',
    hex: 'Number Base Converter',
    loan: 'Loan / EMI Calculator',
    savings: 'Savings Calculator',
    tip: 'Tip Calculator',
    unitprice: 'Unit Price Calculator',
    worldtime: 'World Time Converter',
    settings: 'Settings',
    favoritesTitle: 'Favorites',
    allCalcsTitle: 'All Calculators',
    menuSettings: 'Settings',
    menuHelp: 'Help'
  },
  hi: {
    appTitle: 'SA Calculator',
    calc: 'कैलकुलेटर',
    currencies: 'मुद्रा परिवर्तक',
    units: 'इकाई परिवर्तक',
    discount: 'छूट कैलकुलेटर',
    percent: 'प्रतिशत कैलकुलेटर',
    salestax: 'बिक्री कर कैलकुलेटर',
    bodymetrics: 'शरीर मापदंड कैलकुलेटर',
    date: 'तारीख कैलकुलेटर',
    fuelcost: 'ईंधन लागत कैलकुलेटर',
    fuelefficiency: 'ईंधन दक्षता',
    gradeavg: 'ग्रेड औसत (GPA)',
    hex: 'संख्या आधार परिवर्तक',
    loan: 'ऋण / EMI कैलकुलेटर',
    savings: 'बचत कैलकुलेटर',
    tip: 'टिप कैलकुलेटर',
    unitprice: 'इकाई मूल्य तुलना',
    worldtime: 'विश्व समय परिवर्तक',
    settings: 'सेटिंग्स',
    favoritesTitle: 'पसंदीदा',
    allCalcsTitle: 'सभी कैलकुलेटर',
    menuSettings: 'सेटिंग्स',
    menuHelp: 'सहायता'
  },
  ur: {
    appTitle: 'SA Calculator',
    calc: 'کیلکولیٹر',
    currencies: 'کرنسی کنورٹر',
    units: 'یونٹ کنورٹر',
    discount: 'رعایت کیلکولیٹر',
    percent: 'فیصد کیلکولیٹر',
    salestax: 'سیلز ٹیکس کیلکولیٹر',
    bodymetrics: 'باڈی میٹرکس کیلکولیٹر',
    date: 'تاریخ کیلکولیٹر',
    fuelcost: 'فیول لاگت کیلکولیٹر',
    fuelefficiency: 'فیول ایفی شنسی',
    gradeavg: 'گریڈ اوسط (GPA)',
    hex: 'نمبر بیس کنورٹر',
    loan: 'قرض / EMI کیلکولیٹر',
    savings: 'بچت کیلکولیٹر',
    tip: 'ٹپ کیلکولیٹر',
    unitprice: 'یونٹ قیمت کا موازنہ',
    worldtime: 'عالمی وقت کنورٹر',
    settings: 'ترتیبات (Settings)',
    favoritesTitle: 'پسندیدہ',
    allCalcsTitle: 'تمام کیلکولیٹرز',
    menuSettings: 'سیٹنگز',
    menuHelp: 'مدد'
  },
  es: {
    appTitle: 'SA Calculator',
    calc: 'Calculadora',
    currencies: 'Conversor de Divisas',
    units: 'Conversor de Unidades',
    discount: 'Calculadora de Descuento',
    percent: 'Calculadora de Porcentaje',
    salestax: 'Impuesto sobre Ventas',
    bodymetrics: 'Métricas Corporales',
    date: 'Calculadora de Fechas',
    fuelcost: 'Costo de Combustible',
    fuelefficiency: 'Eficiencia de Combustible',
    gradeavg: 'Promedio de Calificaciones',
    hex: 'Conversor de Base Numérica',
    loan: 'Calculadora de Préstamos',
    savings: 'Calculadora de Ahorros',
    tip: 'Calculadora de Propinas',
    unitprice: 'Precio por Unidad',
    worldtime: 'Conversor de Hora Mundial',
    settings: 'Ajustes',
    favoritesTitle: 'Favoritos',
    allCalcsTitle: 'Todas las calculadoras',
    menuSettings: 'Ajustes',
    menuHelp: 'Ayuda'
  },
  fr: {
    appTitle: 'SA Calculator',
    calc: 'Calculatrice',
    currencies: 'Convertisseur de Devises',
    units: 'Convertisseur d’Unités',
    discount: 'Calculateur de Réduction',
    percent: 'Calculateur de Pourcentage',
    salestax: 'Taxe sur les Ventes',
    bodymetrics: 'Métriques Corporelles',
    date: 'Calculateur de Date',
    fuelcost: 'Coût du Carburant',
    fuelefficiency: 'Consommation de Carburant',
    gradeavg: 'Moyenne Générale',
    hex: 'Convertisseur de base numérique',
    loan: 'Calculateur de Prêt',
    savings: 'Calculateur d’Épargne',
    tip: 'Calculateur de Pourboire',
    unitprice: 'Prix Unitaire',
    worldtime: 'Heure Mondiale',
    settings: 'Paramètres',
    favoritesTitle: 'Favoris',
    allCalcsTitle: 'Toutes les calculatrices',
    menuSettings: 'Paramètres',
    menuHelp: 'Aide'
  },
  de: {
    appTitle: 'SA Calculator',
    calc: 'Rechner',
    currencies: 'Währungsrechner',
    units: 'Einheitenrechner',
    discount: 'Rabattrechner',
    percent: 'Prozentrechner',
    salestax: 'Umsatzsteuerrechner',
    bodymetrics: 'Körperdaten-Rechner',
    date: 'Datumsrechner',
    fuelcost: 'Treibstoffkosten',
    fuelefficiency: 'Kraftstoffeffizienz',
    gradeavg: 'Notendurchschnitt',
    hex: 'Zahlensystem-Konverter',
    loan: 'Kreditrechner',
    savings: 'Sparrechner',
    tip: 'Trinkgeldrechner',
    unitprice: 'Stückpreisvergleich',
    worldtime: 'Weltzeitkonverter',
    settings: 'Einstellungen',
    favoritesTitle: 'Favoriten',
    allCalcsTitle: 'Alle Rechner',
    menuSettings: 'Einstellungen',
    menuHelp: 'Hilfe'
  },
  ar: {
    appTitle: 'SA Calculator',
    calc: 'حاسبة',
    currencies: 'محول العملات',
    units: 'محول الوحدات',
    discount: 'حاسبة الخصم',
    percent: 'حاسبة النسبة المئوية',
    salestax: 'ضريبة المبيعات',
    bodymetrics: 'مقاييس الجسم',
    date: 'حاسبة التاريخ',
    fuelcost: 'تكلفة الوقود',
    fuelefficiency: 'كفاءة الوقود',
    gradeavg: 'المعدل التراكمي',
    hex: 'حاسبة النظام الست عشري',
    loan: 'حاسبة القروض',
    savings: 'حاسبة المدخرات',
    tip: 'حاسبة البقشيش',
    unitprice: 'سعر الوحدة',
    worldtime: 'محول الوقت العالمي',
    settings: 'الإعدادات',
    favoritesTitle: 'المفضلة',
    allCalcsTitle: 'جميع الحاسبات',
    menuSettings: 'الإعدادات',
    menuHelp: 'مساعدة'
  },
  zh: {
    appTitle: 'SA Calculator',
    calc: '计算器',
    currencies: '货币换算',
    units: '单位换算',
    discount: '折扣计算器',
    percent: '百分比计算器',
    salestax: '销售税计算器',
    bodymetrics: '身体指数计算器',
    date: '日期计算器',
    fuelcost: '燃油成本计算器',
    fuelefficiency: '燃油效率',
    gradeavg: '平均成绩绩点 (GPA)',
    hex: '进制转换器',
    loan: '贷款计算器',
    savings: '储蓄计算器',
    tip: '小费计算器',
    unitprice: '单价比较计算器',
    worldtime: '世界时间换算',
    settings: '设置',
    favoritesTitle: '常用收藏',
    allCalcsTitle: '所有计算器',
    menuSettings: '设置',
    menuHelp: '帮助'
  }
};

function applyLanguage(lang) {
  if (!Object.prototype.hasOwnProperty.call(TRANSLATIONS, lang)) lang = 'en';
  STATE.language = lang;
  const languageSelect = document.getElementById('setting-language');
  if (languageSelect && languageSelect.value !== lang) languageSelect.value = lang;
  saveSettingsToStorage();
  const dict = TRANSLATIONS[lang] || TRANSLATIONS.en;
  
  // 1. Update Header Title
  const currentTitleKey = STATE.currentScreen === 'calc' ? 'appTitle' : STATE.currentScreen;
  const currentScreenTitle = dict[currentTitleKey] || (STATE.currentScreen === 'calc' ? 'SA Calculator' : STATE.currentScreen);
  setElementText('app-title', currentScreenTitle);

  // 2. Update Drawer Header & Menu
  document.documentElement.lang = lang;
  const drawerHeader = document.getElementById('drawer-dialog-title');
  if (drawerHeader) drawerHeader.textContent = dict.appTitle || 'SA Calculator';
  const drawerSubtitle = document.querySelector('.drawer-brand-block small');
  if (drawerSubtitle) drawerSubtitle.textContent = 'YOUR CALCULATION WORKSPACE';
  
  const updateDrawerMenuLabel = (element, icon, label) => {
    if (!element) return;
    const iconNode = document.createElement('span');
    iconNode.className = 'menu-icon';
    iconNode.setAttribute('aria-hidden', 'true');
    iconNode.textContent = icon;
    element.replaceChildren(iconNode, document.createTextNode(` ${label}`));
    element.setAttribute('aria-label', label);
  };

  updateDrawerMenuLabel(document.getElementById('menu-help'), '❓', dict.menuHelp || 'Help');

  // 3. Update Drawer Titles
  const sectionTitles = document.querySelectorAll('.drawer-section-title');
  if (sectionTitles[0]) sectionTitles[0].textContent = dict.favoritesTitle || 'Favorites';
  if (sectionTitles[1]) sectionTitles[1].textContent = dict.allCalcsTitle || 'All Calculators';

  // 4. Update Drawer Item Labels
  document.querySelectorAll('.drawer-item').forEach(item => {
    const sId = item.getAttribute('data-screen');
    if (sId && dict[sId]) {
      item.textContent = dict[sId];
      item.setAttribute('aria-label', dict[sId]);
    }
  });

  // 5. Update favorite labels in both the manager and the drawer.
  initFavoritesManager();
  updateDrawerFavoritesDOM();

  // Translate static and dynamically-created UI text, accessible labels and placeholders.
  if (globalThis.SALocalization) globalThis.SALocalization.apply(lang);
  refreshCurrencyLocalization();
  if (STATE.currentScreen === 'calc' && STATE.isResultMode) updateCalcDisplayDOM(false);
  renderDateEvents();
  updateWorldTimeLive();
  renderCurrencyRefreshTimes();
  showToast('Language changed');
}

function applyStartupScreen(screenId) {
  const valid = ['calc', 'currencies', 'units', 'discount', 'percent', 'salestax', 'bodymetrics', 'date', 'fuelcost', 'fuelefficiency', 'gradeavg', 'hex', 'loan', 'savings', 'tip', 'unitprice', 'worldtime', 'last'];
  if (!valid.includes(screenId)) {
    showToast('Choose a supported startup screen');
    return;
  }
  STATE.startupScreen = screenId;
  saveSettingsToStorage();
  const startupNames = {calc:'Standard Calculator',currencies:'Currencies',units:'Units',discount:'Discount',percent:'Percent',salestax:'Sales Tax',bodymetrics:'Body Metrics',date:'Date',fuelcost:'Fuel Cost',fuelefficiency:'Fuel Efficiency',gradeavg:'Grade Average',hex:'Number Base',loan:'Loan / EMI',savings:'Savings',tip:'Tip',unitprice:'Unit Price',worldtime:'World Time'};
  showToast(screenId === 'last' ? 'Will resume the last calculator screen on launch' : `Default startup screen: ${startupNames[screenId] || screenId}`);
}

function toggleRestoreState(enabled) {
  STATE.restoreState = enabled;
  if (!enabled) {
    try { localStorage.removeItem('sumaire_previous_inputs'); } catch (error) {}
  } else {
    persistPreviousInputs();
  }
  saveSettingsToStorage();
}

const ALL_CALC_ITEMS = [
  { id: 'calc', name: 'Calculator' },
  { id: 'currencies', name: 'Currencies' },
  { id: 'units', name: 'Units' },
  { id: 'discount', name: 'Discount' },
  { id: 'percent', name: 'Percent' },
  { id: 'salestax', name: 'Sales Tax' },
  { id: 'bodymetrics', name: 'Body Metrics' },
  { id: 'date', name: 'Date' },
  { id: 'fuelcost', name: 'Fuel Cost' },
  { id: 'fuelefficiency', name: 'Fuel Efficiency' },
  { id: 'gradeavg', name: 'Grade Average' },
  { id: 'hex', name: 'Number Base' },
  { id: 'loan', name: 'Loan' },
  { id: 'savings', name: 'Savings' },
  { id: 'tip', name: 'Tip' },
  { id: 'unitprice', name: 'Unit Price' },
  { id: 'worldtime', name: 'World Time' },
  { id: 'scientific', name: 'Scientific Calculator' }
];

function initFavoritesManager() {
  const container = document.getElementById('favorites-checklist');
  if (!container) return;
  container.replaceChildren();
  if (!STATE.favorites) {
    STATE.favorites = ['currencies', 'units', 'discount', 'percent', 'salestax'];
  }
  const fragment = document.createDocumentFragment();
  ALL_CALC_ITEMS.forEach(item => {
    const div = document.createElement('label');
    div.style.cssText = 'display:flex; align-items:center; gap:6px; font-size:12px; cursor:pointer; padding:3px 0;';
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = STATE.favorites.includes(item.id);
    checkbox.addEventListener('change', () => toggleFavoriteItem(item.id, checkbox.checked));
    div.append(checkbox, document.createTextNode(` ${item.name}`));
    fragment.appendChild(div);
  });
  container.appendChild(fragment);
}

function toggleFavoriteItem(id, isFav) {
  if (isFav && !STATE.favorites.includes(id)) {
    STATE.favorites.push(id);
  } else if (!isFav) {
    STATE.favorites = STATE.favorites.filter(f => f !== id);
  }
  saveSettingsToStorage();
  updateDrawerFavoritesDOM();
  if (STATE.currentScreen === 'favorites') renderFavoritesScreen();
}

function updateDrawerFavoritesDOM() {
  const drawerList = document.querySelector('.drawer-scrollable');
  if (!drawerList) return;
  const sections = drawerList.querySelectorAll('.drawer-section-title');
  const favSection = sections[0];
  const allSection = sections[1] || null;
  if (!favSection) return;
  let curr = favSection.nextElementSibling;
  while (curr && curr !== allSection) {
    const next = curr.nextElementSibling;
    curr.remove();
    curr = next;
  }
  const fragment = document.createDocumentFragment();
  const safeFavorites = [...new Set((Array.isArray(STATE.favorites) ? STATE.favorites : []).filter(id => ALL_CALC_ITEMS.some(item => item.id === id)))];
  STATE.favorites = safeFavorites;
  // Calculator already has its own permanent bottom-navigation destination; never duplicate it in the drawer.
  const drawerFavorites = safeFavorites.filter(id => id !== 'calc');
  drawerFavorites.forEach(favId => {
    const item = ALL_CALC_ITEMS.find(candidate => candidate.id === favId);
    if (!item) return;
    const div = document.createElement('div');
    div.className = `drawer-item ${STATE.currentScreen === favId ? 'active' : ''}`;
    div.setAttribute('data-screen', item.id);
    div.setAttribute('role', 'button');
    div.setAttribute('tabindex', '0');
    div.setAttribute('aria-label', TRANSLATIONS[STATE.language]?.[item.id] || item.name);
    if (STATE.currentScreen === favId) div.setAttribute('aria-current', 'page');
    div.addEventListener('keydown', event => {
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault();
        div.click();
      }
    });
    const dot = document.createElement('span');
    dot.className = 'drawer-dot';
    const label = TRANSLATIONS[STATE.language]?.[item.id] || item.name;
    div.append(dot, document.createTextNode(label));
    fragment.appendChild(div);
  });
  drawerList.insertBefore(fragment, allSection);
}

function resetDefaultFavorites() {
  STATE.favorites = ['currencies', 'units', 'discount', 'percent', 'salestax'];
  saveSettingsToStorage();
  initFavoritesManager();
  updateDrawerFavoritesDOM();
  showToast('Favorites reset to defaults');
}

function toggleRecordHistory(enabled) {
  STATE.recordHistory = enabled;
  saveSettingsToStorage();
}

function applyMaxHistory(val) {
  STATE.maxHistory = Math.max(1, Math.min(500, Number.parseInt(val, 10) || 50));
  saveSettingsToStorage();
  if (STATE.history && STATE.history.length > STATE.maxHistory) {
    trimHistoryToLimit();
    persistHistory();
    updateHistoryDOM();
  }
  persistHistory();
  showToast(`Max history set to ${val}`);
}

function toggleKeySound(enabled) {
  STATE.keySound = enabled;
  saveSettingsToStorage();
  showToast(enabled ? 'Key sound enabled' : 'Key sound muted');
}

function applyVibeStrength(val) {
  STATE.vibeStrength = val;
  saveSettingsToStorage();
  triggerHaptic();
  showToast(`Vibration set to ${val}`);
}

function toggleTelemetry(enabled) {
  // This standalone build has no analytics or crash-reporting endpoint.
  STATE.telemetry = false;
  const control = document.getElementById('setting-telemetry');
  if (control) control.checked = false;
  saveSettingsToStorage();
  if (enabled) showToast('Diagnostics are local only; nothing is uploaded');
}

let purgeCacheDialogOpener=null;
function getDialogFocusable(modal){ return modal ? [...modal.querySelectorAll('button,[href],input,select,textarea,[tabindex]:not([tabindex="-1"])')].filter(el=>!el.disabled && el.offsetParent!==null) : []; }
function openPurgeCacheDialog() {
  const modal=document.getElementById('purge-cache-modal'); if(!modal) return purgeLocalCache();
  purgeCacheDialogOpener=document.activeElement; modal.classList.add('active'); modal.setAttribute('aria-hidden','false');
  requestAnimationFrame(()=>{const f=getDialogFocusable(modal);(f[0]||modal).focus({preventScroll:true});});
}
function closePurgeCacheDialog() {
  const modal=document.getElementById('purge-cache-modal'); if(!modal) return;
  modal.classList.remove('active'); modal.setAttribute('aria-hidden','true');
  const target=purgeCacheDialogOpener?.isConnected?purgeCacheDialogOpener:document.getElementById('purge-cache-cancel'); target?.focus?.({preventScroll:true}); purgeCacheDialogOpener=null;
}

async function purgeLocalCache() {
  const modal=document.getElementById('purge-cache-modal'); if(modal?.classList.contains('active')){ modal.classList.remove('active'); modal.setAttribute('aria-hidden','true'); }
  const keys=['sumaire_settings_master','sumaire_previous_inputs','sumaire_history_v1','sumaire_currency_rates_v1',CURRENCY_RATE_CACHE_KEY,'sumaire_memory_v1','sumaire_world_cities_v1','sumaire_last_screen','sumaire_date_events_v1','sumaire_gpa_courses_v1','sumaire_ovulation_notes_v1'];
  let storageErrors=0;
  try{keys.forEach(k=>localStorage.removeItem(k));keys.forEach(k=>{if(localStorage.getItem(k)!==null)storageErrors++;});}catch(_){storageErrors++;}
  try{sessionStorage.clear();}catch(_){storageErrors++;}
  let cacheErrors=0;
  try{if(window.caches&&typeof caches.keys==='function'){const cacheKeys=await caches.keys();const results=await Promise.all(cacheKeys.map(k=>caches.delete(k)));cacheErrors=results.filter(x=>x!==true).length;}}catch(_){cacheErrors++;}
  let swErrors=0;
  try{if(navigator.serviceWorker?.getRegistrations){const regs=await navigator.serviceWorker.getRegistrations();const results=await Promise.all(regs.map(r=>r.unregister()));swErrors=results.filter(x=>x!==true).length;}}catch(_){swErrors++;}
  const ok=storageErrors===0&&cacheErrors===0&&swErrors===0;
  showToast(ok?'Cached data cleared successfully':`Cache cleanup completed with ${storageErrors+cacheErrors+swErrors} verification issue(s)`);
  setTimeout(()=>location.reload(),700);
}

let supportModalOpener = null;
function openSupportModal(id) {
  const modal = document.getElementById(id);
  if (!modal) { showToast('This help panel is unavailable'); return; }
  supportModalOpener = document.activeElement;
  modal.classList.add('active');
  modal.setAttribute('aria-hidden', 'false');
  document.body.classList.add('support-modal-open');
  requestAnimationFrame(() => {
    if (!modal.classList.contains('active')) return;
    const first = getModalFocusableElements(modal)[0];
    (first || modal).focus({ preventScroll: true });
  });
}
function closeSupportModal(modal) {
  if (!modal) return;
  modal.classList.remove('active');
  modal.setAttribute('aria-hidden', 'true');
  if (!document.querySelector('.support-modal.active')) document.body.classList.remove('support-modal-open');
  const target = supportModalOpener?.isConnected ? supportModalOpener : document.getElementById('menu-help');
  target?.focus?.({ preventScroll: true });
  supportModalOpener = null;
}
function showHelpModal() { openSupportModal('help-modal'); }
function showContactModal() { openSupportModal('feedback-modal'); }
async function shareFeedbackReport() {
  const field = document.getElementById('feedback-report-text');
  const details = String(field?.value || '').trim();
  if (!details) { showToast('Write a short description before sharing'); field?.focus(); return; }
  const report = `SA Calculator feedback / bug report\nVersion: ${APP_VERSION}\nScreen: ${STATE.currentScreen}\n\n${details}`;
  if (navigator.share) {
    try { await navigator.share({ title: 'SA Calculator feedback', text: report }); showToast('Share sheet opened'); }
    catch (error) { if (error?.name !== 'AbortError') showToast('Sharing is unavailable; use Copy report instead'); }
  } else {
    try { await navigator.clipboard.writeText(report); showToast('Report copied. You can paste it into your support channel.'); }
    catch (_) { copyTextFallback(report); }
  }
}
function copyFeedbackReport() {
  const field = document.getElementById('feedback-report-text');
  const details = String(field?.value || '').trim();
  if (!details) { showToast('Write a short description before copying'); field?.focus(); return; }
  const report = `SA Calculator feedback / bug report\nVersion: ${APP_VERSION}\nScreen: ${STATE.currentScreen}\n\n${details}`;
  if (navigator.clipboard?.writeText) navigator.clipboard.writeText(report).then(() => showToast('Report copied')).catch(() => copyTextFallback(report));
  else copyTextFallback(report);
}
function initSupportDialogs() {
  document.querySelectorAll('.support-modal [data-support-close]').forEach(button => button.addEventListener('click', () => closeSupportModal(button.closest('.support-modal'))));
  document.querySelectorAll('.support-modal').forEach(modal => {
    modal.addEventListener('click', event => { if (event.target === modal) closeSupportModal(modal); });
  });
  document.addEventListener('keydown', event => {
    const modal = document.querySelector('.support-modal.active');
    if (!modal) return;
    if (event.key === 'Escape') { event.preventDefault(); closeSupportModal(modal); }
    else keepModalTabFocus(event, modal);
  });
  document.getElementById('feedback-copy')?.addEventListener('click', copyFeedbackReport);
  document.getElementById('feedback-share')?.addEventListener('click', shareFeedbackReport);
}



// Purge dialog keyboard/accessibility guard.
(()=>{
  const modal=document.getElementById('purge-cache-modal'); if(!modal) return;
  modal.addEventListener('keydown',e=>{
    if(!modal.classList.contains('active')) return;
    if(e.key==='Escape'){e.preventDefault();closePurgeCacheDialog();return;}
    if(e.key!=='Tab') return;
    const f=getDialogFocusable(modal); if(!f.length) return;
    const first=f[0],last=f[f.length-1];
    if(e.shiftKey&&document.activeElement===first){e.preventDefault();last.focus();}
    else if(!e.shiftKey&&document.activeElement===last){e.preventDefault();first.focus();}
  });
  modal.addEventListener('click',e=>{if(e.target===modal)closePurgeCacheDialog();});
})();

// Centralized event delegation: no inline JavaScript event attributes in HTML.
(() => {
  const actions = {
    resetAllDefaults,
    toggleFullScreen,
    applyFontSize,
    toggleScreenAwake,
    openThemePicker,
    applySettingTheme,
    applyAccentColor,
    toggleOLED,
    toggleLiveCalc,
    toggleImplicit,
    applySettingPrecision,
    applySettingSeparator,
    toggleTrailingZero,
    applyLanguage,
    applyStartupScreen,
    toggleRestoreState,
    resetDefaultFavorites,
    clearAllHistory,
    toggleRecordHistory,
    applyMaxHistory,
    toggleAutoCopy,
    toggleKeySound,
    toggleHaptic,
    applyVibeStrength,
    toggleTelemetry,
    purgeLocalCache,
    openPurgeCacheDialog,
    closePurgeCacheDialog,
    showHelpModal,
    showContactModal,
    closeThemePicker,
    closePopupKeypad
  };

  const invoke = (element, eventType) => {
    if (!element || element.dataset.actionEvent !== eventType) return;
    const action = actions[element.dataset.action];
    if (typeof action !== 'function') return;
    if (eventType === 'change') {
      const value = element.type === 'checkbox' ? element.checked : element.value;
      action(value);
    } else {
      action();
    }
  };

  document.addEventListener('click', (event) => {
    const element = event.target.closest('[data-action][data-action-event="click"]');
    if (element) invoke(element, 'click');
  });

  document.addEventListener('change', (event) => {
    const element = event.target.closest('[data-action][data-action-event="change"]');
    if (element) invoke(element, 'change');
  });

  document.addEventListener('keydown', (event) => {
    if (event.key !== 'Enter' && event.key !== ' ') return;
    const element = event.target.closest('[role="button"][data-action][data-action-event="click"]');
    if (!element || element.tagName === 'BUTTON' || element.tagName === 'A') return;
    event.preventDefault();
    invoke(element, 'click');
  });

  document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') closePurgeCacheDialog();
  });
})();


/* Sumaire 1.81.0 — unified accessible option picker.
   Native selects remain authoritative for values, validation and existing app handlers. */
(function initSumaireOptionPicker() {
  'use strict';
  let active = null;
  let backdrop = null;
  let panel = null;
  let optionList = null;
  let heading = null;
  let searchWrap = null;
  let searchInput = null;
  let highlighted = -1;
  let previousBodyOverflow = '';
  let closeTimer = 0;

  const isEligible = (select) => select instanceof HTMLSelectElement &&
    !select.dataset.sumairePicker && !select.hidden && !select.multiple &&
    !(Number(select.size) > 1) && select.getAttribute('aria-hidden') !== 'true' && select.options.length > 0;

  function selectedLabel(select) {
    const option = select.options[select.selectedIndex];
    return option ? option.textContent.trim() : 'Choose an option';
  }

  function updateTrigger(select) {
    const trigger = select && select._sumaireTrigger;
    if (!trigger) return;
    const value = trigger.querySelector('.sumaire-select-value');
    const isCurrency = /^cur-(from|to)$/.test(select.id || '');
    const isUnit = /^unit-(from|to)$/.test(select.id || '');
    if (isCurrency) {
      const code = String(select.value || '').toUpperCase();
      const flag = currencyFlagForCode(code);
      const name = localizedCurrencyName(code);
      trigger.replaceChildren();
      const flagNode = document.createElement('span');
      flagNode.className = 'sumaire-select-flag';
      flagNode.setAttribute('aria-hidden', 'true');
      flagNode.textContent = flag;
      const identity = document.createElement('span');
      identity.className = 'sumaire-select-value';
      const codeNode = document.createElement('strong');
      codeNode.textContent = code;
      const nameNode = document.createElement('small');
      nameNode.textContent = name;
      identity.append(codeNode, nameNode);
      const chevron = document.createElement('span');
      chevron.className = 'sumaire-select-chevron';
      chevron.setAttribute('aria-hidden', 'true');
      trigger.append(flagNode, identity, chevron);
      select.parentElement?.querySelectorAll('.code-select-display,.currency-flag,.currency-name').forEach(node => { node.hidden = true; });
    } else if (value) {
      value.textContent = selectedLabel(select);
    }
    trigger.title = isCurrency ? `${select.value} · ${localizedCurrencyName(select.value)}` : selectedLabel(select);
    trigger.setAttribute('aria-label', (select.getAttribute('aria-label') || select.name || 'Choose an option') + ': ' + selectedLabel(select));
    trigger.disabled = !!select.disabled;
    trigger.setAttribute('aria-required', select.required ? 'true' : 'false');
    trigger.setAttribute('aria-expanded', active === select ? 'true' : 'false');
  }

  function enhance(select) {
    if (!isEligible(select) || !select.parentNode) return;
    select.dataset.sumairePicker = 'true';
    const trigger = document.createElement('button');
    trigger.type = 'button';
    trigger.className = (select.className ? select.className + ' ' : '') + 'sumaire-select-trigger';
    trigger.id = 'sumaire-trigger-' + (select.id || ('field-' + document.querySelectorAll('.sumaire-select-trigger').length));
    if (select.getAttribute('style')) trigger.setAttribute('style', select.getAttribute('style'));
    trigger.innerHTML = '<span class="sumaire-select-value"></span><span class="sumaire-select-chevron" aria-hidden="true"></span>';
    trigger.title = selectedLabel(select);
    trigger.setAttribute('role', 'combobox');
    trigger.setAttribute('aria-haspopup', 'dialog');
    trigger.setAttribute('aria-expanded', 'false');
    trigger.setAttribute('aria-controls', 'sumaire-option-list');
    trigger.setAttribute('aria-label', select.getAttribute('aria-label') || select.name || 'Choose an option');
    const labelledBy = select.getAttribute('aria-labelledby');
    const externalLabel = select.id ? document.querySelector('label[for="' + CSS.escape(select.id) + '"]') : null;
    if (labelledBy) trigger.setAttribute('aria-labelledby', labelledBy);
    else if (externalLabel && externalLabel.id) trigger.setAttribute('aria-labelledby', externalLabel.id);
    select.parentNode.insertBefore(trigger, select);
    select.classList.add('sumaire-select-native');
    select.tabIndex = -1;
    select.setAttribute('aria-hidden', 'true');
    select._sumaireTrigger = trigger;
    updateTrigger(select);
    trigger.addEventListener('click', () => openPicker(select));
    select.addEventListener('change', () => updateTrigger(select));
    const observer = new MutationObserver(() => {
      updateTrigger(select);
      if (active === select) renderOptions(select);
    });
    observer.observe(select, { childList: true, subtree: true, characterData: true, attributes: true });
    select._sumaireOptionObserver = observer;
  }

  function ensureLayer() {
    if (backdrop) return;
    backdrop = document.createElement('div');
    backdrop.className = 'sumaire-picker-backdrop';
    backdrop.hidden = true;
    backdrop.innerHTML =
      '<section class="sumaire-picker-panel" role="dialog" aria-modal="true" aria-labelledby="sumaire-picker-heading" tabindex="-1">' +
        '<header class="sumaire-picker-header"><div class="sumaire-picker-heading" id="sumaire-picker-heading"></div><button type="button" class="sumaire-picker-close" aria-label="Close options" title="Close">&times;</button></header>' +
        '<div class="sumaire-picker-search-wrap" hidden><input type="search" class="sumaire-picker-search" aria-label="Search currencies" placeholder="Search currency name or code" autocomplete="off"></div>' +
        '<div class="sumaire-picker-options" id="sumaire-option-list" role="listbox" tabindex="0" aria-labelledby="sumaire-picker-heading"></div>' +
      '</section>';
    document.body.appendChild(backdrop);
    panel = backdrop.querySelector('.sumaire-picker-panel');
    heading = backdrop.querySelector('.sumaire-picker-heading');
    searchWrap = backdrop.querySelector('.sumaire-picker-search-wrap');
    searchInput = backdrop.querySelector('.sumaire-picker-search');
    optionList = backdrop.querySelector('.sumaire-picker-options');
    searchInput?.addEventListener('input', () => { if (active) { highlighted = -1; renderOptions(active); } });
    backdrop.querySelector('.sumaire-picker-close').addEventListener('click', () => closePicker(true));
    backdrop.addEventListener('click', event => {
      if (event.target === backdrop) closePicker(true);
    });
  }

  function optionEntries(select) {
    const entries = [];
    Array.from(select.children).forEach(child => {
      if (child.tagName === 'OPTGROUP') {
        Array.from(child.children).forEach(option => {
          if (option.tagName === 'OPTION') entries.push({ option, group: child.label || '', groupDisabled: child.disabled });
        });
      } else if (child.tagName === 'OPTION') entries.push({ option: child, group: '', groupDisabled: false });
    });
    return entries;
  }

  function selectedOptionIndex(select, entries) {
    if (!select || !select.options || !select.options.length) return -1;
    const nativeIndex = Number(select.selectedIndex);
    if (Number.isInteger(nativeIndex) && nativeIndex >= 0 && nativeIndex < select.options.length) {
      const nativeOption = select.options[nativeIndex];
      if (nativeOption && !nativeOption.disabled && !(nativeOption.parentElement && nativeOption.parentElement.disabled)) return nativeIndex;
    }
    const byValue = Array.from(select.options).findIndex(option => option.value === String(select.value || ''));
    if (byValue >= 0) return byValue;
    const firstEnabled = entries.find(({ option, groupDisabled }) => !option.disabled && !groupDisabled);
    return firstEnabled ? Array.prototype.indexOf.call(select.options, firstEnabled.option) : -1;
  }

  function renderOptions(select) {
    if (!optionList) return;
    optionList.replaceChildren();
    const entries = optionEntries(select);
    const isCurrency = /^cur-(from|to)$/.test(select?.id || '');
    const isUnit = /^unit-(from|to)$/.test(select?.id || '');
    const searchable = isCurrency || isUnit;
    const query = searchable ? String(searchInput?.value || '').trim().toLocaleLowerCase() : '';
    const selectedIndex = selectedOptionIndex(select, entries);
    // Show the complete available catalogue immediately. Search is an optional
    // refinement, never a prerequisite for discovering currencies or units.
    // The list itself is virtualized only by the scroll container; no entries
    // are silently hidden on first open.
    entries.forEach(({ option, group, groupDisabled }) => {
      const code = String(option.value || '').toUpperCase();
      const currencyName = isCurrency ? localizedCurrencyName(code) : '';
      const regionName = isCurrency ? currencyRegionNameForCode(code) : '';
      const optionLabel = (group ? group + ' · ' : '') + (isCurrency ? `${currencyName} · ${code} · ${regionName}` : option.textContent.trim());
      const index = Array.prototype.indexOf.call(select.options, option);
      // Every enabled option is present on first open. A non-empty query filters
      // the same complete catalogue immediately, including one-character searches.
      if (query && !(optionLabel + ' ' + option.value).toLocaleLowerCase().includes(query)) return;
      const item = document.createElement('button');
      item.type = 'button';
      item.className = 'sumaire-picker-option ' + (isCurrency ? 'is-currency-option' : isUnit ? 'is-unit-option' : 'is-generic-option');
      item.setAttribute('role', 'option');
      item.dataset.optionIndex = String(index);
      item.id = 'sumaire-option-' + index;
      item.setAttribute('aria-selected', option.selected ? 'true' : 'false');
      item.disabled = option.disabled || groupDisabled;
      if (isCurrency) {
        const flag = document.createElement('span');
        flag.className = 'sumaire-picker-option-flag currency-picker-flag';
        flag.setAttribute('aria-hidden', 'true');
        flag.textContent = currencyFlagForCode(code);
        item.appendChild(flag);
      }
      const label = document.createElement('span');
      label.className = 'sumaire-picker-option-label';
      if (isCurrency) {
        const name = document.createElement('strong');
        name.textContent = currencyName;
        const meta = document.createElement('small');
        meta.textContent = `${code} · ${regionName}`;
        label.append(name, meta);
      } else {
        label.textContent = optionLabel;
      }
      const check = document.createElement('span');
      check.className = 'sumaire-picker-check';
      check.setAttribute('aria-hidden', 'true');
      check.textContent = '✓';
      item.append(label, check);
      item.addEventListener('click', () => chooseOption(select, index));
      optionList.appendChild(item);
    });
    if (!optionList.children.length) {
      const empty = document.createElement('div');
      empty.className = 'sumaire-picker-empty';
      empty.setAttribute('role', 'status');
      empty.textContent = /^unit-(from|to)$/.test(select?.id || '') ? 'No matching units' : 'No matching currencies';
      optionList.appendChild(empty);
    }
    const enabled = Array.from(optionList.querySelectorAll('.sumaire-picker-option:not(:disabled)'));
    if (!enabled.some(el => Number(el.dataset.optionIndex) === highlighted)) {
      highlighted = enabled.length ? Number(enabled[0].dataset.optionIndex) : -1;
    }
    updateHighlight(false);
  }

  function updateHighlight(scroll) {
    if (!optionList) return;
    // Options may be replaced while the picker remains open. Remove any
    // previous active-descendant ID before applying the current live option.
    optionList.removeAttribute('aria-activedescendant');
    const items = optionList.querySelectorAll('.sumaire-picker-option');
    items.forEach(item => {
      const isActive = Number(item.dataset.optionIndex) === highlighted && !item.disabled;
      item.classList.toggle('is-highlighted', isActive);
      if (isActive) optionList.setAttribute('aria-activedescendant', item.id);
    });
    const current = optionList.querySelector('.sumaire-picker-option.is-highlighted');
    if (scroll && current) current.scrollIntoView({ block: 'nearest' });
  }

  function openPicker(select) {
    if (!select || !select.isConnected || select.disabled) return;
    ensureLayer();
    if (closeTimer) { clearTimeout(closeTimer); closeTimer = 0; }
    if (active && active !== select) closePicker(false, true);
    active = select;
    highlighted = selectedOptionIndex(select, optionEntries(select));
    if (highlighted < 0) highlighted = 0;
    const searchableCurrency = /^cur-(from|to)$/.test(select.id || '');
    const searchableUnit = /^unit-(from|to)$/.test(select.id || '');
    const isCurrency = searchableCurrency;
    const isUnit = searchableUnit;
    const searchableSelection = searchableCurrency || searchableUnit;
    const selectedCode = String(select.value || '').toUpperCase();
    const direction = select.id === 'cur-from' ? 'From currency' : select.id === 'cur-to' ? 'To currency' : select.id === 'unit-from' ? 'From unit' : 'To unit';
    heading.textContent = searchableSelection ? `${direction} · ${selectedCode}` : (select.getAttribute('aria-label') || select.name || 'Select an option');
    if (searchWrap) searchWrap.hidden = !searchableSelection;
    if (searchInput) {
      searchInput.value = '';
      searchInput.blur();
      searchInput.placeholder = isCurrency ? 'Search currency name, code or country' : 'Search unit name or symbol';
      searchInput.setAttribute('aria-label', isCurrency ? 'Search currencies' : 'Search units');
    }
    optionList.setAttribute('aria-label', heading.textContent);
    renderOptions(select);
    backdrop.hidden = false;
    previousBodyOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    requestAnimationFrame(() => {
      if (active !== select) return;
      backdrop.classList.add('is-open');
      // Keep the currency list visible on open. Search remains available, but the
      // Android IME opens only after the user explicitly taps the search field.
      const closeButton = panel.querySelector('.sumaire-picker-close');
      (closeButton || panel).focus({ preventScroll: true });
      updateHighlight(false);
    });
    updateTrigger(select);
  }

  function chooseOption(select, index) {
    if (!select || index < 0 || index >= select.options.length) return;
    const option = select.options[index];
    if (!option || option.disabled || (option.parentElement && option.parentElement.disabled)) return;
    const changed = select.selectedIndex !== index;
    select.selectedIndex = index;
    updateTrigger(select);
    closePicker(true);
    if (changed) {
      select.dispatchEvent(new Event('input', { bubbles: true }));
      select.dispatchEvent(new Event('change', { bubbles: true }));
    }
  }

  function closePicker(returnFocus, immediate) {
    if (!backdrop || !active) return;
    const previous = active;
    active = null;
    if (searchInput) searchInput.value = '';
    if (searchWrap) searchWrap.hidden = true;
    backdrop.classList.remove('is-open');
    document.body.style.overflow = previousBodyOverflow;
    updateTrigger(previous);
    if (returnFocus && previous._sumaireTrigger && previous._sumaireTrigger.isConnected) {
      previous._sumaireTrigger.focus({ preventScroll: true });
    }
    const finish = () => {
      if (!active && backdrop) backdrop.hidden = true;
      closeTimer = 0;
    };
    if (immediate || window.matchMedia('(prefers-reduced-motion: reduce)').matches) finish();
    else {
      closeTimer = window.setTimeout(finish, 190);
    }
  }

  document.addEventListener('keydown', event => {
    if (!active) return;
    const enabled = Array.from(optionList.querySelectorAll('.sumaire-picker-option:not(:disabled)'));
    if (event.key === 'Escape') {
      event.preventDefault(); closePicker(true);
    } else if (event.key === 'ArrowDown' || event.key === 'ArrowUp' || event.key === 'Home' || event.key === 'End') {
      event.preventDefault();
      if (!enabled.length) return;
      let current = enabled.findIndex(el => Number(el.dataset.optionIndex) === highlighted);
      if (event.key === 'Home') current = 0;
      else if (event.key === 'End') current = enabled.length - 1;
      else current = (current + (event.key === 'ArrowDown' ? 1 : -1) + enabled.length) % enabled.length;
      highlighted = Number(enabled[current].dataset.optionIndex);
      updateHighlight(true);
    } else if (event.key === 'Enter' || event.key === ' ') {
      event.preventDefault(); chooseOption(active, highlighted);
    } else if (event.key === 'Tab') {
      const focusables = Array.from(panel.querySelectorAll('button:not(:disabled), input:not(:disabled), [tabindex="0"]')).filter(el => el.offsetParent !== null);
      if (!focusables.length) { event.preventDefault(); panel.focus({ preventScroll: true }); return; }
      const first = focusables[0], last = focusables[focusables.length - 1];
      if (event.shiftKey && (document.activeElement === first || document.activeElement === panel)) { event.preventDefault(); last.focus(); }
      else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first.focus(); }
    }
  });

  document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('select').forEach(enhance);
    const observer = new MutationObserver(records => {
      records.forEach(record => {
        // A select may be inserted empty and populated asynchronously afterwards.
        const ownerSelect = record.target && record.target.closest ? record.target.closest('select') : null;
        if (ownerSelect) enhance(ownerSelect);
        record.addedNodes.forEach(node => {
          if (node.nodeType !== 1) return;
          if (node.matches && node.matches('select')) enhance(node);
          if (node.closest) { const parentSelect = node.closest('select'); if (parentSelect) enhance(parentSelect); }
          if (node.querySelectorAll) node.querySelectorAll('select').forEach(enhance);
        });
      });
    });
    observer.observe(document.body, { childList: true, subtree: true });
  });
})();
